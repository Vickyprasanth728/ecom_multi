const db = require("../../models");
const Op = db.Sequelize.Op;
const jwt = require("../../helpers/jwt");
const Moment = require('moment');
let fetch = require('node-fetch');
// const Razorpay = require('razorpay');
const authentication = require("../../middlewares/auth.js");

exports.createOrgSusb = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const data = await db['client_subscription'].create({
      org_id: org_id,
      subscription_id: req.body.subscription_id,
      paid_amount: req.body.paid_amount,
      status: req.body.status,
      start_date: req.body.start_date,
      mode_of_payment: req.body.mode_of_payment,
      transaction_id: req.body.transaction_id,
      transaction_status: req.body.transaction_status,
      transaction_time: req.body.transaction_time,
      no_of_days: req.body.no_of_days,
      status: req.body.status,
      created_by: created_by.id
    });
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.findAllOld = async (req, res) => {
  try {

    const organ_id = req.user.id
    console.log('organ_id', organ_id.org_id);

    var condition = {
      where:{
        status: {
          [Op.in]: [1,2]
        },
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','org_id','paid_amount','start_date','mode_of_payment','transaction_time','transaction_id','no_of_days', 'status'],
      include: [
        {
          model: db['subscription'],
          attributes: ['id','subscription_name','status'],
          where: {},
          order: [['id', 'DESC']], // ASC, DESC
          required: false,
        },
        {
          model: db['organization'],
          attributes: ['id','organization_name'],
          where: {},
          required: false,
        },
      ]
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db[req.params.document].findAll(condition);
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.findOne = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      attributes:{exclude :['createdAt','updatedAt']}
    };
    const id = req.params.id;
    const data = await db[req.params.document].findByPk(id,condition);
    if (data) {
      res.status(200).send({
          status:200,
          message:'Success',
          output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(req.body, {
      where: { id: id },
    });
    if (num == 1) {
      let thisQuery = ` SELECT cs.*, sub.subscription_name as subscription_name, sub.status as subscription_status, org.organization_name as organization_name, IF(cs.mode_of_payment = 0, "Stripe", IF(cs.mode_of_payment = 1, "Razor" , "Direct Paymnet")) as payment_name FROM lz_client_subscription as cs 
      left join lz_organization as org on (cs.org_id = org.id) 
      left join lz_subscription as sub on (cs.subscription_id = sub.id) 
      where cs.status IN (1,2)
      group by cs.id
      `
      const data = await db.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message: "Updated successfully.",
        output:data[0]
      });
    } else {
      let thisQuery = ` SELECT cs.*, sub.subscription_name as subscription_name, sub.status as subscription_status, org.organization_name as organization_name, IF(cs.mode_of_payment = 0, "Stripe", IF(cs.mode_of_payment = 1, "Razor" , "Direct Paymnet")) as payment_name FROM lz_client_subscription as cs 
      left join lz_organization as org on (cs.org_id = org.id) 
      left join lz_subscription as sub on (cs.subscription_id = sub.id) 
      where cs.status IN (1,2)
      group by cs.id
      `
      const data1 = await db.sequelize.query(thisQuery);
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`,
        output:data1[0]
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.delete = async (req, res) => {
  const clientSubscriptionData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(clientSubscriptionData,{
      where: { id: id },
    });
    let thisQuery = ` SELECT cs.*, sub.subscription_name as subscription_name, sub.status as subscription_status, org.organization_name as organization_name, IF(cs.mode_of_payment = 0, "Stripe", IF(cs.mode_of_payment = 1, "Razor" , "Direct Paymnet")) as payment_name FROM lz_client_subscription as cs 
    left join lz_organization as org on (cs.org_id = org.id) 
    left join lz_subscription as sub on (cs.subscription_id = sub.id) 
    where cs.status IN (1,2)
    group by cs.id
    `
    const data = await db.sequelize.query(thisQuery);
    
  if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!",
        output:data[0]
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`,
        output:data
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.planExpire = async (req, res) => {
  try {

    const created_by = req.user.id
    console.log('created_by111', created_by.id);

    const id = req.params.id;
    const getData = await db[req.params.document].findAll({
        where:{id :id},
        attributes:["id",'start_date','no_of_days']
    });

    const dateNum = getData[0]?.dataValues.start_date
    console.log('dateNum',dateNum);

    const NoOfDays = getData[0].dataValues.no_of_days
    console.log('NoOfDays',NoOfDays);

    const checkdate = (startingDate, number, add) => {
      if (add) {
        return new Date(new Date().setDate(startingDate.getDate() + number));
      } else {
        return new Date(new Date().setDate(startingDate.getDate() - number));
      }
    }
    // console.log('Today : ' + new Date());
    // console.log('Past : ' + checkdate(new Date(), 5, false));
    console.log('Future : ' + checkdate(dateNum, NoOfDays, true));

    const expireDate = checkdate(dateNum, NoOfDays, true)
    const TodayDate = new Date()
    console.log("expireDate", expireDate);
    console.log('TodayDate', TodayDate);

    const FinalExpiredDate = {
      expireDate: Moment(expireDate).format('YYYY-MM-DD'),
      }
      // console.log("FinalExpiredDate",FinalExpiredDate.expireDate);

    const FinalTodayDate = {
      TodayDate: Moment.utc().format('YYYY-MM-DD'),
      }
      console.log("FinalTodayDate",FinalTodayDate.TodayDate);

      const logindata = await db['user_timeline'].findOne({
        where:{user_id :created_by.id},
        order:[["id", "desc"]]
      });
      console.log("logindata", logindata.dataValues.user_id);

      const loginCheckDate = logindata.dataValues.login_time

      const loginDate = {
        LoginDate: Moment.utc(loginCheckDate).format('YYYY-MM-DD'),
        }
      console.log("FinalExpiredDate",FinalExpiredDate.expireDate);
      console.log("loginDate",loginDate.LoginDate);

      let ed = FinalExpiredDate.expireDate
      let ld = loginDate.LoginDate
        
      console.log("edddd",ed);
      console.log("lddd",ld);

    if(ed.toString() == ld.toString() || ed.toString() < ld.toString()) {
      const subsdata = {
        status: 0
      }

      const num = await db[req.params.document].update(subsdata, {
        where: { id: id },
      });
    } 
    
    if (getData) {
      res.status(200).send({
          status:200,
          message:'Success',
          output:getData
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.findOrgID = async (req, res) => {
  try {

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;
    const organization_id = req.params.org_id;
    const data = await db[req.params.document].findAll({
      where:{
        status:1,org_id : organization_id
      },
      attributes:{exclude :['createdAt','updatedAt']},
      include:[
        {
          model: db["subscription"],
          // attributes: { exclude: ['createdAt', 'updatedAt'] },
          where: {},
          required: false,
        },
      ]
    });
    const data1 = await db[req.params.document].findAll({
      where:{
        status:1,org_id : organization_id
      },
      order:[['id', 'asc']],
      limit:1,
      attributes:{exclude :['createdAt','updatedAt']},
      include:[
        {
          model: db["subscription"],
          // attributes: { exclude: ['createdAt', 'updatedAt'] },
          where: {},
          required: false,
        },
      ]
    });
    const data2 = await db[req.params.document].findAll({
      where:{
        status:1,org_id : organization_id
      },
      order:[['id', 'desc']],
      limit:1,
      attributes:{exclude :['createdAt','updatedAt']},
      include:[
        {
          model: db["subscription"],
          // attributes: { exclude: ['createdAt', 'updatedAt'] },
          where: {},
          required: false,
        },
      ]
    });

    const active1 = data1[0]?.dataValues.id 
    const upcoming1 = data2[0]?.dataValues.id 

    console.log('active1', active1);
    console.log('upcoming1', upcoming1);

    const upcoming2 = (active1 === upcoming1 ? [] : null) ?? data2

    if (data) {
      res.status(200).send({
          status:200,
          message:'Success',
          output:data,
          active_plan: data1,
          upcoming_plan: upcoming2
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const organanization_id = req.body.org_id

    const id = req.params.id;
    const getData = await db['client_subscription'].findAll({
      where:{org_id : organanization_id},
      order:[['id', 'desc']],
      attributes:["id",'start_date','no_of_days','org_id']
  });
    const getData123 = await db['client_subscription'].findAll({
      // where:{org_id : org_id},
      order:[['id', 'desc']],
      attributes:["id",'start_date','no_of_days','org_id']
  });

  const newOrg = getData[0]?.dataValues.org_id
  console.log("clientSubs", newOrg);

  const dateNum = getData[0]?.dataValues.start_date
  console.log('dateNum',dateNum);

  const NoOfDays = getData[0]?.dataValues.no_of_days
  console.log('NoOfDays',NoOfDays);

  const checkdate = (startingDate, number, add) => {
    if (add) {
      return new Date(new Date().setDate(startingDate?.getDate() + number));
    } else {
      return new Date(new Date().setDate(startingDate?.getDate() - number));
    }
  }
  // console.log('Today : ' + new Date());
  // console.log('Past : ' + checkdate(new Date(), 5, false));
  console.log('Future : ' + checkdate(dateNum, NoOfDays, true));

  const expireDate = checkdate(dateNum, NoOfDays, true)
  const TodayDate = new Date()
  console.log("expireDate", expireDate);
  console.log('TodayDate', TodayDate);

  const eeeeee = Moment.utc(dateNum).add(NoOfDays - 5, "days").format('YYYY-MM-DD')
  console.log("eeeeee",eeeeee );

    // var condition = {
    //   where: {
    //     [Op.and]: [
    //       {
    //         org_id: org_id,
    //       },
    //     ],
    //   },
    // };

    // const user = await db[req.params.document].findOne(condition);
    // const user = await db[req.params.document].findOne({
    //   where: {
    //     org_id: newOrg,
    //   }
    // });
    const user123 = await db['client_subscription'].findOne({
      where: {
          [Op.or]: [
              {
                  org_id: req.body.org_id,
              },
          ],
      },
  });
    // if (eeeeee < Moment().format('YYYY-MM-DD') || !newOrg) {
    if (eeeeee < Moment().format('YYYY-MM-DD') || !user123) {
      const data = await db['client_subscription'].create({
        org_id: req.body.org_id,
        subscription_id: req.body.subscription_id,
        paid_amount: req.body.paid_amount,
        status: req.body.status,
        start_date: req.body.start_date,
        mode_of_payment: req.body.mode_of_payment,
        transaction_id: req.body.transaction_id,
        transaction_status: req.body.transaction_status,
        transaction_time: req.body.transaction_time,
        no_of_days: req.body.no_of_days,
        status: req.body.status,
        created_by: created_by.id
      });

  
      let thisQuery = ` SELECT cs.*, sub.subscription_name as subscription_name, sub.status as subscription_status, org.organization_name as organization_name, IF(cs.mode_of_payment = 0, "Stripe", IF(cs.mode_of_payment = 1, "Razor" , "Direct Paymnet")) as payment_name FROM lz_client_subscription as cs 
      left join lz_organization as org on (cs.org_id = org.id) 
      left join lz_subscription as sub on (cs.subscription_id = sub.id) 
      where cs.status IN (1,2)
      group by cs.id
      `
      const dataAfterAdd = await db.sequelize.query(thisQuery);
      res.status(200).send({
        status:200,
        message:'Success',
        output:dataAfterAdd[0]
      });

    } else if(user123){

      let thisQuery = ` SELECT cs.*, sub.subscription_name as subscription_name, sub.status as subscription_status, org.organization_name as organization_name, IF(cs.mode_of_payment = 0, "Stripe", IF(cs.mode_of_payment = 1, "Razor" , "Direct Paymnet")) as payment_name FROM lz_client_subscription as cs 
      left join lz_organization as org on (cs.org_id = org.id) 
      left join lz_subscription as sub on (cs.subscription_id = sub.id) 
      where cs.status IN (1,2)
      group by cs.id
      `
      const dataPAE = await db.sequelize.query(thisQuery);
  
      res.status(200).send({
        status:400,
        message: "Plan already in use.",
        output:dataPAE[0]
      });
  }
 } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.updateClientSubscriptionStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;

    const data = {
      status: req.body.status,
    }

    const num = await db['client_subscription'].update(data, {
      where: { id: id },
    });
    if (num == 1) {
      
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.findAll = async (req, res) => {
  try {

    const organ_id = req.user.id
    console.log('organ_id', organ_id.org_id);

    let thisQuery = ` SELECT cs.*, sub.subscription_name as subscription_name, sub.status as subscription_status, org.organization_name as organization_name, IF(cs.mode_of_payment = 0, "Stripe", IF(cs.mode_of_payment = 1, "Razor" , "Direct Paymnet")) as payment_name FROM lz_client_subscription as cs 
    left join lz_organization as org on (cs.org_id = org.id) 
    left join lz_subscription as sub on (cs.subscription_id = sub.id) 
    where cs.status IN (1,2)
    group by cs.id
    `
    const data = await db.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};