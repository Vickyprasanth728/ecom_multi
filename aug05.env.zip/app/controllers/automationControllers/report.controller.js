const jwt = require("../../helpers/jwt");

const db = require("../../models");
const db2 = require("../../zOrganizationFile/orgModel/orgIndex.js");
const Op = db.Sequelize.Op;
var Sequelize = require('sequelize');

const bcrypt = require("bcrypt");
const saltRounds = 10;

const path = require("path");
const fs = require("fs");

const pdfkit = require('pdfkit');
const pdfdocument = new pdfkit; 

const datebetween = async (queryString) => {
    let dateBetween;
  
    if (queryString.filter_by == '' || queryString.filter_by == undefined ) {
      dateBetween = ` `
    }
    if (queryString.filter_by == 1) {
      dateBetween = ` and (DATE(c.created_at) = DATE(NOW())) `
    }
    else if (queryString.filter_by == 2) {
      dateBetween = ` and (DATE(c.created_at) = DATE(NOW())-1) `
    }
    else if (queryString.filter_by == 3) {
      dateBetween = ` and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)  `
    }
    else if (queryString.filter_by == 4) {
      dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month)) `
    }
    else if (queryString.filter_by == 5) {
      dateBetween = ` and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 month)) `
    }
    else if (queryString.filter_by == 6) {
      dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 year)) `
    }
    else if (queryString.filter_by == 7) {
      dateBetween = ` and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') `
    }
    return dateBetween;
};
exports.downloadpdf = async (req, res) => {
    try {

        let thisQuery2 = `SELECT CONCAT(first_name,' ',IFNULL(last_name, '')) as contact_name FROM lz_contacts where status = 1 `
        const data = await db2.sequelize.query(thisQuery2);
        // console.log(req.files)
        res.status(200).send({
            output: data[0],
        });
        const pdfdocument = new pdfkit;
        pdfdocument.pipe(fs.createWriteStream('transaction.pdf'));

        // let x =  data
        const obj = JSON.stringify(data);
        pdfdocument.text(obj).fontSize(25)
        console.log(obj);
        
        pdfdocument
        .scale(0.6)
        .translate(470, -380)
        .path('M 250,75 L 323,301 131,161 369,161 177,301 z')
        .fill('red', 'even-odd')
        .restore();

        pdfdocument.end();
        console.log("output", data);
    }

    catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
}
exports.monthlyReport = async (req, res) => {
  try {
    // CONTACT SOURCE
    let thisQuery1 = `SELECT COUNT(c.source) as count, so.option_value as source_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and c.source IS NOT NULL and so.option_type = 'source' and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY so.option_value `
    const data1 = await db2.sequelize.query(thisQuery1);

    // CONTACT STATUS
    let thisQuery2 = `SELECT COUNT(c.contact_status) as count, cs.option_value as source_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        WHERE c.status = 1 and c.source IS NOT NULL and cs.option_type = 'contact_status' and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY cs.option_value `
    const data2 = await db2.sequelize.query(thisQuery2);

    // TEAM WISE - CONTACT
    let thisQuery3 = `SELECT COUNT(c.id) as count, 
        count(case when c.source ='76' then 1 end) as google_ppc_count,
        count(case when c.source ='72' then 1 end) as mcube_count,
        count(case when c.source ='68' then 1 end) as facebook_count,
        CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as teamleader_name
        FROM lz_contacts as c
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_masters as so on (so.id = c.source)
        WHERE c.status = 1 and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY us.team_leader `
    const data3 = await db2.sequelize.query(thisQuery3);

    // PROPERTY NAME & CONTACT GENERATED
    let thisQuery4 = `SELECT COUNT(c.id) as count, pa.name_of_building as property_name
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        WHERE c.status = 1 and pa.name_of_building IS NOT NULL and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY pa.name_of_building `
    const data4 = await db2.sequelize.query(thisQuery4);

    // CONTACT TO LEAD CONVERSION
    let thisQuery5 = `SELECT COUNT(c.id) as count, so.option_value as source_name, COUNT(c.id) as contact_generated, COUNT(l.id) as leads_converted, COUNT(l.id) / COUNT(c.id) * 100 as conversion
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_leads as l on (l.contact_id = c.id)
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and c.source IS NOT NULL and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY so.option_value `
    const data5 = await db2.sequelize.query(thisQuery5);

    // CONTACT DROP REASON
    let x = `(select COUNT(id) as id from lz_contacts where status = 1) `
    const dataX = await db2.sequelize.query(x);
    const dx = dataX[0][0].id
    console.log('xxxxxxx', dx);

    let thisQuery6 = `SELECT COUNT(c.id) as count, dro.option_value as drop_reason_name, COUNT(dro.id) / COUNT(c.id) * 100 as conversion
        FROM lz_contacts as c
        LEFT JOIN lz_contacts as con on (con.id = c.id)
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY dro.option_value `
    const data6 = await db2.sequelize.query(thisQuery6);

    // CONTACT DROP REASON - PROJECT WISE
    let thisQuery7 = `SELECT COUNT(c.id) as count, pa.name_of_building as property_name, dro.option_value as drop_reason_name
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY pa.name_of_building `
    const data7 = await db2.sequelize.query(thisQuery7);

    // CONTACT DROP REASON - SOURCE WISE
    let thisQuery8 = `SELECT COUNT(c.id) as count, so.option_value as source_name, dro.option_value as drop_reason_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY so.option_value `
    const data8 = await db2.sequelize.query(thisQuery8);

    // LEAD LOST REASON
    let thisQuery9 = `SELECT COUNT(l.id) as count, ls.option_value as lost_reason_name
        FROM lz_leads as l
        LEFT JOIN lz_masters as ls on (l.lead_status = ls.id)
        WHERE l.status = 1 and ls.option_type = 'lead_drop_reason' and (l.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND l.created_at < last_day(curdate() - interval 1 month))
        GROUP BY ls.option_value `
    const data9 = await db2.sequelize.query(thisQuery9);

    // TEAM-WISE CONTACT TO LEAD CONVERSION
    let thisQuery10 = `SELECT CONCAT(us.first_name,' ',IFNULL(us.last_name,'')) as team_leader_name, COUNT(c.id) as contact_generated, COUNT(l.id) as leads_converted
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_leads as l on (l.contact_id = c.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        WHERE c.status = 1 and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))
        GROUP BY us.team_leader `

    const data10 = await db2.sequelize.query(thisQuery10);

    res.status(200).send({
      teamleader: data3[0],
      tl_contact_lead: data10[0],
      lost: data9[0],
      dropSource: data8[0],
      dropProject: data7[0],
      drop: data6[0],
      lead: data5[0],
      source: data1[0],
      status: data2[0],
      project: data4[0],
    });
  }

  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
}
exports.weeklyReport = async (req, res) => {
  try {
    // CONTACT SOURCE
    let thisQuery1 = `SELECT COUNT(c.source) as count, so.option_value as source_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and c.source IS NOT NULL and so.option_type = 'source' and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY so.option_value `
    const data1 = await db2.sequelize.query(thisQuery1);

    // CONTACT STATUS
    let thisQuery2 = `SELECT COUNT(c.contact_status) as count, cs.option_value as source_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        WHERE c.status = 1 and c.source IS NOT NULL and cs.option_type = 'contact_status' and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY cs.option_value `
    const data2 = await db2.sequelize.query(thisQuery2);

    // TEAM WISE - CONTACT
    let thisQuery3 = `SELECT COUNT(c.id) as count, 
        count(case when c.source ='76' then 1 end) as google_ppc_count,
        count(case when c.source ='72' then 1 end) as mcube_count,
        count(case when c.source ='68' then 1 end) as facebook_count,
        CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as teamleader_name
        FROM lz_contacts as c
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_masters as so on (so.id = c.source)
        WHERE c.status = 1 and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY us.team_leader `
    const data3 = await db2.sequelize.query(thisQuery3);

    // PROPERTY NAME & CONTACT GENERATED
    let thisQuery4 = `SELECT COUNT(c.id) as count, pa.name_of_building as property_name
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        WHERE c.status = 1 and pa.name_of_building IS NOT NULL and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY pa.name_of_building `
    const data4 = await db2.sequelize.query(thisQuery4);

    // CONTACT TO LEAD CONVERSION
    let thisQuery5 = `SELECT COUNT(c.id) as count, so.option_value as source_name, COUNT(c.id) as contact_generated, COUNT(l.id) as leads_converted, COUNT(l.id) / COUNT(c.id) * 100 as conversion
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_leads as l on (l.contact_id = c.id)
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and c.source IS NOT NULL and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY so.option_value `
    const data5 = await db2.sequelize.query(thisQuery5);

    // CONTACT DROP REASON
    let x = `(select COUNT(id) as id from lz_contacts where status = 1) `
    const dataX = await db2.sequelize.query(x);
    const dx = dataX[0][0].id
    console.log('xxxxxxx', dx);

    let thisQuery6 = `SELECT COUNT(c.id) as count, dro.option_value as drop_reason_name, COUNT(dro.id) / COUNT(c.id) * 100 as conversion
        FROM lz_contacts as c
        LEFT JOIN lz_contacts as con on (con.id = c.id)
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY dro.option_value `
    const data6 = await db2.sequelize.query(thisQuery6);

    // CONTACT DROP REASON - PROJECT WISE
    let thisQuery7 = `SELECT COUNT(c.id) as count, pa.name_of_building as property_name, dro.option_value as drop_reason_name
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY pa.name_of_building `
    const data7 = await db2.sequelize.query(thisQuery7);

    // CONTACT DROP REASON - SOURCE WISE
    let thisQuery8 = `SELECT COUNT(c.id) as count, so.option_value as source_name, dro.option_value as drop_reason_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY so.option_value `
    const data8 = await db2.sequelize.query(thisQuery8);

    // LEAD LOST REASON
    let thisQuery9 = `SELECT COUNT(l.id) as count, ls.option_value as lost_reason_name
        FROM lz_leads as l
        LEFT JOIN lz_masters as ls on (l.lead_status = ls.id)
        WHERE l.status = 1 and ls.option_type = 'lead_drop_reason' and (l.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND l.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY ls.option_value `
    const data9 = await db2.sequelize.query(thisQuery9);

    // TEAM-WISE CONTACT TO LEAD CONVERSION
    let thisQuery10 = `SELECT CONCAT(us.first_name,' ',IFNULL(us.last_name,'')) as team_leader_name, COUNT(c.id) as contact_generated, COUNT(l.id) as leads_converted
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_leads as l on (l.contact_id = c.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        WHERE c.status = 1 and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)
        GROUP BY us.team_leader `

    const data10 = await db2.sequelize.query(thisQuery10);

    res.status(200).send({
      teamleader: data3[0],
      tl_contact_lead: data10[0],
      lost: data9[0],
      dropSource: data8[0],
      dropProject: data7[0],
      drop: data6[0],
      lead: data5[0],
      source: data1[0],
      status: data2[0],
      project: data4[0],
    });
  }

  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
}
exports.dailyReport = async (req, res) => {
  try {
    // CONTACT SOURCE
    let thisQuery1 = `SELECT COUNT(c.source) as count, so.option_value as source_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and c.source IS NOT NULL and so.option_type = 'source' and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY so.option_value `
    const data1 = await db2.sequelize.query(thisQuery1);

    // CONTACT STATUS
    let thisQuery2 = `SELECT COUNT(c.contact_status) as count, cs.option_value as source_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        WHERE c.status = 1 and c.source IS NOT NULL and cs.option_type = 'contact_status' and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY cs.option_value `
    const data2 = await db2.sequelize.query(thisQuery2);

    // TEAM WISE - CONTACT
    let thisQuery3 = `SELECT COUNT(c.id) as count, 
        count(case when c.source ='76' then 1 end) as google_ppc_count,
        count(case when c.source ='72' then 1 end) as mcube_count,
        count(case when c.source ='68' then 1 end) as facebook_count,
        CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as teamleader_name
        FROM lz_contacts as c
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_masters as so on (so.id = c.source)
        WHERE c.status = 1 and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY us.team_leader `
    const data3 = await db2.sequelize.query(thisQuery3);

    // PROPERTY NAME & CONTACT GENERATED
    let thisQuery4 = `SELECT COUNT(c.id) as count, pa.name_of_building as property_name
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as cs on (c.contact_status = cs.id)
        WHERE c.status = 1 and pa.name_of_building IS NOT NULL and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY pa.name_of_building `
    const data4 = await db2.sequelize.query(thisQuery4);

    // CONTACT TO LEAD CONVERSION
    let thisQuery5 = `SELECT COUNT(c.id) as count, so.option_value as source_name, COUNT(c.id) as contact_generated, COUNT(l.id) as leads_converted, COUNT(l.id) / COUNT(c.id) * 100 as conversion
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_leads as l on (l.contact_id = c.id)
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and c.source IS NOT NULL and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY so.option_value `
    const data5 = await db2.sequelize.query(thisQuery5);

    // CONTACT DROP REASON
    let x = `(select COUNT(id) as id from lz_contacts where status = 1) `
    const dataX = await db2.sequelize.query(x);
    const dx = dataX[0][0].id
    console.log('xxxxxxx', dx);

    let thisQuery6 = `SELECT COUNT(c.id) as count, dro.option_value as drop_reason_name, COUNT(dro.id) / COUNT(c.id) * 100 as conversion
        FROM lz_contacts as c
        LEFT JOIN lz_contacts as con on (con.id = c.id)
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY dro.option_value `
    const data6 = await db2.sequelize.query(thisQuery6);

    // CONTACT DROP REASON - PROJECT WISE
    let thisQuery7 = `SELECT COUNT(c.id) as count, pa.name_of_building as property_name, dro.option_value as drop_reason_name
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY pa.name_of_building `
    const data7 = await db2.sequelize.query(thisQuery7);

    // CONTACT DROP REASON - SOURCE WISE
    let thisQuery8 = `SELECT COUNT(c.id) as count, so.option_value as source_name, dro.option_value as drop_reason_name
        FROM lz_contacts as c
        LEFT JOIN lz_masters as dro on (c.contact_status = dro.id)
        LEFT JOIN lz_masters as so on (c.source = so.id)
        WHERE c.status = 1 and dro.option_type = 'lead_drop_reason' and (DATE(c.created_at) = DATE(NOW()))
        GROUP BY so.option_value `
    const data8 = await db2.sequelize.query(thisQuery8);

    // LEAD LOST REASON
    let thisQuery9 = `SELECT COUNT(l.id) as count, ls.option_value as lost_reason_name
        FROM lz_leads as l
        LEFT JOIN lz_masters as ls on (l.lead_status = ls.id)
        WHERE l.status = 1 and ls.option_type = 'lead_drop_reason' and (DATE(l.created_at) = DATE(NOW())) 
        GROUP BY ls.option_value `
    const data9 = await db2.sequelize.query(thisQuery9);

    // TEAM-WISE CONTACT TO LEAD CONVERSION
    let thisQuery10 = `SELECT CONCAT(us.first_name,' ',IFNULL(us.last_name,'')) as team_leader_name, COUNT(c.id) as contact_generated, COUNT(l.id) as leads_converted
        FROM lz_contacts as c
        LEFT JOIN lz_properties as p on (p.id = c.property_id)
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_leads as l on (l.contact_id = c.id)
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        WHERE c.status = 1 and (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) 
        GROUP BY us.team_leader `

    const data10 = await db2.sequelize.query(thisQuery10);

    res.status(200).send({
      tl_contact_lead: data10[0],
      teamleader: data3[0],
      lost: data9[0],
      dropSource: data8[0],
      dropProject: data7[0],
      drop: data6[0],
      lead: data5[0],
      source: data1[0],
      status: data2[0],
      project: data4[0],
    });
  }

  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
}