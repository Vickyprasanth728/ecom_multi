const db = require("../../models");
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const currencyData = await db['currency'].findOne({
      where: {status:1, name:`${req.body.name}`},
      attributes:['name','symbol']
    });
    console.log("currencyData", currencyData);
    const executives = currencyData?.dataValues ? currencyData?.dataValues.name : 0

    if (executives !== 0) {
      res.status(200).send({
        status:400,
        message: "Currency Already Exists.",
      });
    } else {
    const data = await db['currency'].create({
      name: req.body.name,
      symbol: req.body.symbol,
      created_by: created_by.id
    });
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findAll = async (req, res) => {
  try {
    var condition = {
      where: {status:1},
      order: [['id', 'ASC']], // ASC, DESC
      attributes:['id','name','symbol'],
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db[req.params.document].findAll(condition);
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findOne = async (req, res) => {
  try {
    const id = req.params.id;

    var condition = {
      where:{
        status:1,
        id:id
      },
      attributes:['id','name','symbol'],
    };
    const data = await db[req.params.document].findByPk(id, condition);
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const countryID = await db['currency'].findOne({
      where: {id: id},
    });
    const countryData = countryID?.dataValues ? countryID?.dataValues.id : 0
    console.log("countryData", countryData);

    const countryCheck = await db['currency'].findOne({
      where: {
        id: {
          [Op.ne]: countryData
        },
        name:`${req.body.name}`,
      },
      attributes:['name']
    });
    const checkData = countryCheck?.dataValues ? countryCheck?.dataValues.id : 0

    if (checkData !== 0) {
      res.status(400).send({
        status:400,
        message: "Currency Already Exists.",
      });
    } else {
    const id = req.params.id;
    const num = await db[req.params.document].update(req.body, {
      where: { id: id,status:1 },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.delete = async (req, res) => {
  const currencyData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(currencyData,{
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteAll = async (req, res) => {
  try {
    const num = await db[req.params.document].destroy({
      where: {},
      truncate: false,
    });
    res.send({
      message: `${num} has been deleted.`,
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};