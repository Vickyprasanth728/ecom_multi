const db = require("../../models");
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const languageData = await db['language'].findOne({
      where: { status: {
        [Op.in]: [1,2]
      },lang:`${req.body.lang}`},
      attributes:['lang_name', 'lang']
    });
    console.log("languageData", languageData);
    const executives = languageData?.dataValues ? languageData?.dataValues.lang : 0

    if (executives !== 0) {
      res.status(200).send({
        status:400,
        message: "Language Already Exists.",
      });
    } else {
    const data = await db[req.params.document].create({
      lang: req.body.lang,
      lang_name: req.body.lang_name,
      status: req.body.status,
      created_by: created_by.id
    });
    const langKey = req.body.lang
    let thisQuery = `select lang_key from lz_translations where lang = 'en' `
    const data1 = await db.sequelize.query(thisQuery);
    const langValue = data1[0]  

    for(let i = 0; langValue.length > i; i++) {
      const data2 = await db['translations'].create({
        lang: langKey,
        lang_key: langValue[i].lang_key,
        created_by: created_by.id
      })
    }

    // console.log("data222",data2);
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findAll = async (req, res) => {
  try {
    var condition = {
      where:{
        status: {
          [Op.in]: [1,2]
        },
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','lang','lang_name','status'],
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db[req.params.document].findAll(condition);
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findOne = async (req, res) => {
  try {
    // var condition = {
    //   where:{
    //     status:1
    //   },
    // };
    const id = req.params.id;
    const data = await db[req.params.document].findAll({
      where:{
        status: {
          [Op.in]: [1,2]
        },
      },
        attributes:['id','lang','lang_name','status']
  });
    if (data) {
      res.status(200).send({
          status:200,
          message:'Success',
          output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const LangID = await db['language'].findOne({
      where: {id: id},
      // attributes:['id']
    });
    const adminId = LangID?.dataValues ? LangID?.dataValues.id : 0
    console.log("adminId", adminId);

    const LangCheck = await db['language'].findOne({
      where: {
        id: {
          [Op.ne]: adminId
        },
        status: {
          [Op.in]: [1,2]
        },
        [Op.and]: [
          {lang: req.body.lang},
          {lang_name:req.body.lang_name},
        ],
      },
      attributes:['lang']
    });

    const executives = LangCheck?.dataValues ? LangCheck?.dataValues.id : 0

    if (executives !== 0) {
      res.status(200).send({
        status:400,
        message: "Language Already Exists.",
      });
    } else {
    const num = await db[req.params.document].update(req.body, {
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:LangID
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } 
}
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.delete = async (req, res) => {
  const langData = {
    status: 0,
  }
  const transData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db['language'].update(langData,{
      where: {id:id},
    });

    const num123 = await db['language'].findOne({
      where: {id:id},
    });
  
    const langValue = num123?.dataValues.lang

    const num1 = await db['translations'].update(transData,{
      where: {lang:`${langValue}`},
    });

    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteAll = async (req, res) => {
  try {
    const num = await db[req.params.document].destroy({
      where: {},
      truncate: false,
    });
    res.status(200).send({
      message: `${num} has been deleted.`,
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};