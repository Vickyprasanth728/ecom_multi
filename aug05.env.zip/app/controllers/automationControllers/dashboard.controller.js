const db = require("../../models");
const Op = db.Sequelize.Op;
var Sequelize = require('sequelize');
const Moment = require('moment');

// exports.findAll = async (req, res) => {
//   try {
//     var condition = {
//         where: {status:1},
//         attributes: [
//           [Sequelize.fn('COUNT', Sequelize.col('id')), 'subscription_plan_count'],
//         ]
//     };
//     var condition1 = {
//         where: {status:1},
//         attributes: [
//           [Sequelize.fn('COUNT', Sequelize.col('id')), 'org_count'],
//         ]
//     };

//     const subscriptionData = await db['subscription'].findAll(condition);
//     const orgData = await db['organization'].findAll(condition1);

//     const combinedData = {
//         org_count: orgData,
//         subscription: subscriptionData,
//         transaction_count: [],
//         revenue_count: [],
//     };

//     res.status(200).send({
//         status:200,
//         message: 'Success',
//         output:{
//             "subscription":subscriptionData[0] ? subscriptionData[0] : [],
//             "org_count":orgData[0] ? orgData[0] : [],
//             "transaction_count":combinedData.transaction_count[0] ? combinedData.transaction_count[0] : [],
//             "revenue_count":combinedData.revenue_count[0] ? combinedData.revenue_count[0] : [],
//         }
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };

exports.getDashboardCount = async (req, res) => {
  try {
    const subscriptionData = ` SELECT COUNT(id) as subscription_count FROM lz_subscription where status = 1 `
    const data = await db.sequelize.query(subscriptionData);

    const orgData = `SELECT COUNT(id) as org_count FROM lz_organization where status = 1 `
    const data2 = await db.sequelize.query(orgData);

    const transData = `SELECT COUNT(id) as transaction_count FROM lz_client_subscription where status = 1 `
    const data6 = await db.sequelize.query(transData);

    const revenueData = ` SELECT SUM(paid_amount) as revenue_amount FROM lz_client_subscription `
    const data3 = await db.sequelize.query(revenueData);

    const revenueMonthWise = ` SELECT SUM(paid_amount) as revenue_month_wise FROM lz_client_subscription as cs where MONTH(cs.created_at) = MONTH(NOW()) `
    const data4 = await db.sequelize.query(revenueMonthWise);

    const revenueAllMonthWise = `SELECT m.month, 
    IFNULL(n.count,0) count, n.revenue_paid_amount FROM 
    (SELECT 'January' AS MONTH UNION 
    SELECT 'February' AS MONTH UNION 
    SELECT 'March' AS MONTH UNION 
    SELECT 'April' AS MONTH UNION 
    SELECT 'May' AS MONTH UNION 
    SELECT 'June' AS MONTH UNION 
    SELECT 'July' AS MONTH UNION 
    SELECT 'August' AS MONTH UNION 
    SELECT 'September' AS MONTH UNION 
    SELECT 'October' AS MONTH UNION 
    SELECT 'November' AS MONTH UNION 
    SELECT 'December' AS MONTH ) m LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, COUNT(id) AS count, SUM(paid_amount) AS revenue_paid_amount FROM lz_client_subscription where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) group by monthname(created_at), month(created_at) order by month(created_at))n ON m.MONTH=n.MONTH `
    const data5 = await db.sequelize.query(revenueAllMonthWise);

    res.status(200).send({
        status:200,
        message: 'Success',
        output:{
            "subscription_count":data[0][0].subscription_count,
            "org_count":data2[0][0].org_count,
            "transactionCount":data6[0][0].transaction_count,
            "revenueAmount":data3[0][0].revenue_amount,
            "revenueMonthWise":data4[0][0].revenue_month_wise,
            "revenueAllMonthWise":data5[0]
        }
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.ClientSubscriptionDetails = async (req, res) => {
  try {

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const organanization_id = req.body.org_id

    const id = req.params.id;

    const getData123 = await db['client_subscription'].findAll({
      // where:{org_id : org_id},
      order:[['id', 'desc']],
      attributes:["id",'start_date','no_of_days','org_id']
     });

    const dateNum = getData123[0]?.dataValues.start_date
    console.log('dateNum',dateNum);

    const NoOfDays = getData123[0]?.dataValues.no_of_days
    console.log('NoOfDays',NoOfDays);

    const data = await db['client_subscription'].findAll({
      // where:{org_id : org_id},
      // order:[['id', 'desc']],
      attributes:["id",'start_date','no_of_days','org_id'],
      include: [
        {
          model: db['organization'],
          attributes: ['organization_name','website','logo'],
          where: {},
          required: false,
        },
      ],
     });

    let thisQuery = `select start_date from lz_client_subscription `
    const data1 = await db.sequelize.query(thisQuery);

    let thisQuery1 = `select no_of_days from lz_client_subscription `
    const data2 = await db.sequelize.query(thisQuery1);
    
    const dateData =  data1[0];
    const numData =  data2[0]
    console.log("start_date", dateData);
    console.log('no_of_days', numData);

    let CSWithdata = [];
    for(let i=0; data.length > i; i++) {
      const days30Expire = Moment.utc(dateData[i].start_date).add(numData[i].no_of_days - 30, "days").format('YYYY-MM-DD');
      const expire = Moment.utc(dateData[i].start_date).add(numData[i].no_of_days ,"days").format('YYYY-MM-DD');

      let dataPush = {...data[i]?.dataValues, finalDate:days30Expire, expireDate:expire};
      console.log("dataPush", dataPush);
      CSWithdata.push(dataPush);
    }

    const checkData = CSWithdata.filter(compareDate)
    function compareDate(e) {
      return Moment(e.finalDate).format('YYYY-MM-DD') < Moment().format('YYYY-MM-DD')
    }

    res.status(200).send({
        status:200,
        message: 'Success',
        output: checkData
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};