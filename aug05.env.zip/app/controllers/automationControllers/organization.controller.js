const jwt = require("../../helpers/jwt");

const db = require("../../models");
const db2 = require("../../zOrganizationFile/orgModel/orgIndex.js");
const Op = db.Sequelize.Op;
var Sequelize = require('sequelize');

const bcrypt = require("bcrypt");
const saltRounds = 10;

const path = require("path");
const fs = require("fs");

exports.createOrg = async (req, res) => {
    try {
        const created_by = req.user.id
        console.log('created_by', created_by.id);

        let water_mark = "";
        let logo = "";
      
        if (req.files.logo) {
          const extension = req.files.logo[0]["mimetype"].split('/')[1]
          logo = req.files.logo[0]["filename"] + '.' + extension
        }
        if (req.files.water_mark) {
          const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
          water_mark = req.files.water_mark[0]["filename"] + '.' + extension
        }
        const user = await db['users'].findOne({
            where: {
                [Op.or]: [
                    {
                        email: req.body.email,
                    },
                ],
            },
        });

        const OrgUser = await db['organization'].findOne({
          where: {
              [Op.or]: [
                  {
                      sub_domain_database_name: req.body.sub_domain_database_name,
                  },
              ],
          },
      });

        if (user) {
            res.status(200).send({
                status:400,
                message: "Email Already Exists.",
            });
        } 
        else if (OrgUser) {
          res.status(200).send({
            status:400,
            message: "Database Already Exists.",
        });
        }
          else {
        bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
        req.body.password = hash;
        const data = await db[req.params.document].create({
            organization_name: req.body.organization_name,
            user_name: req.body.user_name,
            password: req.body.password,
            sub_domain: req.body.sub_domain,
            sub_domain_database_name: req.body.sub_domain_database_name,
            phone_number: req.body.phone_number,
            gst_number: req.body.gst_number || null,
            cin_number: req.body.cin_number || null,
            tan_number: req.body.tan_number || null,
            pan_number: req.body.pan_number || null,
            address: req.body.address || null,
            city: req.body.city || null,
            state: req.body.state || null,
            country: req.body.country || null,
            currency: req.body.currency || null,
            website: req.body.website || null,
            facebook_url: req.body.facebook_url || null,
            linkindin_url: req.body.linkindin_url || null,
            twitter_url: req.body.twitter_url || null,
            instagram_url: req.body.instagram_url || null,
            youtube_url: req.body.youtube_url || null,
            approval: req.body.approval || 0,
            logo: logo || null,
            water_mark: water_mark || null,
            created_by: created_by.id
        });

        const orgName = req.body.organization_name;
        const userName = req.body.user_name;
        const phoneNumber = req.body.phone_number;

            let orgId = data.dataValues.id;
            console.log('orgId', orgId);

            // bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
            //     req.body.password = hash;
                const data1 = await db['users'].create({
                    email: req.body.email,
                    password: req.body.password,
                    org_id: orgId,
                    status: req.body.status,
                    created_by: created_by.id
                });

              const data11 = await db2['organization'].create({
                  organization_name: req.body.organization_name,
                  company_ref_id: orgId,
                  user_name: req.body.user_name,
                  password: req.body.password,
                  sub_domain: req.body.sub_domain,
                  sub_domain_database_name: req.body.sub_domain_database_name,
                  phone_number: req.body.phone_number,
                  gst_number: req.body.gst_number || null,
                  cin_number: req.body.cin_number || null,
                  tan_number: req.body.tan_number || null,
                  pan_number: req.body.pan_number || null,
                  address: req.body.address || null,
                  city: req.body.city || null,
                  state: req.body.state || null,
                  country: req.body.country || null,
                  currency: req.body.currency || null,
                  website: req.body.website || null,
                  facebook_url: req.body.facebook_url || null,
                  linkindin_url: req.body.linkindin_url || null,
                  twitter_url: req.body.twitter_url || null,
                  instagram_url: req.body.instagram_url || null,
                  youtube_url: req.body.youtube_url || null,
                  approval: req.body.approval || 0,
                  logo: logo || null,
                  water_mark: water_mark || null,
                  created_by: created_by.id
              });
      
              let orgId2 = data11.dataValues.id;
              console.log('orgId', orgId);
                  // bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
                  //     req.body.password = hash;
                const data12 = await db2['user'].create({
                    email: req.body.email,
                    first_name: req.body.user_name,
                    password: req.body.password,
                    org_id: orgId,
                    status: req.body.status,
                    created_by: created_by.id
                });

                const emailName = req.body.email;
                const passwordName = req.body.password;

                const userID = data12.dataValues.id;

                const data111 = await db2['usersPersonal'].create({
                  user_id: userID,
                })
                const data222 = await db2['usersProfessional'].create({
                  user_id: userID,
                })
                const data333 = await db2['usersFinance'].create({
                  user_id: userID,
                })
                const data444 = await db2['usersGoals'].create({
                  user_id: userID,
                })

        let orgID = data.dataValues.id;

        if (req.files.water_mark) {
            const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgID}`, water_mark);
            const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgID}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully moved the water_mark image!")
              }
            });
          }
                
        if (req.files.logo) {
            const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgID}`, logo);
  
            const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgID}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully Logo Uploaded !")
              }
            });
          }
          var condition12 = {
            where:{
              status:1
            },
            order: [['id', 'DESC']],
            attributes: {exclude: ['createdAt','updatedAt','created_by','deleted_by']},
            include: [
              {
                model: db["users"],
                attributes: ["email"],
                where: {},
                as:"user",
                required: false,
              },
              {
                model: db["city"],
                attributes: ['id',"name"],
                where: {},
                as:"city_name",
                required: false,
              },
              {
                model: db["state"],
                attributes: ['id',"name"],
                where: {},
                as:"state_name",
                required: false,
              },
              {
                model: db["country"],
                attributes: ['id',"name"],
                where: {},
                as:"country_name",
                required: false,
              },
              {
                model: db["currency"],
                attributes: ['id',"name"],
                where: {},
                as:"currency_name",
                required: false,
              },
            ]
          };

          try {

          const dbName = req.body.sub_domain_database_name;
          const sequelize = new Sequelize('new_listez_db', 'root', "", {
            host: 'localhost',
            dialect: 'mysql'
          });
          await sequelize.query(`CREATE DATABASE ${dbName}`);

          const dynamicSequelize = new Sequelize(dbName, 'root', "", {
            host: 'localhost',
            dialect: 'mysql'
          });

          const dbO = {};

          dbO.Sequelize = Sequelize;
          dbO.sequelize = dynamicSequelize;

          const orgRoles = require('../../zOrganizationFile/orgModel/orgRoles.model')(dynamicSequelize, Sequelize);
          const organization = require("../../zOrganizationFile/orgModel/organization.model.js")(dynamicSequelize, Sequelize);
          const orgUser = require("../../zOrganizationFile/orgModel/orgUser.model.js")(dynamicSequelize, Sequelize);
          const usersPersonal = require("../../zOrganizationFile/orgModel/orgUsersPersonal.model.js")(dynamicSequelize, Sequelize);
          const usersProfessional = require("../../zOrganizationFile/orgModel/orgUsersProfessional.js")(dynamicSequelize, Sequelize);
          const usersFinance = require("../../zOrganizationFile/orgModel/orgUsersFinance.model.js")(dynamicSequelize, Sequelize);
          const usersGoals = require("../../zOrganizationFile/orgModel/orgUsersGoals.model.js")(dynamicSequelize, Sequelize);
          const logoutTimeline = require("../../zOrganizationFile/orgModel/orgUserTimline.model.js")(dynamicSequelize, Sequelize);

          const attendance = require("../../zOrganizationFile/orgModel/orgAttendance.model.js")(dynamicSequelize, Sequelize);
          const auto_assign = require("../../zOrganizationFile/orgModel/orgAutoContactAssign.model.js")(dynamicSequelize, Sequelize);
          const branch = require("../../zOrganizationFile/orgModel/orgBranch.model.js")(dynamicSequelize, Sequelize);
          const bs = require("../../zOrganizationFile/orgModel/orgBusinessSettings.model.js")(dynamicSequelize, Sequelize);
          const contacts = require("../../zOrganizationFile/orgModel/orgContact.model.js")(dynamicSequelize, Sequelize);
          const contactAddress = require("../../zOrganizationFile/orgModel/orgContactAddress.model.js")(dynamicSequelize, Sequelize);
          const contactDetails = require("../../zOrganizationFile/orgModel/orgContactDetails.model.js")(dynamicSequelize, Sequelize);
          const contactDocuments = require("../../zOrganizationFile/orgModel/orgContactdocuments.model.js")(dynamicSequelize, Sequelize);
          const contactFilter = require("../../zOrganizationFile/orgModel/orgContactFilter.model.js")(dynamicSequelize, Sequelize);
          const contactSettings = require("../../zOrganizationFile/orgModel/orgContactSettings.model.js")(dynamicSequelize, Sequelize);
          const contactSettingMembers = require("../../zOrganizationFile/orgModel/orgContactSettingsMembers.model.js")(dynamicSequelize, Sequelize);
          const emailSettings = require("../../zOrganizationFile/orgModel/emailSettings.model.js")(dynamicSequelize, Sequelize);
          const expenses = require("../../zOrganizationFile/orgModel/orgExpenses.model.js")(dynamicSequelize, Sequelize);
          const expenseDetails = require("../../zOrganizationFile/orgModel/orgExpensedetails.model.js")(dynamicSequelize, Sequelize);
          const fileUploads = require("../../zOrganizationFile/orgModel/orgFileUploads.model.js")(dynamicSequelize, Sequelize);
          const financeCashback = require("../../zOrganizationFile/orgModel/orgFinanceCashback.model.js")(dynamicSequelize, Sequelize);
          const financeFeeConfirmation = require("../../zOrganizationFile/orgModel/orgFinanceFeeConfirmation.model.js")(dynamicSequelize, Sequelize);
          const financeIncentives = require("../../zOrganizationFile/orgModel/orgFinanceFeeConfirmation.model.js")(dynamicSequelize, Sequelize);
          const financeInvoice = require("../../zOrganizationFile/orgModel/orgFinanceInvoice.model.js")(dynamicSequelize, Sequelize);
          const financeProInvoice = require("../../zOrganizationFile/orgModel/orgFinanceProInvoice.model.js")(dynamicSequelize, Sequelize);
          const financeInvoiceCollection = require("../../zOrganizationFile/orgModel/orgFinanceInvoiceCollection.model.js")(dynamicSequelize, Sequelize);
          const leads = require("../../zOrganizationFile/orgModel/orgLead.model.js")(dynamicSequelize, Sequelize);
          const leadRequirement = require("../../zOrganizationFile/orgModel/orgLeadsRequirement.model.js")(dynamicSequelize, Sequelize);
          const leadfilter = require("../../zOrganizationFile/orgModel/orgLeadFilter.model.js")(dynamicSequelize, Sequelize);
          const logs = require("../../zOrganizationFile/orgModel/orgLogs.model.js")(dynamicSequelize, Sequelize);
          // const mailTemplate = require("../../zOrganizationFile/orgModel/emailSettings.model.js")(dynamicSequelize, Sequelize);
          const masters = require("../../zOrganizationFile/orgModel/orgMaster.model.js")(dynamicSequelize, Sequelize);
          const notes = require("../../zOrganizationFile/orgModel/orgNotes.model.js")(dynamicSequelize, Sequelize);
          const properties = require("../../zOrganizationFile/orgModel/orgProperty.model.js")(dynamicSequelize, Sequelize);
          const propertyAddress = require("../../zOrganizationFile/orgModel/orgPropertyAddress.model.js")(dynamicSequelize, Sequelize);
          const propertyResidentials = require("../../zOrganizationFile/orgModel/orgPropertyResidentials.js")(dynamicSequelize, Sequelize);
          const propertyfilter = require("../../zOrganizationFile/orgModel/orgPropertyFilter.js")(dynamicSequelize, Sequelize);
          const rolePermissions = require("../../zOrganizationFile/orgModel/orgRolePermissions.model.js")(dynamicSequelize, Sequelize);
          const source = require("../../zOrganizationFile/orgModel/orgSource.model.js")(dynamicSequelize, Sequelize);
          const tasks = require("../../zOrganizationFile/orgModel/orgTasks.model.js")(dynamicSequelize, Sequelize);
          const taskFilter = require("../../zOrganizationFile/orgModel/orgTasksFilter.model.js")(dynamicSequelize, Sequelize);
          const teams = require("../../zOrganizationFile/orgModel/orgTeam.model.js")(dynamicSequelize, Sequelize);
          const template = require("../../zOrganizationFile/orgModel/orgTemplate.model.js")(dynamicSequelize, Sequelize);
          const themeSettings = require("../../zOrganizationFile/orgModel/OrgTheme.model.js")(dynamicSequelize, Sequelize);
          const transaction = require("../../zOrganizationFile/orgModel/orgTransaction.model.js")(dynamicSequelize, Sequelize);
          const transactionBrokerageDetails = require("../../zOrganizationFile/orgModel/orgTransactionBrokerageDetails.model.js")(dynamicSequelize, Sequelize);
          const transactionInvoicingDetails = require("../../zOrganizationFile/orgModel/orgTransactionInvoicingDetails.model.js")(dynamicSequelize, Sequelize);
          const transactionFilter = require("../../zOrganizationFile/orgModel/orgTransactionFilter.model.js")(dynamicSequelize, Sequelize);
          
          await dynamicSequelize.sync({ force: false });
          console.log('Table created successfully.', dbName);

          let thisQuery = ` INSERT INTO lz_organization (organization_name, company_ref_id, user_name,phone_number) VALUES ('${orgName}','${orgID}','${userName}','${phoneNumber}')`
          const orgData = await dbO.sequelize?.query(thisQuery);
          
          let thisQuery1 = ` INSERT INTO lz_user (org_id,email,password) VALUES ('${orgID}','${emailName}','${passwordName}')`
          const userData = await dbO.sequelize?.query(thisQuery1);

          console.log("orgData", orgData);
          console.log("userData", userData);

          } catch (error) {
            console.error('Error creating table:', error);
          }
    
        const orgData = await db[req.params.document].findAll(condition12);

            res.status(200).send({
                status: 200,
                message: 'Success',
                output: orgData
            });
            // })
        })
    }

    } catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.findAll = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      order: [['updatedAt', 'DESC']],
      attributes: {exclude: ['created_by','deleted_by']},
      include: [
        {
          model: db["users"],
          attributes: ["email"],
          where: {},
          as:"user",
          required: false,
        },
        {
          model: db["client_subscription"],
          attributes: {exclude: ['createdAt','updatedAt','created_by']},
          where: {},
          as:"client_subscription",
          required: false,
        },
        {
          model: db["city"],
          attributes: ['id',"name"],
          where: {},
          as:"city_name",
          required: false,
        },
        {
          model: db["state"],
          attributes: ['id',"name"],
          where: {},
          as:"state_name",
          required: false,
        },
        {
          model: db["country"],
          attributes: ['id',"name"],
          where: {},
          as:"country_name",
          required: false,
        },
        {
          model: db["currency"],
          attributes: ['id',"name"],
          where: {},
          as:"currency_name",
          required: false,
        },
      ],
      // offset :parseInt(req.query.offset) || 0,
      // limit: parseInt(req.query.limit) || 12
      
      offset : parseInt(req.query.offset) || 0,
      // limit : ( offset == 0 ? parseInt(req.query.limit || 12) ? offset == NaN : parseInt(req.query.limit || 1000000000000000) : parseInt(req.query.limit || 1000000000000000))
      limit : (req.query.offset ? 12 : null)

      // upcoming2 : ( offset == 0 ? [] : null) ?? limit
    };
    var offset = parseInt(req.query.offset);
    console.log("offsetttt", offset);
    // var limit = parseInt(req.query.limit) || 12;

    // const upcoming2 = ( offset == 0 ? [] : null) ?? limit

    // var offset = parseInt(req.query.offset);
    // var limit = parseInt(req.query.limit) || 12;

    // if (offset >= 0 && limit <= 0) {
    //   condition.offset = offset;
    //   condition.limit = limit;
    // }
    
    var condition1 = {
        where:{
          status:1
        },
        order: [['id', 'DESC']],
    };

    const data = await db[req.params.document].findAll(condition);
    const data2 = await db[req.params.document].findAll({
      where:{status:1},
      attributes: [[Sequelize.fn('COUNT', Sequelize.col('id')), 'organization_count']],
    });
    const users = await db['users'].findAll(condition1);

    const org_count = data2[0]?.dataValues.organization_count
    console.log("org_count", org_count);

    res.status(200).send({
        status:200,
        message: 'Success',
        count:org_count,
        output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findOne = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      attributes: {exclude: ['createdAt','updatedAt','created_by','deleted_by']},
    //   attributes:['id']
    include: [
      {
        model: db["users"],
        attributes: ["email"],
        where: {},
        as:"user",
        required: false,
      },
      {
        model: db["client_subscription"],
        attributes: {exclude: ['createdAt','updatedAt','created_by']},
        where: {},
        as:"client_subscription",
        required: false,
      },
      {
        model: db["city"],
        attributes: ['id',"name"],
        where: {},
        as:"city_name",
        required: false,
      },
      {
        model: db["state"],
        attributes: ['id',"name"],
        where: {},
        as:"state_name",
        required: false,
      },
      {
        model: db["country"],
        attributes: ['id',"name"],
        where: {},
        as:"country_name",
        required: false,
      },
      {
        model: db["currency"],
        attributes: ['id',"name"],
        where: {},
        as:"currency_name",
        required: false,
      },
    ]
    };
    const id = req.params.id;
    const data = await db[req.params.document].findByPk(id,condition);
    if (data) {
      res.status(200).send({
          status:200,
          message: 'Success',
          output:data
        });
    } else {
      res.status(200).send({
        status: 404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateOrgCheck = async (req, res) => {
    try {
        const id = req.params.id;
        // const email = `${req.body.email}`;
        const user = await db['users'].findOne({
            where: { id: id },
            // attributes:['id']
        });
        console.log("userrrrr", user);
        const adminId = user?.dataValues ? user?.dataValues.id : 0
        console.log("adminId", adminId);

        const users = await db['users'].findOne({
            // where: { email:`${req.body.email}`,id : `${adminId}`},
            where: {
                id: {
                    [Op.ne]: adminId
                },
                email: `${req.body.email}`,
            },

            attributes: ['id', "email"]
        });
        console.log("userssss", users);

        const executives = users?.dataValues ? users?.dataValues.id : 0
        console.log("executivesssss", executives);

        if (executives !== 0) {
            res.status(200).send({
                status:400,
                message: "Email already in use.",
            });
        } else { 

            let water_mark = "";
            let logo = "";

            if (req.files.logo) {
                const extension = req.files.logo[0]["mimetype"].split('/')[1]
                logo = req.files.logo[0]["filename"] + '.' + extension
            }
            if (req.files.water_mark) {
                const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
                water_mark = req.files.water_mark[0]["filename"] + '.' + extension
            }
            bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
                req.body.password = hash;
                const data = {
                    organization_name: req.body.organization_name,
                    user_name: req.body.user_name,
                    password: req.body.password,
                    sub_domain: req.body.sub_domain,
                    sub_domain_database_name: req.body.sub_domain_database_name,
                    phone_number: req.body.phone_number,
                    gst_number: req.body.gst_number,
                    cin_number: req.body.cin_number,
                    tan_number: req.body.tan_number,
                    pan_number: req.body.pan_number,
                    address: req.body.address,
                    city: req.body.city,
                    state: req.body.state,
                    country: req.body.country,
                    currency: req.body.currency,
                    website: req.body.website,
                    facebook_url: req.body.facebook_url,
                    linkindin_url: req.body.linkindin_url,
                    twitter_url: req.body.twitter_url,
                    instagram_url: req.body.instagram_url,
                    youtube_url: req.body.youtube_url,
                    approval: req.body.approval || 0,
                    logo: logo,
                    water_mark: water_mark,
                };

                let orgId = req.params.id
                console.log('orgIdddd',orgId);
                const num = await db[req.params.document].update(data, {
                    where: { id: id },
                });
                const num1 = await db2[req.params.document].update(data, {
                    where: { company_ref_id: id },
                });
                if (num == 1 && num1 == 1) {

                    // let orgID = data.dataValues.id;

                    if (req.files.water_mark) {
                        const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
                        const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgId}`, water_mark);
                        const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgId}`
                        fs.mkdirSync(baseUrl, { recursive: true })
                        fs.rename(currentPath, destinationPath, function (err) {
                          if (err) {
                            throw err
                          } else {
                            console.log("Successfully moved the water_mark image!")
                          }
                        });
                      }
                            
                    if (req.files.logo) {
                        const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
                        const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgId}`, logo);
              
                        const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgId}`
                        fs.mkdirSync(baseUrl, { recursive: true })
                        fs.rename(currentPath, destinationPath, function (err) {
                          if (err) {
                            throw err
                          } else {
                            console.log("Successfully Logo Uploaded !")
                          }
                        });
                      }
                    const data1 = {
                        email: req.body.email,
                        password: req.body.password,
                        // org_id: orgId,
                    };

                    const num = await db['users'].update(data1, {
                        where: { org_id: orgId },
                    });

                    var condition12 = {
                      where:{
                        status:1
                      },
                      order: [['id', 'DESC']],
                      attributes: {exclude: ['createdAt','updatedAt','created_by','deleted_by']},
                      include: [
                        {
                          model: db["users"],
                          attributes: ["email"],
                          where: {},
                          as:"user",
                          required: false,
                        },
                        {
                          model: db["city"],
                          attributes: ['id',"name"],
                          where: {},
                          as:"city_name",
                          required: false,
                        },
                        {
                          model: db["state"],
                          attributes: ['id',"name"],
                          where: {},
                          as:"state_name",
                          required: false,
                        },
                        {
                          model: db["country"],
                          attributes: ['id',"name"],
                          where: {},
                          as:"country_name",
                          required: false,
                        },
                        {
                          model: db["currency"],
                          attributes: ['id',"name"],
                          where: {},
                          as:"currency_name",
                          required: false,
                        },
                      ]
                      };
                
                    const orgData = await db[req.params.document].findAll(condition12);

                    res.status(200).send({
                        status:200,
                        message: "Updated successfully.",
                        output: orgData,
                    });
                } else {
                    res.status(200).send({
                        status:404,
                        message: `Cannot update with id : ${id}.`
                    });
                }
            })
        }
    }
    catch (error) {
        res.status(500).send({
            message: error.message,
        });
    }
};
exports.delete = async (req, res) => {
  const orgData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(orgData,{
      where: { id: id },
    });
    if (num == 1) {
        var condition12 = {
          where:{
            status:1
          },
          order: [['id', 'DESC']],
          attributes: {exclude: ['createdAt','updatedAt','created_by','deleted_by']},
          include: [
            {
              model: db["users"],
              attributes: ["email"],
              where: {},
              as:"user",
              required: false,
            },
            {
              model: db["city"],
              attributes: ['id',"name"],
              where: {},
              as:"city_name",
              required: false,
            },
            {
              model: db["state"],
              attributes: ['id',"name"],
              where: {},
              as:"state_name",
              required: false,
            },
            {
              model: db["country"],
              attributes: ['id',"name"],
              where: {},
              as:"country_name",
              required: false,
            },
            {
              model: db["currency"],
              attributes: ['id',"name"],
              where: {},
              as:"currency_name",
              required: false,
            },
          ]
          };
    
        const orgData = await db[req.params.document].findAll(condition12);

      res.status(200).send({
        status: 200,
        message: "Deleted successfully!",
        output:orgData
      });
    } else {
      res.status(200).send({
        status: 404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateApproval = async (req, res) => {
  try {
    const id = req.params.id;

    const orgData = {
      approval: req.body.approval,
    }
    const num = await db[req.params.document].update(orgData, {
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getOrgDropdown = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

      const dataFromCity = await  await db['city'].findAll({where:{status:1}, attributes:['id','country_id','state_id','name','status']});
      const dataFromState = await  await db['state'].findAll({where:{status:1}, attributes:['id','country_id','name','status']});
      const dataFromCountry = await  await db['country'].findAll({where:{status:1}, attributes:['id','name','status']});
      const dataFromCurrency = await  await db['currency'].findAll({where:{status:1}, attributes:['id','name','symbol','status']});

      const combinedData = {
          city: dataFromCity,
          state: dataFromState,
          country: dataFromCountry,
          currency: dataFromCurrency,
      };
      res.status(200).send({
          message: "Organization dropdown get data",
          status: 200,
          output: combinedData
      })
  }
  catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal Server Error' });
  }
};

exports.updateOrgExist = async (req, res) => {
  try {
    const id = req.params.id;
    // const email = `${req.body.email}`;
    const user = await db['users'].findOne({
      where: { id: id },
      // attributes:['id']
    });
    console.log("userrrrr", user);
    const adminId = user?.dataValues ? user?.dataValues.id : 0
    console.log("adminId", adminId);

    const users = await db['users'].findOne({
      // where: { email:`${req.body.email}`,id : `${adminId}`},
      where: {
        id: {
          [Op.ne]: adminId
        },
        email: `${req.body.email}`,
      },

      attributes: ['id', "email"]
    });
    console.log("userssss", users);

    const executives = users?.dataValues ? users?.dataValues.id : 0
    console.log("executivesssss", executives);

    if (executives !== 0) {
      res.status(200).send({
        status: 400,
        message: "Email already in use.",
      });
    } else {
      if (adminId == 1) {
        let water_mark = "";
        let logo = "";

        if (req.files.logo) {
          const extension = req.files.logo[0]["mimetype"].split('/')[1]
          logo = req.files.logo[0]["filename"] + '.' + extension
        }
        if (req.files.water_mark) {
          const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
          water_mark = req.files.water_mark[0]["filename"] + '.' + extension
        }
        bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
          req.body.password = hash;
          let data = {};
          if(logo && water_mark) { 
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city,
              state: req.body.state,
              country: req.body.country,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval || 0,
              logo: logo,
              water_mark: water_mark,
            };
          } else {
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city,
              state: req.body.state,
              country: req.body.country,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval || 0,
            };
          }

          let orgId = req.params.id
          console.log('orgIdddd', orgId);
          const num = await db[req.params.document].update(data, {
            where: { id: id },
          });

          if (num == 1) {

            // let orgID = data.dataValues.id;

            if (req.files.water_mark) {
              const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
              const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgId}`, water_mark);
              const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgId}`
              fs.mkdirSync(baseUrl, { recursive: true })
              fs.rename(currentPath, destinationPath, function (err) {
                if (err) {
                  throw err
                } else {
                  console.log("Successfully moved the water_mark image!")
                }
              });
            }

            if (req.files.logo) {
              const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
              const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgId}`, logo);

              const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgId}`
              fs.mkdirSync(baseUrl, { recursive: true })
              fs.rename(currentPath, destinationPath, function (err) {
                if (err) {
                  throw err
                } else {
                  console.log("Successfully Logo Uploaded !")
                }
              });
            }
            const data1 = {
              email: req.body.email,
              password: req.body.password,
              // org_id: orgId,
            };

            const num = await db['users'].update(data1, {
              where: { org_id: orgId },
            });

            var condition12 = {
              where: {
                status: 1
              },
              order: [['id', 'DESC']],
              attributes: { exclude: ['createdAt', 'updatedAt', 'created_by', 'deleted_by'] },
              include: [
                {
                  model: db["users"],
                  attributes: ["email"],
                  where: {},
                  as: "user",
                  required: false,
                },
                {
                  model: db["city"],
                  attributes: ['id', "name"],
                  where: {},
                  as: "city_name",
                  required: false,
                },
                {
                  model: db["state"],
                  attributes: ['id', "name"],
                  where: {},
                  as: "state_name",
                  required: false,
                },
                {
                  model: db["country"],
                  attributes: ['id', "name"],
                  where: {},
                  as: "country_name",
                  required: false,
                },
                {
                  model: db["currency"],
                  attributes: ['id', "name"],
                  where: {},
                  as: "currency_name",
                  required: false,
                },
              ]
            };

            const orgData = await db[req.params.document].findAll(condition12);

            res.status(200).send({
              status: 200,
              message: "Updated successfully.",
              output: orgData,
            });
          } else {
            res.status(200).send({
              status: 404,
              message: `Cannot update with id : ${id}.`
            });
          }
        })
      }
      else {
        let water_mark = "";
        let logo = "";

        if (req.files.logo) {
          const extension = req.files.logo[0]["mimetype"].split('/')[1]
          logo = req.files.logo[0]["filename"] + '.' + extension
        }
        if (req.files.water_mark) {
          const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
          water_mark = req.files.water_mark[0]["filename"] + '.' + extension
        }
        bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
          req.body.password = hash;
          let data = {};
          if(logo && water_mark) { 
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city,
              state: req.body.state,
              country: req.body.country,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval || 0,
              logo: logo,
              water_mark: water_mark,
            };
          } else {
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city,
              state: req.body.state,
              country: req.body.country,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval || 0,
            };
          }

          let orgId = req.params.id
          console.log('orgIdddd', orgId);
          const num = await db['organization'].update(data, {
            where: { id: id },
          });
          // const num1 = await db2['organization'].update(data, {
          //   where: {company_ref_id: id },
          // });
          if (num == 1) {

            // let orgID = data.dataValues.id;

            if (req.files.water_mark) {
              const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
              const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgId}`, water_mark);
              const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgId}`
              fs.mkdirSync(baseUrl, { recursive: true })
              fs.rename(currentPath, destinationPath, function (err) {
                if (err) {
                  throw err
                } else {
                  console.log("Successfully moved the water_mark image!")
                }
              });
            }

            if (req.files.logo) {
              const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
              const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgId}`, logo);

              const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgId}`
              fs.mkdirSync(baseUrl, { recursive: true })
              fs.rename(currentPath, destinationPath, function (err) {
                if (err) {
                  throw err
                } else {
                  console.log("Successfully Logo Uploaded !")
                }
              });
            }
            const data1 = {
              email: req.body.email,
              password: req.body.password,
              // org_id: orgId,
            };

            // const num = await db['users'].update(data1, {
            //   where: { org_id: orgId },
            // });

            // var condition12 = {
            //   where: {
            //     status: 1
            //   },
            //   order: [['id', 'DESC']],
            //   attributes: { exclude: ['createdAt', 'updatedAt', 'created_by', 'deleted_by'] },
            //   include: [
            //     {
            //       model: db["users"],
            //       attributes: ["email"],
            //       where: {},
            //       as: "user",
            //       required: false,
            //     },
            //     {
            //       model: db["city"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "city_name",
            //       required: false,
            //     },
            //     {
            //       model: db["state"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "state_name",
            //       required: false,
            //     },
            //     {
            //       model: db["country"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "country_name",
            //       required: false,
            //     },
            //     {
            //       model: db["currency"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "currency_name",
            //       required: false,
            //     },
            //   ]
            // };

            // const orgData = await db[req.params.document].findAll(condition12);

            res.status(200).send({
              status: 200,
              message: "Updated successfully.",
              output: data,
            });
          } else {
            res.status(200).send({
              status: 404,
              message: `Cannot update with id : ${id}.`
            });
          }
        })
      }

    }
  }
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.updateOrgTwoUpdate = async (req, res) => {
  try {
    const id = req.params.id;
    // const email = `${req.body.email}`;
    const user = await db['users'].findOne({
      where: { id: id },
      // attributes:['id']
    });
    console.log("userrrrr", user);
    const adminId = user?.dataValues ? user?.dataValues.id : 0
    console.log("adminId", adminId);

    const users = await db['users'].findOne({
      // where: { email:`${req.body.email}`,id : `${adminId}`},
      where: {
        id: {
          [Op.ne]: adminId
        },
        email: `${req.body.email}`,
      },

      attributes: ['id', "email"]
    });
    console.log("userssss", users);

    const executives = users?.dataValues ? users?.dataValues.id : 0
    console.log("executivesssss", executives);

    if (executives !== 0) {
      res.status(200).send({
        status: 400,
        message: "Email already in use.",
      });
    } else {
        let water_mark = "";
        let logo = "";

        if (req.files.logo) {
          const extension = req.files.logo[0]["mimetype"].split('/')[1]
          logo = req.files.logo[0]["filename"] + '.' + extension
        }
        if (req.files.water_mark) {
          const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
          water_mark = req.files.water_mark[0]["filename"] + '.' + extension
        }
        bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
          req.body.password = hash;
          let data = {};
          if(logo) { 
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city || 0,
              state: req.body.state || 0,
              country: req.body.country || 0,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval || 0,
              logo: logo,
              // water_mark: water_mark,
            };
          }      
          else if(water_mark) { 
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city || 0,
              state: req.body.state || 0,
              country: req.body.country || 0,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval || 0,
              // logo: logo,
              water_mark: water_mark,
            };
          }else {
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city || 0,
              state: req.body.state || 0,
              country: req.body.country || 0,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval || 0,
            };
          }

          let orgId = req.params.id
          console.log('orgIdddd', orgId);
          const num = await db['organization'].update(data, {
            where: { id: id },
          });

          if (num == 1) {

            if (req.files.water_mark) {
              const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
              const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgId}`, water_mark);
              const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgId}`
              fs.mkdirSync(baseUrl, { recursive: true })
              fs.rename(currentPath, destinationPath, function (err) {
                if (err) {
                  throw err
                } else {
                  console.log("Successfully moved the water_mark image!")
                }
              });
            }

            if (req.files.logo) {
              const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
              const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgId}`, logo);

              const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgId}`
              fs.mkdirSync(baseUrl, { recursive: true })
              fs.rename(currentPath, destinationPath, function (err) {
                if (err) {
                  throw err
                } else {
                  console.log("Successfully Logo Uploaded !")
                }
              });
            }
            const data1 = {
              email: req.body.email,
              password: req.body.password,
              // org_id: orgId,
            };

            const num = await db['users'].update(data1, {
              where: { org_id: orgId },
            });

            // var condition12 = {
            //   where: {
            //     status: 1
            //   },
            //   order: [['id', 'DESC']],
            //   attributes: { exclude: ['createdAt', 'updatedAt', 'created_by', 'deleted_by'] },
            //   include: [
            //     {
            //       model: db["users"],
            //       attributes: ["email"],
            //       where: {},
            //       as: "user",
            //       required: false,
            //     },
            //     {
            //       model: db["city"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "city_name",
            //       required: false,
            //     },
            //     {
            //       model: db["state"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "state_name",
            //       required: false,
            //     },
            //     {
            //       model: db["country"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "country_name",
            //       required: false,
            //     },
            //     {
            //       model: db["currency"],
            //       attributes: ['id', "name"],
            //       where: {},
            //       as: "currency_name",
            //       required: false,
            //     },
            //   ]
            // };

            // const orgData = await db['organization'].findAll(condition12);

            const orgData = await db['organization'].findAll({
              where:{status:1}
            })

            res.status(200).send({
              status: 200,
              message: "Organization Updated successfully.",
              output: orgData,
            });
          } else {
            res.status(200).send({
              status: 404,
              message: `Cannot update with id : ${id}.`
            });
          }
      })
    }
  }
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};


exports.updateOrg = async (req, res) => {
  try {
    const id = req.params.id;
    // const email = `${req.body.email}`;
    const user = await db['users'].findOne({
        where: { id: id },
        // attributes:['id']
    });
    console.log("userrrrr", user);
    const adminId = user?.dataValues ? user?.dataValues.id : 0
    console.log("adminId", adminId);

    const users = await db['users'].findOne({
        // where: { email:`${req.body.email}`,id : `${adminId}`},
        where: {
            id: {
                [Op.ne]: adminId
            },
            email: `${req.body.email}`,
        },

        attributes: ['id', "email"]
    });
    console.log("userssss", users);

    const executives = users?.dataValues ? users?.dataValues.id : 0
    console.log("executivesssss", executives);

    if (executives !== 0) {
        res.status(200).send({
            status:400,
            message: "Email already in use.",
        });
    } else { 

        let water_mark = "";
        let logo = "";

        if (req.files.logo) {
            const extension = req.files.logo[0]["mimetype"].split('/')[1]
            logo = req.files.logo[0]["filename"] + '.' + extension
        }
        if (req.files.water_mark) {
            const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
            water_mark = req.files.water_mark[0]["filename"] + '.' + extension
        }
        bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
            req.body.password = hash;
            let data = {};
          if(logo) { 
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city || 0,
              state: req.body.state || 0,
              country: req.body.country || 0,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval,
              logo: logo,
              // water_mark: water_mark,
            };
          }      
          else if(water_mark) { 
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city || 0,
              state: req.body.state || 0,
              country: req.body.country || 0,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval,
              // logo: logo,
              water_mark: water_mark,
            };
          }else {
            data = {
              organization_name: req.body.organization_name,
              user_name: req.body.user_name,
              password: req.body.password,
              sub_domain: req.body.sub_domain,
              sub_domain_database_name: req.body.sub_domain_database_name,
              phone_number: req.body.phone_number,
              gst_number: req.body.gst_number,
              cin_number: req.body.cin_number,
              tan_number: req.body.tan_number,
              pan_number: req.body.pan_number,
              address: req.body.address,
              city: req.body.city || 0,
              state: req.body.state || 0,
              country: req.body.country || 0,
              currency: req.body.currency,
              website: req.body.website,
              facebook_url: req.body.facebook_url,
              linkindin_url: req.body.linkindin_url,
              twitter_url: req.body.twitter_url,
              instagram_url: req.body.instagram_url,
              youtube_url: req.body.youtube_url,
              approval: req.body.approval,
            };
          }

            let orgId = req.params.id
            console.log('orgIdddd',orgId);
            const num = await db['organization'].update(data, {
                where: { id: id },
            });
            // const num1 = await db2['organization'].update(data, {
            //     where: { company_ref_id: id },
            // });
            if (num == 1) {

                // let orgID = data.dataValues.id;

                if (req.files.water_mark) {
                    const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
                    const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgId}`, water_mark);
                    const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgId}`
                    fs.mkdirSync(baseUrl, { recursive: true })
                    fs.rename(currentPath, destinationPath, function (err) {
                      if (err) {
                        throw err
                      } else {
                        console.log("Successfully moved the water_mark image!")
                      }
                    });
                  }
                        
                if (req.files.logo) {
                    const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
                    const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgId}`, logo);
          
                    const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgId}`
                    fs.mkdirSync(baseUrl, { recursive: true })
                    fs.rename(currentPath, destinationPath, function (err) {
                      if (err) {
                        throw err
                      } else {
                        console.log("Successfully Logo Uploaded !")
                      }
                    });
                  }
                const data1 = {
                    email: req.body.email,
                    password: req.body.password,
                    // org_id: orgId,
                };

                const num = await db['users'].update(data1, {
                    where: { org_id: orgId },
                });

                // var condition12 = {
                //   where:{
                //     status:1
                //   },
                //   order: [['id', 'DESC']],
                //   attributes: {exclude: ['createdAt','updatedAt','created_by','deleted_by']},
                //   include: [
                //     {
                //       model: db["users"],
                //       attributes: ["email"],
                //       where: {},
                //       as:"user",
                //       required: false,
                //     },
                //     {
                //       model: db["city"],
                //       attributes: ['id',"name"],
                //       where: {},
                //       as:"city_name",
                //       required: false,
                //     },
                //     {
                //       model: db["state"],
                //       attributes: ['id',"name"],
                //       where: {},
                //       as:"state_name",
                //       required: false,
                //     },
                //     {
                //       model: db["country"],
                //       attributes: ['id',"name"],
                //       where: {},
                //       as:"country_name",
                //       required: false,
                //     },
                //     {
                //       model: db["currency"],
                //       attributes: ['id',"name"],
                //       where: {},
                //       as:"currency_name",
                //       required: false,
                //     },
                //   ]
                //   };
            
                // const orgData = await db['organization'].findAll(condition12);

                const orgData = await db['organization'].findAll({
                  where:{status:1}
                });

                res.status(200).send({
                    status:200,
                    message: "Updated successfully.",
                    output: orgData,
                });
            } else {
                res.status(200).send({
                    status:404,
                    message: `Cannot update with id : ${id}.`
                });
            }
        })
    }
}
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};




// exports.createOrg = async (req, res) => {
//   try {
//       const created_by = req.user.id
//       console.log('created_by', created_by.id);

//       let water_mark = "";
//       let logo = "";
    
//       if (req.files.logo) {
//         const extension = req.files.logo[0]["mimetype"].split('/')[1]
//         logo = req.files.logo[0]["filename"] + '.' + extension
//       }
//       if (req.files.water_mark) {
//         const extension = req.files.water_mark[0]["mimetype"].split('/')[1]
//         water_mark = req.files.water_mark[0]["filename"] + '.' + extension
//       }
//       const user = await db['users'].findOne({
//           where: {
//               [Op.or]: [
//                   {
//                       email: req.body.email,
//                   },
//               ],
//           },
//       });

//       if (user) {
//           res.status(200).send({
//               status:400,
//               message: "Email Already Exists.",
//           });
//       } else {
//       bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
//       req.body.password = hash;
//       const data = await db[req.params.document].create({
//           organization_name: req.body.organization_name,
//           user_name: req.body.user_name,
//           password: req.body.password,
//           sub_domain: req.body.sub_domain,
//           sub_domain_database_name: req.body.sub_domain_database_name,
//           phone_number: req.body.phone_number,
//           gst_number: req.body.gst_number || null,
//           cin_number: req.body.cin_number || null,
//           tan_number: req.body.tan_number || null,
//           pan_number: req.body.pan_number || null,
//           address: req.body.address || null,
//           city: req.body.city || null,
//           state: req.body.state || null,
//           country: req.body.country || null,
//           currency: req.body.currency || null,
//           website: req.body.website || null,
//           facebook_url: req.body.facebook_url || null,
//           linkindin_url: req.body.linkindin_url || null,
//           twitter_url: req.body.twitter_url || null,
//           instagram_url: req.body.instagram_url || null,
//           youtube_url: req.body.youtube_url || null,
//           approval: req.body.approval || 0,
//           logo: logo || null,
//           water_mark: water_mark || null,
//           created_by: created_by.id
//       });

//           let orgId = data.dataValues.id;
//           console.log('orgId', orgId);

//           // bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
//           //     req.body.password = hash;
//               const data1 = await db['users'].create({
//                   email: req.body.email,
//                   password: req.body.password,
//                   org_id: orgId,
//                   status: req.body.status,
//                   created_by: created_by.id
//               });

//             const data11 = await db2['organization'].create({
//                 organization_name: req.body.organization_name,
//                 company_ref_id: orgId,
//                 user_name: req.body.user_name,
//                 password: req.body.password,
//                 sub_domain: req.body.sub_domain,
//                 sub_domain_database_name: req.body.sub_domain_database_name,
//                 phone_number: req.body.phone_number,
//                 gst_number: req.body.gst_number || null,
//                 cin_number: req.body.cin_number || null,
//                 tan_number: req.body.tan_number || null,
//                 pan_number: req.body.pan_number || null,
//                 address: req.body.address || null,
//                 city: req.body.city || null,
//                 state: req.body.state || null,
//                 country: req.body.country || null,
//                 currency: req.body.currency || null,
//                 website: req.body.website || null,
//                 facebook_url: req.body.facebook_url || null,
//                 linkindin_url: req.body.linkindin_url || null,
//                 twitter_url: req.body.twitter_url || null,
//                 instagram_url: req.body.instagram_url || null,
//                 youtube_url: req.body.youtube_url || null,
//                 approval: req.body.approval || 0,
//                 logo: logo || null,
//                 water_mark: water_mark || null,
//                 created_by: created_by.id
//             });
    
//             let orgId2 = data11.dataValues.id;
//             console.log('orgId', orgId);
//                 // bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
//                 //     req.body.password = hash;
//               const data12 = await db2['user'].create({
//                   email: req.body.email,
//                   first_name: req.body.user_name,
//                   password: req.body.password,
//                   org_id: orgId,
//                   status: req.body.status,
//                   created_by: created_by.id
//               });

//               const userID = data12.dataValues.id;

//               const data111 = await db2['usersPersonal'].create({
//                 user_id: userID,
//               })
//               const data222 = await db2['usersProfessional'].create({
//                 user_id: userID,
//               })
//               const data333 = await db2['usersFinance'].create({
//                 user_id: userID,
//               })
//               const data444 = await db2['usersGoals'].create({
//                 user_id: userID,
//               })

//       let orgID = data.dataValues.id;

//       if (req.files.water_mark) {
//           const currentPath = path.join(process.cwd(), "uploads", req.files.water_mark[0]["filename"]);
//           const destinationPath = path.join(process.cwd(), "uploads/organization/water_mark/" + `${orgID}`, water_mark);
//           const baseUrl = process.cwd() + '/uploads/organization/water_mark/' + `${orgID}`
//           fs.mkdirSync(baseUrl, { recursive: true })
//           fs.rename(currentPath, destinationPath, function (err) {
//             if (err) {
//               throw err
//             } else {
//               console.log("Successfully moved the water_mark image!")
//             }
//           });
//         }
              
//       if (req.files.logo) {
//           const currentPath = path.join(process.cwd(), "uploads", req.files.logo[0]["filename"]);
//           const destinationPath = path.join(process.cwd(), "uploads/organization/logo/" + `${orgID}`, logo);

//           const baseUrl = process.cwd() + '/uploads/organization/logo/' + `${orgID}`
//           fs.mkdirSync(baseUrl, { recursive: true })
//           fs.rename(currentPath, destinationPath, function (err) {
//             if (err) {
//               throw err
//             } else {
//               console.log("Successfully Logo Uploaded !")
//             }
//           });
//         }
//         var condition12 = {
//           where:{
//             status:1
//           },
//           order: [['id', 'DESC']],
//           attributes: {exclude: ['createdAt','updatedAt','created_by','deleted_by']},
//           include: [
//             {
//               model: db["users"],
//               attributes: ["email"],
//               where: {},
//               as:"user",
//               required: false,
//             },
//             {
//               model: db["city"],
//               attributes: ['id',"name"],
//               where: {},
//               as:"city_name",
//               required: false,
//             },
//             {
//               model: db["state"],
//               attributes: ['id',"name"],
//               where: {},
//               as:"state_name",
//               required: false,
//             },
//             {
//               model: db["country"],
//               attributes: ['id',"name"],
//               where: {},
//               as:"country_name",
//               required: false,
//             },
//             {
//               model: db["currency"],
//               attributes: ['id',"name"],
//               where: {},
//               as:"currency_name",
//               required: false,
//             },
//           ]
//         };
  
//       const orgData = await db[req.params.document].findAll(condition12);

//           res.status(200).send({
//               status: 200,
//               message: 'Success',
//               output: orgData
//           });
//           // })
//       })
//   }

//   } catch (error) {
//       res.status(500).send({
//           message: error.message,
//       });
//   }
// };