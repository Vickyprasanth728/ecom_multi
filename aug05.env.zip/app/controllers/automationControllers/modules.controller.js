const db = require("../../models");
const Op = db.Sequelize.Op;

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const data = await 
    db[req.params.document].create({
      module_name: req.body.module_name,
      status: req.body.status,
      created_by: created_by.id
    });
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findAll = async (req, res) => {
    try {
      var condition = {
        where:{
          status:1
        },
        order: [['id', 'DESC']], // ASC, DESC
        attributes:['id','module_name']
      };
      var offset = parseInt(req.query.offset);
      var limit = parseInt(req.query.limit);
  
      if (offset >= 0 && limit >= 0) {
        condition.offset = offset;
        condition.limit = limit;
      }
  
      const data = await db[req.params.document].findAll(condition);
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
  };
exports.findOne = async (req, res) => {

  try {
    // var condition = {
    //   where:{
    //     status:1
    //   },
    //   attributes:['id','option_type','option_value']
    // };

    const id = req.params.id;
    const data = await db[req.params.document].findByPk(id, {
      where: {
        [Op.and]: [
          { id: id },
          { status: 1 }
        ]
      },
      attributes:['id','module_name']
    }
      );
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(req.body, {
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.delete = async (req, res) => {
  const MastersData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db[req.params.document].update(MastersData,{
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};