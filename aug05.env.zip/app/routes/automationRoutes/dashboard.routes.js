const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const dashboard = require("../../controllers/automationControllers/dashboard.controller.js");
    
    var router = require("express").Router();
  
    router.get("/count_dashboard", authentication, dashboard.getDashboardCount);
    router.get("/client_subs_details", authentication, dashboard.ClientSubscriptionDetails);

    app.use('/dashboard/',auth, router);
  };