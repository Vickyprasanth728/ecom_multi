module.exports = app => {
    const auth = require("../../middlewares/auth");
    const city = require("../../controllers/automationControllers/city.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", city.create);
  
    router.get("/get/:document", city.findAll);
  
    router.get("/edit/:document/:id", city.findOne);
  
    router.put("/update/:document/:id", city.update);
  
    router.put("/delete/:document/:id", city.delete);
  
    router.delete("/:document", city.deleteAll);
  
    app.use('/city/',auth, router);
  };
  