const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const masters = require("../../controllers/automationControllers/masters.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, masters.create);
  
    router.get("/get/:document", authentication, masters.findAll);
  
    router.get("/edit/:document/:id", authentication, masters.findOne);
  
    router.put("/update/:document/:option_type/:id", authentication, masters.update);
  
    router.put("/delete/:document/:id", authentication, masters.delete);
  
    app.use('/masters/',auth, router);
  };
  