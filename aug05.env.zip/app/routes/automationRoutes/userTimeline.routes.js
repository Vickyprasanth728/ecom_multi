const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const user_timeline = require("../../controllers/automationControllers/userTimeline.controller.js");
  
    var router = require("express").Router();
  
    router.put("/logout/:document",authentication, user_timeline.update);
  
    app.use('/user_timeline/',auth, router);
  };