const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const language = require("../../controllers/automationControllers/language.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, language.create);
  
    router.get("/get/:document", authentication, language.findAll);
  
    router.get("/edit/:document/:id", authentication, language.findOne);
  
    router.put("/update/:document/:id", authentication, language.update);
  
    router.put("/delete/:document/:id", authentication, language.delete);
  
    router.delete("/:document", authentication, language.deleteAll);
  
    app.use('/language/',auth, router);
  };
  

//   exports.create = async (req, res) => {
//     try {
//       const languageData = await db['language'].findOne({
//         where: {lang_name:`${req.body.lang_name}`},
//         attributes:['lang_name']
//       });
//       console.log("languageData", languageData);
//       const executives = languageData?.dataValues ? languageData?.dataValues.lang_name : 0
  
//       if (executives !== 0) {
//         res.status(400).send({
//           message: "Language Already Exists.",
//         });
//       } else {
//       const data = await db[req.params.document].create(req.body);
//       res.send({
//           status:200,
//           output:data
//       });
//     }} catch (error) {
//       res.status(500).send({
//         message: error.message,
//       });
//     }
//   };