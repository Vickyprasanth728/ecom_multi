module.exports = app => {
    const auth = require("../../middlewares/auth");
    const state = require("../../controllers/automationControllers/state.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", state.create);
  
    router.get("/get/:document", state.findAll);
  
    router.get("/edit/:document/:id", state.findOne);
  
    router.put("/update/:document/:id", state.update);
  
    router.put("/delete/:document/:id", state.delete);
  
    router.delete("/:document", state.deleteAll);
  
    app.use('/state/',auth, router);
  };
  