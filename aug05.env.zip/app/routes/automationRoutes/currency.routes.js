module.exports = app => {
    const auth = require("../../middlewares/auth");
    const currency = require("../../controllers/automationControllers/currency.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", currency.create);
  
    router.get("/get/:document", currency.findAll);
  
    router.get("/edit/:document/:id", currency.findOne);
  
    router.put("/update/:document/:id", currency.update);
  
    router.put("/delete/:document/:id", currency.delete);
  
    router.delete("/:document", currency.deleteAll);
  
    app.use('/currency/',auth, router);
  };
  