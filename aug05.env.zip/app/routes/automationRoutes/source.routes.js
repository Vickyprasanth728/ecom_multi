const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const source = require("../../controllers/automationControllers/source.controller.js");
    
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, source.create);
  
    router.get("/get/:document", authentication, source.findAll);
  
    router.get("/edit/:document/:id", authentication, source.findOne);
  
    router.put("/update/:document/:id", authentication, source.update);
  
    router.put("/delete/:document/:id", authentication, source.delete);
  
    app.use('/source/',auth, router);
  };
  