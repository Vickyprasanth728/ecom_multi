const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const dropdown = require("../../controllers/automationControllers/dropdown.controller.js");
  
    var router = require("express").Router();
  
    router.get("/organization_dropdown", authentication, dropdown.getOrgDropdown);
    router.get("/subscription_organization_dropdown", authentication, dropdown.getSubscriptionDropdown);
  
    app.use('/dropdown/',auth, router);
  };
  