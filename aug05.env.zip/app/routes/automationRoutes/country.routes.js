const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const country = require("../../controllers/automationControllers/country.controller.js");
    
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, country.create);
  
    router.get("/get/:document", authentication, country.findAll);
  
    router.get("/edit/:document/:id", authentication, country.findOne);
  
    router.put("/update/:document/:id", authentication, country.update);
  
    router.put("/delete/:document/:id", authentication, country.delete);
  
    router.delete("/:document", authentication, country.deleteAll);

    app.use('/country/',auth, router);
  };
  