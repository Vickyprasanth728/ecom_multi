const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth.js");
    const reports = require("../../controllers/automationControllers/report.controller.js");
  
    var router = require("express").Router();
  
    router.post("/download_pdf", authentication, reports.downloadpdf);
    // MONTHLY REPORT
    router.get("/monthly_report", authentication, reports.monthlyReport);
    // WEEKLY REPORT
    router.get("/weekly_report", authentication, reports.weeklyReport);
    // DAILY REPORT
    router.get("/daily_report", authentication, reports.dailyReport);
  
    app.use('/',auth, router);
  };
  