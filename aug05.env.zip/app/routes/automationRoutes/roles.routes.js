const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const roles = require("../../controllers/automationControllers/roles.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, roles.create);
  
    router.get("/get/:document", authentication, roles.findAll);
  
    router.get("/edit/:document/:id", authentication, roles.findOne);
  
    router.put("/update/:document/:id", authentication, roles.update);
  
    router.put("/delete/:document/:id", authentication, roles.delete);
  
    app.use('/roles/',auth, router);
  };
  