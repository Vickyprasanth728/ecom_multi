const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const modules = require("../../controllers/automationControllers/modules.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, modules.create);
  
    router.get("/get/:document", authentication, modules.findAll);
  
    router.get("/edit/:document/:id", authentication, modules.findOne);
  
    router.put("/update/:document/:id", authentication, modules.update);
  
    router.put("/delete/:document/:id", authentication, modules.delete);
  
    app.use('/modules/',auth, router);
  };
  