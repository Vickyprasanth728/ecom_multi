const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const theme = require("../../controllers/automationControllers/theme.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document",authentication, theme.create);
  
    router.get("/get/:document",authentication, theme.findAll);
  
    router.get("/edit/:document/:id",authentication, theme.findOne);
  
    router.put("/update/:document/:id",authentication, theme.update);
  
    router.put("/delete/:document/:id",authentication, theme.delete);
  
    app.use('/theme/',auth, router);
  };
  