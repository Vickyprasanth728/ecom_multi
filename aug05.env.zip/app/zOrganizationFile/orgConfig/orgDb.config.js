// module.exports = {
//     DB_HOST: "localhost",
//     DB_USER: "root",
//     DB_PASS: "",
//     DB_DATABASE: "listez_db2",
// };
const db = require("../../models");
// const authentication = require("../../middlewares/dummy.js").at;

exports.databaseAuth = (req, res, next) => {
    console.log("Config DB");
    // console.log("authentication", authentication);
  
    const org_id = 2  
    if(org_id == 2) {
      return(
        module.exports = {
          DB_HOST: "localhost",
          DB_USER: "root",
          DB_PASS: "",
          DB_DATABASE: `listez_db2`,
          // DB_DATABASE: `${authentication}`,
          smtpUserName: "134a7d7fee3891",
          smtpPassword: "f549d5fc6cae82",
          smtpHost: "smtp.mailtrap.io",
          smtpPort: "587"
        }
      )
    }
    else if(org_id == 3) {
      return(
        module.exports = {
          DB_HOST: "localhost",
          DB_USER: "root",
          DB_PASS: "",
          DB_DATABASE: `listez_db3`,
        }
      )
    }
}



    // let DBData;
    // const pop = async() => {
    //   let thisQuery = `select sub_domain_database_name from lz_organization where status = 1 and id = 74 `
    //   const data = await db.sequelize.query(thisQuery);
  
    //   DBData = data[0][0].sub_domain_database_name
    //   console.log("DBData", DBData);
      
    //   return DBData;
    // }
    // pop();
    // setTimeout(() => {
    //   console.log('pooooooooooooooooooooooopppp', DBData);
    // }, 1000)