const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

exports.create = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const sourceData = await db2['source'].findOne({
      where: {status:1 , name:`${req.body.name}`},
      attributes:['name']
    });
    console.log("sourceData", sourceData);
    const executives = sourceData?.dataValues ? sourceData?.dataValues.name : 0

    if (executives !== 0) {
      res.status(400).send({
        status:400,
        message: "Source Already Exists.",
      });
    } else {
    const data = await db2['source'].create({
      name: req.body.name,
      created_by: created_by.id
    });
    res.status(200).send({
        status:200,
        message: 'Successfully',
        output:data
    });
  } } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findAll = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      order: [['id', 'DESC']], // ASC, DESC
      attributes:['id','name']
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db2['source'].findAll(condition);
    res.status(200).send({
        status:200,
        message: 'Success',
        output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.findOne = async (req, res) => {
  try {
    const id = req.params.id;
    const data = await db2['source'].findOne({
        where:{
            status:1, id:id
          },
          attributes:['id','name']
    });
    if (data) {
      res.status(200).send({
          status:200,
          message: 'Success',
          output:data
        });
    } else {
      res.status(200).send({
        status: 404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const sourceID = await db2['source'].findOne({
      where: {id: id},
    });
    const sourceData = sourceID?.dataValues ? sourceID?.dataValues.id : 0
    console.log("sourceData", sourceData);

    const sourceCheck = await db2['source'].findOne({
      where: {
        id: {
          [Op.ne]: sourceData
        },
        name:`${req.body.name}`,
      },
      attributes:['name']
    });
    const checkData = sourceCheck?.dataValues ? sourceCheck?.dataValues.id : 0

    if (checkData !== 0) {
      res.status(400).send({
        status:400,
        message: "Source Already Exists.",
      });
    } else {
    const id = req.params.id;
    const num = await db2['source'].update(req.body, {
      where: { id: id, status:1},
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  }} catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.delete = async (req, res) => {
  const SourceData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const num = await db2['source'].update(SourceData,{
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status: 200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status: 404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};