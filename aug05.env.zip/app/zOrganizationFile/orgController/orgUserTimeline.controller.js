const db = require("../../models");
const db2 = require("../orgModel/orgIndex.js");
const Op = db.Sequelize.Op;
const { DATE, NOW } = require("sequelize");
const Moment = require('moment')

exports.updateOrgLogout = async (req, res) => {
const logoutData = {
    logout_time: Moment.utc().format('YYYY-MM-DD HH:mm:ss'),
    }
    console.log("logoutData",logoutData);

  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const logData = await db2['logoutTimeline'].findOne({
      where: {user_id:`${created_by.id}`},
      order: [['id', 'DESC']],
      limit:1,
    });
    // console.log("logDataaaaa", logData.dataValues.id);
    let logFinal = logData.dataValues?.id
    console.log("logFinalllll", logFinal);

    const logCheck = logData?.dataValues ? logData?.dataValues?.user_id : 0
    console.log("logcheckkkkkk", logCheck);
    
    const num = await db2['logoutTimeline'].update(logoutData, {
      where: {
        [Op.and]: [
          { id: logFinal},
        ],
      },
      order:[['id','desc']],
      // limit:1,
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:logFinal,
      });
    } else {
      res.status(200).send({
        status:200,
        message: `Cannot update with id : ${created_by.id}.`
      });
    }
  } 
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
