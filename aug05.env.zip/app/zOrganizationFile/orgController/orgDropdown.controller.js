const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;


// Lead Dropdown
exports.getLeadDropdown = async (req, res) => {
    try {
        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);
      
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);
      
        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        let values = ['looking_for', 'segment','property_type','lead_priority','source','lead_group','lead_status','project_facing', 'requirement_location','age_of_property','vasthu_compliant','amenities','furnishing_status','possession_status',]
        var condition = {
            where:{status:1},
            attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
          }
  
        // const dataFromOrg = await Modelv1.getAllFromOrg();
        
        const dataFromCity = await db['city'].findAll(condition);
        const dataFromState = await db['state'].findAll(condition);
        const dataFromCountry = await db['country'].findAll(condition);
        const dataFromCurrency = await db['currency'].findAll({
            where:{status:1},
            attributes:['id','name','symbol']
        });
        // const dataFromAssignTo = await db2['user'].findAll({
        //     where:{status:1},
        //     attributes:['id','first_name','last_name']
        // });
        let thisQuery = ` SELECT lz_user.id as id, lz_user.first_name as first_name,lz_user.last_name as last_name 
        FROM lz_user
        left join lz_user as us5 on (lz_user.created_by = us5.id) 
        left join lz_user as us4 on (us5.team_leader = us4.id) 
        left join lz_user as us6 on (lz_user.created_by = us6.id) 
        left join lz_user as us7 on (us6.portfolio_head = us7.id)
        where lz_user.status = 1 `

        if (role_id == 1) {
          thisQuery += ` `
        }
        if (role_id == 2) {
          thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
          // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 3) {
          thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
          // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 4) {
          thisQuery += ` and lz_user.created_by = ${created_by} `
        }
        const dataFromAssignTo = await db2.sequelize.query(thisQuery);

        let thisQuery1 = ` SELECT lz_user.id as id, lz_user.first_name as first_name,lz_user.last_name as last_name 
        FROM lz_user
        left join lz_user as us5 on (lz_user.created_by = us5.id) 
        left join lz_user as us4 on (us5.team_leader = us4.id) 
        left join lz_user as us6 on (lz_user.created_by = us6.id) 
        left join lz_user as us7 on (us6.portfolio_head = us7.id)
        where lz_user.status = 1 `

        if (role_id == 1) {
            thisQuery += ` `
          }
          if (role_id == 2) {
            thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
          }
          if (role_id == 3) {
            thisQuery += ` and lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
          }
          if (role_id == 4) {
            thisQuery += ` and lz_user.created_by = ${created_by} `
          }
        const dataFromSalesManager = await db2.sequelize.query(thisQuery1);

        const dataFromContactList = await db2['contacts'].findAll({
            where:{status:1},
            attributes:['id','first_name','last_name']
        });

        let thisQueryP = ` SELECT property_id as id, pa.name_of_building as name_of_building
        FROM lz_properties as p
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        where p.status = 1 and pa.name_of_building !=""
        `
        const dataFromProject = await db2.sequelize.query(thisQueryP);
        // const dataFromSalesManager = await db2['user'].findAll({
        //     where:{status:1},
        //     attributes:['id','first_name','last_name']
        // });
        const dataFromMasters = await db2['masters'].findAll(condition);
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const looking_for = model4Datafetch.filter((obj) => obj.option_type == 'looking_for');
        const segment = model4Datafetch.filter((obj) => obj.option_type == 'contact_category');
        const property_type = model4Datafetch.filter((obj) => obj.option_type == 'property_type');
        const lead_priority = model4Datafetch.filter((obj) => obj.option_type == 'lead_priority');
        const lead_source = model4Datafetch.filter((obj) => obj.option_type == 'source');
        const lead_group = model4Datafetch.filter((obj) => obj.option_type == 'lead_group');
        const lead_status = model4Datafetch.filter((obj) => obj.option_type == 'lead_status');
        const project_facing = model4Datafetch.filter((obj) => obj.option_type == 'project_facing');
        const requirement_location = model4Datafetch.filter((obj) => obj.option_type == 'requirement_location');
        const age_of_property = model4Datafetch.filter((obj) => obj.option_type == 'age_of_property');
        const vasthu_compliant = model4Datafetch.filter((obj) => obj.option_type == 'vasthu_compliant');
        const amenities = model4Datafetch.filter((obj) => obj.option_type == 'amenities');
        const furnishing_status = model4Datafetch.filter((obj) => obj.option_type == 'furnishing_status');
        const possession_status = model4Datafetch.filter((obj) => obj.option_type == 'possession_status');
  
        const combinedData = {
            assign_to: dataFromAssignTo[0],
            sales_manager: dataFromSalesManager,
            city: dataFromCity,
            state: dataFromState,
            country: dataFromCountry,
            currency: dataFromCurrency,
            looking_for: looking_for,
            property_type: property_type,
            segment: segment,
            lead_priority: lead_priority,
            source: lead_source,
            lead_group: lead_group,
            lead_status: lead_status,
            project_facing: project_facing,
            requirement_location: requirement_location,
            age_of_property: age_of_property,
            vasthu_compliant: vasthu_compliant,
            amenities: amenities,
            furnishing_status: furnishing_status,
            possession_status: possession_status,
            contact_list: dataFromContactList,
            property: dataFromProject[0],
        };
        res.status(200).send({
            message: "Leads dropdown data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
// Property Dropdown
exports.getPropertyDropdown = async (req, res) => {
    try {
        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);
      
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);
      
        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        let values = ['available_for','property_indepth','property_status','source','legal_approval', 'segment','property_type','ownership_type', 'project_stage','project_facing','age_of_property','kitchen_type','vasthu_compliant','flooring','amenities','furnishing_status','currently_under_loan','site_visit_preference','key_custody','car_park_type','water_supply','gated_community','specification','unit_type']
        var condition = {
            where:{status:1},
            attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
          }
  
        // const dataFromOrg = await Modelv1.getAllFromOrg();
        
        const dataFromCity = await db['city'].findAll(condition);
        const dataFromState = await db['state'].findAll(condition);
        const dataFromCountry = await db['country'].findAll(condition);
        const dataFromCurrency = await db['currency'].findAll({
            where:{status:1},
            attributes:['id','name','symbol']
        });
        let thisQuery = ` SELECT lz_user.id as id, lz_user.first_name as first_name,lz_user.last_name as last_name 
        FROM lz_user
        left join lz_user as us5 on (lz_user.created_by = us5.id) 
        left join lz_user as us4 on (us5.team_leader = us4.id) 
        left join lz_user as us6 on (lz_user.created_by = us6.id) 
        left join lz_user as us7 on (us6.portfolio_head = us7.id)
        where lz_user.status = 1 `

        if (role_id == 1) {
            thisQuery += ` `
          }
          if (role_id == 2) {
            thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
          }
          if (role_id == 3) {
            thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
          }
          if (role_id == 4) {
            thisQuery += ` and lz_user.created_by = ${created_by} `
          }
        const dataFromAssignTo = await db2.sequelize.query(thisQuery);

        const dataFromContactList = await db2['contacts'].findAll({
            where:{status:1},
            attributes:['id','first_name','last_name','developer_name']
        });
        const dataFromMasters = await db2['masters'].findAll(condition);
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const available_for = model4Datafetch.filter((obj) => obj.option_type == 'available_for');
        const property_indepth = model4Datafetch.filter((obj) => obj.option_type == 'property_indepth');
        const segment = model4Datafetch.filter((obj) => obj.option_type == 'segment');
        const property_type = model4Datafetch.filter((obj) => obj.option_type == 'property_type');
        const property_status = model4Datafetch.filter((obj) => obj.option_type == 'property_status');
        const property_source = model4Datafetch.filter((obj) => obj.option_type == 'source');
        const legal_approval = model4Datafetch.filter((obj) => obj.option_type == 'legal_approval');
        const project_stage = model4Datafetch.filter((obj) => obj.option_type == 'project_stage');
        const age_of_property = model4Datafetch.filter((obj) => obj.option_type == 'age_of_property');
        const furnishing_status = model4Datafetch.filter((obj) => obj.option_type == 'furnishing_status');
        const ownership_type = model4Datafetch.filter((obj) => obj.option_type == 'ownership_type');
        const project_facing = model4Datafetch.filter((obj) => obj.option_type == 'project_facing');
        const kitchen_type = model4Datafetch.filter((obj) => obj.option_type == 'kitchen_type');
        const flooring = model4Datafetch.filter((obj) => obj.option_type == 'flooring');
        const vasthu_compliant = model4Datafetch.filter((obj) => obj.option_type == 'vasthu_compliant');
        const amenities = model4Datafetch.filter((obj) => obj.option_type == 'amenities');
        const currently_under_loan = model4Datafetch.filter((obj) => obj.option_type == 'currently_under_loan');
        const site_visit_preference = model4Datafetch.filter((obj) => obj.option_type == 'site_visit_preference');
        const key_custody = model4Datafetch.filter((obj) => obj.option_type == 'key_custody');
        const car_park_type = model4Datafetch.filter((obj) => obj.option_type == 'car_park_type');
        const water_supply = model4Datafetch.filter((obj) => obj.option_type == 'water_supply');
        const gated_community = model4Datafetch.filter((obj) => obj.option_type == 'gated_community');
        const specification = model4Datafetch.filter((obj) => obj.option_type == 'specification');
        const unit_type = model4Datafetch.filter((obj) => obj.option_type == 'unit_type');
        const area_units = model4Datafetch.filter((obj) => obj.option_type == 'area_units');
  
        const combinedData = {
            assign_to: dataFromAssignTo[0],
            city: dataFromCity,
            state: dataFromState,
            country: dataFromCountry,
            currency: dataFromCurrency,
            available_for: available_for,
            property_indepth: property_indepth,
            property_status: property_status,
            property_type: property_type,
            property_source: property_source,
            legal_approval: legal_approval,
            project_stage: project_stage,
            segment: segment,
            project_facing: project_facing,
            age_of_property: age_of_property,
            vasthu_compliant: vasthu_compliant,
            amenities: amenities,
            furnishing_status: furnishing_status,
            kitchen_type: kitchen_type,
            ownership_type: ownership_type,
            flooring: flooring,
            currently_under_loan: currently_under_loan,
            site_visit_preference: site_visit_preference,
            car_park_type: car_park_type,
            water_supply: water_supply,
            gated_community: gated_community,
            specification: specification,
            unit_type: unit_type,
            area_units: area_units,
            key_custody: key_custody,
            contact_list: dataFromContactList,
        };
        res.status(200).send({
            message: "Property dropdown data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
// Transaction Dropdown
exports.getTransactionDropdown = async (req, res) => {
    try {
      const created_by = req.user.id
      console.log('created_by', created_by.id);
        let values = ['source','transaction_status']
        var condition = {
            where:{status:1},
            attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
          }
        // const dataFromOrg = await Modelv1.getAllFromOrg();
        
        const dataFromCity = await db['city'].findAll(condition);
        const dataFromState = await db['state'].findAll(condition);
        const dataFromCountry = await db['country'].findAll(condition);
        const dataFromCurrency = await db['currency'].findAll({
            where:{status:1},
            attributes:['id','name','symbol']
        });
        const dataFromTeamLeader = await db2['user'].findAll({
            where:{status:1},
            attributes:['id','first_name','last_name']
        });
        const dataFromSharedWith = await db2['user'].findAll({
            where:{status:1},
            attributes:['id','first_name','last_name']
        });
        let thisQueryP = ` SELECT property_id as id, pa.name_of_building as name_of_building
        FROM lz_properties as p
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        where p.status = 1 and pa.name_of_building !=""
        `
        const dataFromProject = await db2.sequelize.query(thisQueryP);
        const dataFromClient = await db2['contacts'].findAll({
            where:{status:1},
            attributes:['id','first_name','last_name']
        });
        const dataFromDeveloper = await db2['contacts'].findAll({
            where:{status:1},
            attributes:['id','developer_name'],
            group:['developer_name']
        });
        let dataFromLead = `select l.id as id, CONCAT(c.first_name, ' ',c.last_name) as contact_name from lz_leads as l left join lz_contacts as c on (l.contact_id = c.id) where l.status = 1 group by c.first_name `
        const dataLead = await db2.sequelize.query(dataFromLead);

        const dataFromMasters = await db2['masters'].findAll(condition);
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const lead_source = model4Datafetch.filter((obj) => obj.option_type == 'source');
        const transaction_status = model4Datafetch.filter((obj) => obj.option_type == 'transaction_status');
  
        const combinedData = {
            city: dataFromCity,
            state: dataFromState,
            country: dataFromCountry,
            currency: dataFromCurrency,
            lead_source: lead_source,
            transaction_status: transaction_status,
            team_leader: dataFromTeamLeader,
            shared_with: dataFromSharedWith,
            project: dataFromProject[0],
            client: dataFromClient,
            developer_name: dataFromDeveloper,
            lead: dataLead[0],
        };
        res.status(200).send({
            message: "Transaction dropdown data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
// Tasks Dropdown
exports.getTaskDropdown = async (req, res) => {
    try {
        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);
      
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);
      
        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        let values = ['task_type','priority','task_status','reminder']
        var condition = {
            where:{status:1},
            attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
          }
  
        // const dataFromOrg = await Modelv1.getAllFromOrg();
        
        // const dataFromAssignTo = await db2['user'].findAll({
        //     where:{status:1},
        //     attributes:['id','first_name']
        // });

        let thisQuery = ` SELECT lz_user.id as id, lz_user.first_name as first_name,lz_user.last_name as last_name 
            FROM lz_user
            left join lz_user as us5 on (lz_user.created_by = us5.id) 
            left join lz_user as us4 on (us5.team_leader = us4.id) 
            left join lz_user as us6 on (lz_user.created_by = us6.id) 
            left join lz_user as us7 on (us6.portfolio_head = us7.id)
            where lz_user.status = 1 `

        if (role_id == 1) {
            thisQuery += ` `
        }
        if (role_id == 2) {
            thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 3) {
            thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 4) {
            thisQuery += ` and lz_user.created_by = ${created_by} `
        }

        const dataFromAssignTo = await db2.sequelize.query(thisQuery);
        let thisQueryP = ` SELECT property_id as id, pa.name_of_building as name_of_building
        FROM lz_properties as p
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        where p.status = 1 and pa.name_of_building !=""
        `
        const dataFromProject = await db2.sequelize.query(thisQueryP);
        const dataFromContact = await db2['contacts'].findAll({
            where:{status:1},
            attributes:['id','first_name','last_name']
        });
        const dataFromMasters = await db2['masters'].findAll(condition);
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const task_type = model4Datafetch.filter((obj) => obj.option_type == 'task_type');
        const priority = model4Datafetch.filter((obj) => obj.option_type == 'priority');
        const task_status = model4Datafetch.filter((obj) => obj.option_type == 'task_status');
        const reminder = model4Datafetch.filter((obj) => obj.option_type == 'reminder');
  
        const combinedData = {
            assign_to: dataFromAssignTo[0],
            task_type: task_type,
            priority: priority,
            project: dataFromProject[0],
            contact: dataFromContact,
            task_status: task_status,
            reminder: reminder,
        };
        res.status(200).send({
            message: "Task dropdown data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
// Team Dropdown
exports.getTeamDropdown = async (req, res) => {
    try {
      const created_by = req.user.id
      console.log('created_by', created_by.id);

    //   let thisQuery = ` SELECT distinct us1.team_leader as team_leader_id,  CONVERT(us1.team_leader USING utf8) as team_leader, us1.first_name as team_leader_name, GROUP_CONCAT(distinct CONCAT(us2.first_name)) as exec_name  
    //   FROM lz_user as us
    //   LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
    //   LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,us1.team_leader) > 0 
    //   where us.status = 1
    //   group by us.id
    //   `
    // let thisQuery = ` SELECT us1.team_leader as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT( CONCAT(us1.first_name,' ',IFNULL(us.last_name,''),'-',us1.id)) as user_name FROM lz_user as us
    // LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
    // where us.status = 1 and us1.id IS NOT NULL
    // group by us1.team_leader
    // `

        // let thisQuery = ` SELECT us.designation as designation_id, rol.role_name as role_name, us1.team_leader as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT( CONCAT(us1.first_name,' ',IFNULL(us.last_name,''),'-',us1.id)) as user_name FROM lz_user as us
        // LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
        // LEFT JOIN lz_roles as rol on (rol.id = us.designation)
        // LEFT JOIN lz_roles as rol1 on FIND_IN_SET(rol1.reporting_to,us1.team_leader) > 0 
        // where us.status = 1 and us.designation IS NOT NULL
        // group by us1.team_leader
        // `

        let thisQuery = ``
            thisQuery += `select us1.team_leader as team_leader, CONCAT(us1.first_name,' ',IFNULL(us1.last_name, '')) as team_leader_name from lz_user as us left join lz_user as us1 on (us1.id = us1.team_leader) where (us1.designation = 2 or us1.designation=1 or us1.designation=4) group by us1.team_leader `

        const dataFromTeam = await db2.sequelize.query(thisQuery);

        res.status(200).send({
            message: "Team dropdown data",
            status: 200,
            output: dataFromTeam[0]
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
// Contact Settings Dropdown
exports.getContactSettingsDropdown = async (req, res) => {
    try {
        const created_by = req.user.id
        console.log('created_by', created_by.id);

        var condition = {
            where:{status:1},
            attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
        }

        let thisQuery = ` SELECT us.id as id, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as users_name FROM lz_user as us `
        const dataFromUsers = await db2.sequelize.query(thisQuery);

        // const dataFromProject = await db2['propertyAddress'].findAll({
        //     attributes:['id','name_of_building']
        // });

        let thisQueryP = ` SELECT property_id as id, pa.name_of_building as name_of_building
        FROM lz_properties as p
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        where p.status = 1 
        `
        const dataFromProject = await db2.sequelize.query(thisQueryP);

        const dataFromMasters = await db2['masters'].findAll(condition);
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const source = model4Datafetch.filter((obj) => obj.option_type == 'source');

        const combinedData = {
            source: source,
            users: dataFromUsers[0],
            project:dataFromProject[0]
        };

        res.status(200).send({
            message: "Team dropdown data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
// Finance Dropdown
exports.getFinanceDropdown = async (req, res) => {
    try {
        const created_id = req.user.id
        const created_by = created_id.id
        console.log('created_by', created_by);
      
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);
      
        const role = req.user.id
        const role_id = role.designation
        console.log('role_id', role_id);

        var condition = {
            where:{status:1},
            attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
        }

        let thisQueryP = ` SELECT pa.property_id as property_id, pa.name_of_building as name_of_building
        FROM lz_properties as p
        left join lz_property_addresses as pa on (p.id = pa.property_id)
        where p.status = 1 
        group by p.id
        `
        const dataFromProject = await db2.sequelize.query(thisQueryP);

        let thisQueryC = ` SELECT c.id as contact_id, c.developer_name as developer_name
        FROM lz_contacts as c
        where c.status = 1 and c.contact_type = 10
        group by c.id
        `
        const dataFromContacts = await db2.sequelize.query(thisQueryC);

        let thisQueryT = ` SELECT t.id as id, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name
        FROM lz_transactions as t
        left join lz_contacts as c on (t.client_name = c.id) 
        where t.status = 1 
        group by c.id
        `
        const dataFromTransaction = await db2.sequelize.query(thisQueryT);

        let thisQueryFee = ` SELECT fee.id as id, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c1.developer_name as developer_name
        FROM lz_finance_fee_confirmation as fee
        left join lz_contacts as c on (fee.contact_name = c.id) 
        left join lz_contacts as c1 on (fee.developer_name = c1.id) 
        where c.status = 1 
        group by fee.id
        `
        const dataFromFeeConfirmation = await db2.sequelize.query(thisQueryFee);

        let thisQueryIn = ` SELECT fi.id as id, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.developer_name as developer_name
        FROM lz_finance_invoice as fi
        left join lz_contacts as c on (fi.contact_name = c.id) 
        where c.status = 1 
        group by c.id
        `
        const dataFromInVoice = await db2.sequelize.query(thisQueryIn);

        // let thisQueryClient = ` SELECT t.id as id, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name
        // FROM lz_transactions as t
        // left join lz_contacts as c on (t.client_name = c.id) 
        // where t.status = 1 `
        // const dataFromClient = await db2.sequelize.query(thisQueryClient);
        let thisQueryClient = ` SELECT c.id as id, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name
        FROM lz_transactions as t
        left join lz_contacts as c on (t.client_name = c.id) 
        where c.status = 1 
        group by c.id
        `
        const dataFromClient = await db2.sequelize.query(thisQueryClient);

        let thisQuery = ` SELECT lz_user.id as id, lz_user.first_name as first_name,lz_user.last_name as last_name 
        FROM lz_user
        left join lz_user as us5 on (lz_user.created_by = us5.id) 
        left join lz_user as us4 on (us5.team_leader = us4.id) 
        left join lz_user as us6 on (lz_user.created_by = us6.id) 
        left join lz_user as us7 on (us6.portfolio_head = us7.id)
        where lz_user.status = 1 `

        if (role_id == 1) {
            thisQuery += ` `
        }
        if (role_id == 2) {
            thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 3) {
            thisQuery += ` and lz_user.team_leader = ${created_by} or lz_user.portfolio_head = ${created_by} or lz_user.created_by = ${created_by} `
            // thisQuery += ` and c.created_by = ${created_by} `
        }
        if (role_id == 4) {
            thisQuery += ` and lz_user.created_by = ${created_by} `
        }

        const dataFromTeamLeader = await db2.sequelize.query(thisQuery);

        let thisQueryU = `SELECT id, CONCAT(first_name,' ',IFNULL(last_name, '')) as user_name FROM lz_user where status = 1 `
        const dataFromUsers = await db2.sequelize.query(thisQueryU);

        const dataFromMasters = await db2['masters'].findAll(condition);
        let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
        const fee_confirmation_status = model4Datafetch.filter((obj) => obj.option_type == 'fee_confirmation_status');
        const invoice_status = model4Datafetch.filter((obj) => obj.option_type == 'invoice_status');
        const expense_type = model4Datafetch.filter((obj) => obj.option_type == 'expense_type');
        const source = model4Datafetch.filter((obj) => obj.option_type == 'source');
        const release_mode = model4Datafetch.filter((obj) => obj.option_type == 'release_mode');
        const collection_status = model4Datafetch.filter((obj) => obj.option_type == 'collection_status');

        const combinedData = {
            source: source,
            fee_confirmation_status: fee_confirmation_status,
            invoice_status: invoice_status,
            expense_type: expense_type,
            release_mode: release_mode,
            collection_status: collection_status,
            project:dataFromProject[0],
            developer_name:dataFromContacts[0],
            transaction:dataFromTransaction[0],
            client_name:dataFromClient[0],
            team_leader:dataFromTeamLeader[0],
            fee_confirmation: dataFromFeeConfirmation[0],
            invoice: dataFromInVoice[0],
            users: dataFromUsers[0]
        };

        res.status(200).send({
            message: "Finance dropdown data",
            status: 200,
            output: combinedData
        })
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};