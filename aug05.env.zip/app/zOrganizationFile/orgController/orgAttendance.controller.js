const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const Moment = require('moment')
const dayjs = require('dayjs');
const { NOW } = require("sequelize");

exports.saveAttendance = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const startDate =  Moment(req.body.start).format('YYYY-MM-DD');
    console.log("startDate", startDate);

    // const attendanceData = await db2['attendance'].findAll({
    //     where:{
    //         user_id :`${req.body.user_id}`, start : `${startDate}`
    //     }
    // });

    // let thisQuery = ` select id from lz_attendance where user_id = '${req.body.user_id}' `
    // const attendanceData = await db2.sequelize.query(thisQuery);

    // console.log("attendanceDataaaaa", attendanceData[0]);
    // const attendanceId = attendanceData[0] ? attendanceData[0].id : 0
    // console.log("attendanceIDDDDDDDDDD", attendanceId);

    // const attendanceId = await db2['attendance'].findOne({
    //     where: {[Op.or]: [{ user_id :`${req.body.user_id}`, start:'2022-05-06' },],},
    // });

    let thisQuery = ` select id from lz_attendance where user_id ='${req.body.user_id}' and date(start)='${dayjs(req.body.start).format("YYYY-MM-DD")}' `
    const attendanceData = await db2.sequelize.query(thisQuery);

    console.log("attendanceDataaaaa", attendanceData);
    const ggggg = attendanceData[0][0]
    console.log("gggggggggg", ggggg);

    if (ggggg) {
        res.status(200).send({
            status:400,
            message:'Cannot register the attendance twice a day for the person',
            output:[]
          });
    } else {
    const data = await db2['attendance'].create({
      user_id: req.body.user_id,
      start: req.body.start,
      end: req.body.end,
      attendance_status: req.body.attendance_status,
      leave_type: req.body.leave_type,
      user_ip: req.body.user_ip,
      user_latitude: req.body.user_latitude,
      user_longitude: req.body.user_longitude,
      user_address: req.body.user_address,
      created_by: created_by.id
    });
    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getAttendanceCheck = async (req, res) => {
    try {
      
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    let thisQuery = ` SELECT distinct att.id as id, us.id as user_id, CONCAT(us.first_name) as user_name , DATE_FORMAT(att.start,'%Y-%m-%d %H:%i:%s') as start_time, DATE_FORMAT(att.end,'%Y-%m-%d %H:%i:%s') as end_time, att.status as status, att.attendance_status as attendance_status, att.leave_type as leave_type, at.option_value as attendance_status_name, lt.option_value as leave_type_name 
    FROM lz_attendance as att
    LEFT JOIN lz_user as us on (us.id = att.user_id)
    LEFT JOIN lz_masters as at on (at.id = att.attendance_status)
    LEFT JOIN lz_masters as lt on (lt.id = att.leave_type)
    where att.status = 1 
    group by att.id DESC `


    const attendanceData = await db2.sequelize.query(thisQuery);
    const data = await db2['attendance'].findAll({
        where:{status:1},
        order:[['id', 'DESC']]
    })

    console.log('attendanceDataaaaaa',attendanceData[0]);
    console.log('dataaaaaaaaa',data[0]?.dataValues);

    const finalAtt = attendanceData[0]
    const finalAtt2 = data
    
    let timetWithdata = [];
      for(let i=0; finalAtt.length > i;i++) {
          let dataPush = {...finalAtt[i], start_time_at :Moment(finalAtt2[i].start).format('YYYY-MM-DD hh:mm:ss')};
          timetWithdata.push(dataPush);
      }

      res.status(200).send({
        status:200,
        message:'Success',
        output:timetWithdata
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.checkInAttendance = async (req, res) => {
    try {
      const created_id = req.user.id
      const created_by = created_id.id
      console.log('created_by', created_by.id);
  
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

      const d = new Date();
      const currentTime = {d: Moment(d).format('YYYY-MM-DD hh:mm:ss')}
      const autoCheckIN = currentTime.d
      console.log("dddddddd", currentTime);
      console.log("autoCheckIN", autoCheckIN);

    //   const data = await db2['attendance'].findAll()
    //   const yui = Moment(data[0]?.dataValues.start).format('YYYY-MM-DD hh:mm:ss')

    //   const dom = new Date(req.body.start); // Wed Jun 15 07:00:00 GMT+1000 (EST)
    //     dom.toUTCString()
    //     console.log("dommmm", dom);
        // console.log("yuiiiiiiiiiiii", yui);

      let attendanceStatus = req.body.attendance_status
      let leaveType = req.body.leave_type

      if (currentTime <= 10.30) {
        attendanceStatus = 159
      }
      if (currentTime <= 13.00) {
          attendanceStatus = 161
      }
      else {
          attendanceStatus = 160
      }
  
      const startDate =  Moment().format('YYYY-MM-DD hh:mm a');
      console.log("startDate", startDate);
  
      let thisQuery = ` select id from lz_attendance where status = 1 and user_id ='${created_by}' and date(start)='${dayjs(req.body.start).format("YYYY-MM-DD")}' `
      const attendanceData = await db2.sequelize.query(thisQuery);
  
      console.log("attendanceDataaaaa", attendanceData);
      const ggggg = attendanceData[0][0]
      console.log("gggggggggg", ggggg);
  
      if (ggggg) {
          res.status(200).send({
              status:400,
              message:'Cannot register the attendance twice a day for the person',
              output:[]
            });
      } else {
      const data = await db2['attendance'].create({
        user_id: created_by,
        start: req.body.start ?? startDate,
        end: req.body.end  ?? startDate,
        attendance_status: attendanceStatus,
        leave_type: leaveType,
        user_ip: req.body.user_ip,
        user_latitude: req.body.user_latitude,
        user_longitude: req.body.user_longitude,
        user_address: req.body.user_address,
        created_by: created_by
      });

      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.findOne = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;
    const data = await db2[req.params.document].findAll({
      where: {
          id: id,status:1
        },
      attributes: {exclude :['createdAt','updatedAt']}
    }
      );
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateAttendance = async (req, res) => {
  try {
    const id = req.params.id;
    const data = {
        user_id: req.body.user_id,
        start: req.body.start,
        end: req.body.end,
        attendance_status: req.body.attendance_status,
        leave_type: req.body.leave_type,
        user_ip: req.body.user_ip,
        user_latitude: req.body.user_latitude,
        user_longitude: req.body.user_longitude,
        user_address: req.body.user_address,
    }
    const num = await db2['attendance'].update(data, {
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteAttendance = async (req, res) => {
  const attData = {
    status: 0,
  }
  try {
    const id = req.params.id;

    console.log("id111", id);
    const num = await db2['attendance'].update(attData, {
      where: {id:id},
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getAttendance = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const userID = req.params.user_id;
  const teamID = req.params.team_leader;
  
  console.log("userIDDDDDDDDDDD", userID);
  console.log("TeamIDDDDDDDDDDD", teamID);

  if(teamID == 1 && userID == 0) {

    let thisQuery = ` SELECT distinct att.id as id, us.id as user_id, CONCAT(us.first_name) as title, att.start as start, att.end as end, DATE_FORMAT(att.start,'%Y-%m-%d %H:%i:%s') as start_at, DATE_FORMAT(att.end,'%Y-%m-%d %H:%i:%s') as end_at, att.attendance_status as attendance_status, att.leave_type as leave_type, att.status as status, at.option_value as attendance_status_name, lt.option_value as leave_type_name, att.user_address as address FROM lz_attendance as att
    LEFT JOIN lz_user as us on (us.id = att.user_id)
    LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
    LEFT JOIN lz_masters as at on (at.id = att.attendance_status)
    LEFT JOIN lz_masters as lt on (lt.id = att.leave_type)
    where att.status = 1
    group by att.id 
    order by att.id ASC 
    `
    console.log("thisQueryyyy", thisQuery);
    const attendanceData = await db2.sequelize.query(thisQuery);
  
    console.log("admin attendance list");

      res.status(200).send({
        status:200,
        message:'Success',
        output:attendanceData[0]
      });
  }

  else if (teamID == 0) {
  
  let thisQuery = ` SELECT distinct att.id as id, us.id as user_id, CONCAT(us.first_name) as title, att.start as start, att.end as end, DATE_FORMAT(att.start,'%Y-%m-%d %H:%i:%s') as start_at, DATE_FORMAT(att.end,'%Y-%m-%d %H:%i:%s') as end_at, att.attendance_status as attendance_status, att.leave_type as leave_type, att.status as status, at.option_value as attendance_status_name, lt.option_value as leave_type_name FROM lz_attendance as att
  LEFT JOIN lz_user as us on (us.id = att.user_id)
  LEFT JOIN lz_masters as at on (at.id = att.attendance_status)
  LEFT JOIN lz_masters as lt on (lt.id = att.leave_type)
  where att.status = 1 and user_id = ${userID}
  group by att.id 
  order by att.id DESC 
  `
  const attendanceData = await db2.sequelize.query(thisQuery);
  const data = await db2['attendance'].findAll({
      where:{status:1},
      order:[['id', 'DESC']]
  })

    console.log("users attendance list");

    res.status(200).send({
      status:200,
      message:'Success',
      output:attendanceData[0]
    });

  } else if (userID == 0) {
    let thisQuery = ` SELECT distinct att.id as id, us.id as user_id, CONCAT(us.first_name) as title ,att.start as start, att.end as end, DATE_FORMAT(att.start,'%Y-%m-%d %H:%i:%s') as start_at, DATE_FORMAT(att.end,'%Y-%m-%d %H:%i:%s') as end_at, att.attendance_status as attendance_status, att.leave_type as leave_type, att.status as status, at.option_value as attendance_status_name, lt.option_value as leave_type_name FROM lz_attendance as att
    LEFT JOIN lz_user as us on (us.id = att.user_id)
    LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
    LEFT JOIN lz_masters as at on (at.id = att.attendance_status)
    LEFT JOIN lz_masters as lt on (lt.id = att.leave_type)
    where att.status = 1 and us.team_leader = ${teamID} OR att.user_id = ${teamID}
    group by att.id 
    order by att.id DESC 
    `
  
    console.log("thisQueryyyy", thisQuery);
    const attendanceData = await db2.sequelize.query(thisQuery);
  
    console.log("teams attendance list");

      res.status(200).send({
        status:200,
        message:'Success',
        output:attendanceData[0]
      });
  } 

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getAttendanceTimeSheet = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = ` SELECT distinct att.id as id, us.id as user_id, CONCAT(us.first_name) as title , DATE_FORMAT(att.start,'%Y-%m-%d %H:%i:%s') as start, DATE_FORMAT(att.end,'%Y-%m-%d %H:%i:%s') as end, att.status as status, at.option_value as attendance_status_name, lt.option_value as leave_type_name, dep.option_value as department_name FROM lz_attendance as att
  LEFT JOIN lz_user as us on (us.id = att.user_id)
  LEFT JOIN lz_masters as at on (at.id = att.attendance_status)
  LEFT JOIN lz_masters as lt on (lt.id = att.leave_type)
  LEFT JOIN lz_masters as dep on (dep.id = us.department)
  where att.status = 1
  `
  const filters = req.query;
  // if (filters.start_date == '' && filters.end_date=='' && filters.users=='') {
  //   thisQuery += " and DATE_FORMAT(att.start,'%Y-%m-%d') = DATE_FORMAT(NOW(), '%Y-%m-%d') order by user_id "
  // }

  // Start Date & End Date
  if (filters.start_date != '' && filters.end_date !='' && filters.users=='') {
    thisQuery += ` and (DATE_FORMAT(att.start,'%Y-%m-%d') >= '${filters.start_date}' AND DATE_FORMAT(att.start,'%Y-%m-%d') <= '${filters.end_date}') `
  }
  // Start Date
  if (filters.start_date != '' && filters.end_date =='' && filters.users=='') {
    thisQuery += ` and (DATE_FORMAT(att.start,'%Y-%m-%d') >= '${filters.start_date}') `
  }
  // Start Date & Users
  if (filters.start_date != '' && filters.end_date =='' && filters.users !='') {
    thisQuery += ` and (DATE_FORMAT(att.start,'%Y-%m-%d') >= '${filters.start_date}') and att.user_id in (${filters.users}) `
  }
  // Users
  if (filters.start_date == '' && filters.end_date =='' && filters.users!='') {
    thisQuery += ` and att.user_id in (${filters.users}) `
  }
  // Start Date -> End Date -> Users
  if (filters.start_date != '' && filters.end_date !='' && filters.users!='') {
    thisQuery += ` and att.user_id in (${filters.users}) and (DATE_FORMAT(att.start,'%Y-%m-%d') >= '${filters.start_date}' AND DATE_FORMAT(att.start,'%Y-%m-%d') <= '${filters.end_date}') `
  }

  thisQuery += ` group by att.id  `
  thisQuery += ` order by att.id DESC `
  
  const attendanceData = await db2.sequelize.query(thisQuery);
  const data = await db2['attendance'].findAll({
      where:{status:1},
      order:[['id', 'DESC']]
  })

  console.log("attendance time sheet");

    res.status(200).send({
      status:200,
      message:'Success',
      output:attendanceData[0]
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getAttendanceCount = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const userID = req.params.user_id
  
  // let thisQuery = ` SELECT count(att.id) as id, DAYNAME(start) as start_day, DATE_FORMAT(att.start,'%Y-%m-%d %H:%i:%s') as start_date, count(case when att.attendance_status ='1' then 1 end) as absent_count ,count(case when att.attendance_status ='2' then 1 end) as present_count ,count(case when att.attendance_status ='3' then 1 end) as half_count 
  // FROM lz_attendance as att 
  // LEFT JOIN lz_masters as at on (at.id = att.attendance_status) 
  // where (att.status = 1) and (att.start >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND att.start < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) group by DAY(att.start) order by DAY(att.start)
  // `

  let thisQuery = ` SELECT count(att.id) as id FROM lz_attendance as att where YEAR(att.created_at) = YEAR(NOW() - INTERVAL 0 YEAR) `
  const attendanceData = await db2.sequelize.query(thisQuery);

  console.log("attendance count");

    res.status(200).send({
      status:200,
      message:'Success',
      output:attendanceData[0]
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};


exports.getLogSheet = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const userID = req.params.user_id

  let thisQuery = ` SELECT ut.id as id, ut.user_id as user_id, CONCAT(first_name,' ', IFNULL(last_name, '')) as user_name, us.email as email, ut.login_time as login_time_at, ut.logout_time as logout_time_at, DATE_FORMAT(ut.login_time,'%Y-%m-%d %H:%i:%s') as login_time, DATE_FORMAT(ut.logout_time,'%Y-%m-%d %H:%i:%s') as logout_time FROM lz_user_timeline as ut
  LEFT JOIN lz_user as us on (us.id = ut.user_id)
  where us.status = 1
  `
  const filters = req.query;

  if (filters.login_time != '' && filters.logout_time != '') {
    thisQuery += ` and (DATE_FORMAT(ut.login_time,'%Y-%m-%d') >= '${filters.login_time}' AND DATE_FORMAT(ut.logout_time,'%Y-%m-%d') <= '${filters.logout_time}') `
  }

  const attendanceData = await db2.sequelize.query(thisQuery);

  console.log("attendance count");

    res.status(200).send({
      status:200,
      message:'Success',
      output:attendanceData[0]
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};