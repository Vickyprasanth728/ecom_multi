const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;

exports.saveNotes = async (req, res) => {
    try {
      const id = req.params.id
      const created_by = req.user.id
      console.log('created_by', created_by.id);
  
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);

    if (req.body.parent_id == 0) {

      const data = await db2['notes'].create({
        org_id: org_id,
        reply: req.body.reply,
        parent_id: "0",
        module_id: req.body.module_id,
        module_name: req.body.module_name,
        user_id: created_by.id,
        created_by: created_by.id
      });
      const ModuleID = data?.dataValues.module_id
      const ModuleName = data?.dataValues.module_name

      const NotesID = data?.dataValues.id;

      const data1 = {
        parent_id: NotesID
      }
      const num = await db2['notes'].update(data1, {
        where: { id: NotesID },
      });

      let thisQuery = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id,  nc.created_at as created_at, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
      const notesData = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:notesData[0]
      });

    } else {
        const data = await db2['notes'].create({
            org_id: org_id,
            reply: req.body.reply,
            parent_id: req.body.parent_id,
            module_id: req.body.module_id,
            module_name: req.body.module_name,
            user_id: created_by.id,
            created_by: created_by.id
          });
          let ModuleID =  data?.dataValues.module_id
          let ModuleName = data?.dataValues.module_name

          let thisQuery = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id, nc.created_at as created_at, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
          const notesData = await db2.sequelize.query(thisQuery);

          res.status(200).send({
            status:200,
            message:'Success',
            output:notesData[0]
          });
    }

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.getNotes = async (req, res) => {
    try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = 2
    console.log('role_id', role_id);

    const ModuleID = req.params.module_id;
    const ModuleName = req.params.module_name;
    
    let thisQuery1 = `
    ${ModuleName == 1 ? `SELECT c.id as contact_id FROM lz_contacts as c where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} and c.id = ${ModuleID}` : 
      ModuleName == 2 ? `SELECT l.id as lead_id,l.contact_id as contact_id FROM lz_leads as l where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.id = ${ModuleID}` : 
      ModuleName == 3 ? `SELECT p.contact_id as contact_id FROM lz_properties as p where p.status = 1 and p.id = ${ModuleID} ` : 
      ModuleName == 4 ? `SELECT t.contact as contact_id, t.project as property_id, le.id as lead_id FROM lz_tasks as t left join lz_contacts as c on (c.id = t.contact) left join lz_leads as le on (c.id = le.contact_id) where ${role_id == 1 ? `t.status IN (1,2) ` : `t.status = 1`} and t.id = ${ModuleID} ` :
      ModuleName == 5 ? `SELECT tra.client_name as contact_id, tra.project_name as property_id, tra.lead_id as lead_id FROM lz_transactions as tra left join lz_leads as le on (le.id = tra.lead_id) where tra.status = 1 and tra.id = ${ModuleID} ` : ``} `
    const conData = await db2.sequelize.query(thisQuery1);

    const cData = `
    ${ModuleName == 2 || 3 ? conData[0][0].contact_id : 
      ModuleName == 4 ? conData[0][0].contact : 
      ModuleName == 5 ? conData[0][0].client_name : ``} `
    console.log("cData", cData);
    const lData = `
    ${ModuleName == 2 || 3 ? conData[0][0].lead_id : 
      ModuleName == 4 ? conData[0][0].contact_id : 
      ModuleName == 5 ? conData[0][0].lead_id : ``} `
    console.log("lData", lData);
    const pData = `
    ${ModuleName == 2 || 3 ? conData[0][0].property_id : 
      ModuleName == 4 ? conData[0][0].property_id : 
      ModuleName == 5 ? conData[0][0].property_id : ``} `
    console.log("pData", pData);

    let thisQuery = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id,  nc.created_at as created_at, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image 
    FROM lz_notes as nc 
    LEFT JOIN lz_user as us on (us.id = nc.user_id)  
    where nc.status = 1 and (nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} 
    ${ModuleName == 1 ? `` : `or (nc.module_id = ${cData} and nc.module_name = 1) `} 
    ${ModuleName == 4 ? `or (nc.module_id = ${lData} and nc.module_name = 2) or (nc.module_id = ${pData} and nc.module_name = 3) ` : ``} 
    ${ModuleName == 5 ? `or (nc.module_id = ${lData} and nc.module_name = 2) or (nc.module_id = ${pData} and nc.module_name = 3) ` : ``} 
    )
    order by nc.parent_id DESC, nc.id `
    const notesData = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        count:notesData[0].length,
        output:notesData[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.updateNotes = async (req, res) => {
  try {
    const id = req.params.id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const contactNotesData = {
        reply: req.body.reply,
    };

    const ModuleID = req.body.module_id
    const ModuleName = req.body.module_name

    const num = await db2['notes'].update(contactNotesData, {
      where: { id: id },
    });
    if (num == 1) {

        let thisQuery1 = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
        const notesData = await db2.sequelize.query(thisQuery1);

      res.status(200).send({
        status:200,
        message: "Updated successfully.",
        output:notesData[0]
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteNotes = async (req, res) => {

  const id = req.params.id;
  const parent_id = req.params.parent_id;

  const created_by = req.user.id
  console.log('created_by', created_by.id);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const ModuleID = req.body.module_id
  const ModuleName = req.body.module_name

  try {
    let thisQuery = ` UPDATE lz_notes SET status = 0 `
    if (id == parent_id) {
        thisQuery += "where parent_id IN (" + parent_id + ")"
    } else {
        thisQuery += `where id = ${id} `
    }
    const data = await db2.sequelize.query(thisQuery);

    let thisQuery1 = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc LEFT JOIN lz_user as us on (us.id = nc.user_id) where nc.status = 1 and nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} order by nc.parent_id DESC, nc.id `
    const notesData = await db2.sequelize.query(thisQuery1);

    res.status(200).send({
        status:200,
        message:'Success',
        output:notesData[0]
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getLeadNotes = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const ModuleID = req.params.module_id;
  const ModuleName = req.params.module_name;

  let thisQuery = `SELECT nc.id as id, nc.org_id as org_id, nc.reply as reply, nc.parent_id as parent_id, nc.module_id as module_id, nc.module_name as module_name, nc.user_id as user_id,  nc.created_at as created_at, nc.updated_at as updated_at, IF(nc.parent_id != nc.id , "YES", "NO") as reply1, CONCAT(us.first_name,' ',us.last_name) as user_name, us.profile_image as user_profile_image FROM lz_notes as nc 
  LEFT JOIN lz_user as us on (us.id = nc.user_id) 
  where nc.status = 1 
  and nc.module_id = ${ModuleID} 
  and nc.module_name IN (${ModuleName}, 1)
  order by nc.parent_id DESC, nc.id `
  const notesData = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:notesData[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};


// exports.getNotes = async (req, res) => {
//   try {
    
//   const organ_id = req.user.id
//   const org_id = organ_id.org_id
//   console.log('organ_id', org_id);

//   const ModuleID = req.params.module_id;
//   const ModuleName = req.params.module_name;

//     let thisQuery1 = `${ModuleName == 2 ? `SELECT l.contact_id as contact_id FROM lz_leads as l where l.status = 1 and l.id = ${ModuleID}` : ModuleName == 3 ? `SELECT p.contact_id as contact_id FROM lz_properties as p where p.status = 1 and p.id = ${ModuleID} ` : ModuleName == 4 ? `SELECT t.contact as contact_id FROM lz_tasks as t where t.status = 1 and t.id = ${ModuleID} ` : ModuleName == 5 ? `SELECT tra.client_name as contact_id FROM lz_transactions as tra where tra.status = 1 and tra.id = ${ModuleID} ` : ``} `
//     const conData = await db2.sequelize.query(thisQuery1);
//     const cData = `${ModuleName == 2 || 3 ? conData[0][0].contact_id : ModuleName == 4 ? conData[0][0].contact : ModuleName == 5 ? conData[0][0].client_name : ``}`
//     console.log("cData", cData);

//   let thisQuery = `SELECT nc.id as id, nc.module_id as module_id, nc.module_name as module_name
//   FROM lz_notes as nc 
//   LEFT JOIN lz_user as us on (us.id = nc.user_id)  
//   where nc.status = 1 and (nc.module_id = ${ModuleID} and nc.module_name = ${ModuleName} or nc.module_id = ${cData})
//   order by nc.parent_id DESC, nc.id `
//   const notesData = await db2.sequelize.query(thisQuery);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       count:notesData[0].length,
//       output:notesData[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };



// const db2 = require("../orgModel/orgIndex.js");
// const db = require("../../models");
// const Op = db2.Sequelize.Op;
// const Moment = require('moment')


// const datebetween = async (queryString) => {
//   let dateBetween;

//   if (queryString.filter_by == '' || queryString.filter_by == undefined ) {
//     dateBetween = ` `
//   }
//   if (queryString.filter_by == 1) {
//     dateBetween = ` and (DATE(c.created_at) = DATE(NOW())) `
//   }
//   else if (queryString.filter_by == 2) {
//     dateBetween = ` and (DATE(c.created_at) = DATE(NOW())-1) `
//   }
//   else if (queryString.filter_by == 3) {
//     dateBetween = ` and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)  `
//   }
//   else if (queryString.filter_by == 4) {
//     dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month)) `
//   }
//   else if (queryString.filter_by == 5) {
//     dateBetween = ` and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 month)) `
//   }
//   else if (queryString.filter_by == 6) {
//     dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 year)) `
//   }
//   else if (queryString.filter_by == 7) {
//     dateBetween = ` and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') `
//   }
//   return dateBetween;
// }
// exports.getDashboardCount = async (req, res) => {
//   try {

//   // let thisQuery = ` SELECT designation from lz_user where id ='${created_by}' limit 1 `
//   // const dashboardData = await db2.sequelize.query(thisQuery);
//   // const dataDashboard = dashboardData[0]
//   // console.log("dashboardData", dataDashboard);

//   // const role = dataDashboard[0] ? dataDashboard[0]["designation"] : 0 role.designation

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//   let thisQuery1 = ` `

//   if (role_id == 1) {
//       thisQuery1 += `SELECT`
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 ) AS contacts, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 ) AS leads, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 ) AS properties, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 ) AS tasks, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 ) AS transactions `
//     }
//   if (role_id == 2) {
//       thisQuery1 += `SELECT`
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}) AS contacts, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS leads, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS properties, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS tasks, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 and created_by = ${created_by} ) AS transactions `
//   }
//   if (role_id >= 2) {
//       thisQuery1 += `SELECT`
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS contacts, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS leads, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS properties, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS tasks, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 and created_by = ${created_by} ) AS transactions `
//   }

//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0][0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };
// exports.getDashboardBarCount = async (req, res) => {
//   try {
//     const module = req.params.moduleId;

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);

//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);

//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//     const userID = req.params.created_by;
//     const teamID = req.params.team_leader;

//     let thisQuery1 = ` `

//       let roleCheck = ``
//       if (role_id == 1) {
//         roleCheck = ` `
//       }
//       if (role_id == 2) {
//         roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//         roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
//       }
//       if (role_id >= 3) {
//         roleCheck = ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//       }
     
//     const queryString = req.query;

//     const timeLimit = req.params.id;

//     if(teamID == 0) {

//     if (timeLimit == 1) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       where c.created_by = ${userID} and (DATE(c.created_at) = DATE(NOW())) ${roleCheck} `
//     }
//     if (timeLimit == 2) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       where c.created_by = ${userID} and (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) ${roleCheck} `
//     }
//     if (timeLimit == 3) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DAYNAME(c.created_at) as dayname, DATE_FORMAT(c.created_at,'%Y-%m') as date FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c where c.created_by = ${userID} and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) GROUP BY DAYNAME(c.created_at) ${roleCheck} `
//     }
//     if (timeLimit == 4) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c where c.created_by = ${userID} and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month)) GROUP BY DATE(c.created_at) ${roleCheck} `
//     }
//     if (timeLimit == 5) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c where c.created_by = ${userID} and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 month)) GROUP BY DATE(c.created_at) ${roleCheck} `
//     }

//     // if (timeLimit == 6) {
//     //   thisQuery1 += `SELECT m.month,
//     //   IFNULL(n.count,0) count, IFNULL(n.date, 0) date FROM 
//     //   (SELECT 'January' AS MONTH UNION 
//     //   SELECT 'February' AS MONTH UNION 
//     //   SELECT 'March' AS MONTH UNION 
//     //   SELECT 'April' AS MONTH UNION 
//     //   SELECT 'May' AS MONTH UNION 
//     //   SELECT 'June' AS MONTH UNION 
//     //   SELECT 'July' AS MONTH UNION 
//     //   SELECT 'August' AS MONTH UNION 
//     //   SELECT 'September' AS MONTH UNION 
//     //   SELECT 'October' AS MONTH UNION 
//     //   SELECT 'November' AS MONTH UNION 
//     //   SELECT 'December' AS MONTH ) m 
//     //   LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//     //   COUNT(id) AS count, DATE_FORMAT(created_at, '%Y-%m') AS date FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
      
//     //   where c.created_by = ${userID} and YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//     //   group by monthname(created_at), 
//     //   month(created_at) 
//     //   order by month(created_at))n ON m.MONTH = n.MONTH `
//     // }

//     if (timeLimit == 6) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c where c.created_by = ${userID} and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 year)) GROUP BY MONTH(c.created_at) ${roleCheck} `
//     }
//     if (timeLimit == 7) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       where c.created_by = ${userID} and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') GROUP BY DATE(c.created_at) ${roleCheck} `
//     }

//     } else if (userID == 0) {

//     // Today
//     if (timeLimit == 1) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       LEFT JOIN lz_user as us on (us.id = c.created_by)
//       LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//       where us.team_leader = ${teamID} OR c.created_by = ${userID} and (DATE(c.created_at) = DATE(NOW())) ${roleCheck} `
//     }
//     // Yesterday
//     if (timeLimit == 2) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       LEFT JOIN lz_user as us on (us.id = c.created_by)
//       LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//       where us.team_leader = ${teamID} OR c.created_by = ${userID} and (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) ${roleCheck} `
//     }
//     // Last Week
//     if (timeLimit == 3) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DAYNAME(c.created_at) as dayname, DATE_FORMAT(c.created_at,'%Y-%m') as date FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       LEFT JOIN lz_user as us on (us.id = c.created_by)
//       LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//       where us.team_leader = ${teamID} OR c.created_by = ${userID} and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) GROUP BY DAYNAME(c.created_at) ${roleCheck} `
//     }
//     // Last Month
//     if (timeLimit == 4) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       LEFT JOIN lz_user as us on (us.id = c.created_by)
//       LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//       where us.team_leader = ${teamID} OR c.created_by = ${userID} and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month)) GROUP BY DATE(c.created_at) ${roleCheck} `
//     }
//     // This Month
//     if (timeLimit == 5) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       LEFT JOIN lz_user as us on (us.id = c.created_by)
//       LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//       where us.team_leader = ${teamID} OR c.created_by = ${userID} and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 month)) GROUP BY DATE(c.created_at) ${roleCheck} `
//     }
//      // This Year
//     // if (timeLimit == 6) {
//     //   thisQuery1 += `SELECT m.month, 
//     //   IFNULL(n.count,0) count FROM 
//     //   (SELECT 'January' AS MONTH UNION 
//     //   SELECT 'February' AS MONTH UNION 
//     //   SELECT 'March' AS MONTH UNION 
//     //   SELECT 'April' AS MONTH UNION 
//     //   SELECT 'May' AS MONTH UNION 
//     //   SELECT 'June' AS MONTH UNION 
//     //   SELECT 'July' AS MONTH UNION 
//     //   SELECT 'August' AS MONTH UNION 
//     //   SELECT 'September' AS MONTH UNION 
//     //   SELECT 'October' AS MONTH UNION 
//     //   SELECT 'November' AS MONTH UNION 
//     //   SELECT 'December' AS MONTH ) m 
//     //   LEFT JOIN( SELECT MONTHNAME(c.created_at) AS MONTH, 
//     //   COUNT(c.id) AS count FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//     //   LEFT JOIN lz_user as us on (us.id = c.created_by)
//     //   LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//     //   where us.team_leader = ${teamID} OR c.created_by = ${userID} and YEAR(c.created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//     //   group by monthname(c.created_at), 
//     //   month(c.created_at) 
//     //   order by month(c.created_at))n ON m.MONTH = n.MONTH `
//     // }

//     if (timeLimit == 6) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       LEFT JOIN lz_user as us on (us.id = c.created_by)
//       LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//       where us.team_leader = ${teamID} OR c.created_by = ${userID} and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 year)) GROUP BY MONTH(c.created_at) ${roleCheck} `
//     }

//     if (timeLimit == 7) {
//       thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : 'lz_transactions'} as c 
//       LEFT JOIN lz_user as us on (us.id = c.created_by)
//       LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//       where c.created_by = ${userID} and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') GROUP BY DATE(c.created_at) ${roleCheck} `
//     }

//     }

//     const dashboardData1 = await db2.sequelize.query(thisQuery1);
//     // const count_filter = (dashboardData1[0][0].count)
    
//     console.log("dashboardData1", thisQuery1);
//     // console.log("count_filter", count_filter);

//     res.status(200).send({
//       status: 200,
//       message: 'Success',
//       // count: count_filter,
//       output: dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };
// exports.getDashboardMastersCount = async (req, res) => {
//   try {
//     const module = req.params.moduleId;
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 
//     const masterId = req.params.option_type 

//     const userID = req.params.created_by;
//     const teamID = req.params.team_leader;

//     let thisQuery1 = ` `

//     const queryString = req.query;

//     let querydatebetween = await datebetween(queryString).then(dateBetween => {
//       return dateBetween;
//     });

//     let roleCheck = ``
//     if (role_id == 1) {
//       roleCheck = ` `
//     }
//     if (role_id == 2) {
//       roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//       roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
//     }
//     if (role_id >= 3) {
//       roleCheck = ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//     }

//     if (masterId) {
//       //   thisQuery1 += ` SELECT COUNT(c.${masterId}) as count, m.option_value as ${masterId} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' :  module == 3 ? 'lz_properties' :  module == 4 ? 'lz_tasks' : 'lz_transactions'} as c
//       //   LEFT JOIN lz_masters as m on (c.${masterId} = m.id)
//       //   LEFT JOIN lz_user as us on (us.id = c.created_by)
//       //   ${userID == 0 ? 'LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)': ''}
//       //   where c.status = 1 and m.option_type = '${masterId}' and ${userID != 0 ? 'c.created_by =' : `c.created_by =`} ${userID} ${querydatebetween}
//       //   group by m.option_value
//       //  `
//       if(teamID == 0) {
//         thisQuery1 += ` SELECT COUNT(c.${masterId}) as count, m.option_value as ${masterId} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' :  module == 3 ? 'lz_properties' :  module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : ""} as c
//         LEFT JOIN lz_masters as m on (c.${masterId} = m.id)
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and m.option_type = '${masterId}' and c.created_by = ${userID} ${querydatebetween} ${roleCheck}
//         group by m.option_value
//        `
//        console.log("Teamsssssssss");
       
//       } else if(userID == 0) {
//         thisQuery1 += ` SELECT COUNT(c.${masterId}) as count, m.option_value as ${masterId} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' :  module == 3 ? 'lz_properties' :  module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : "" } as c
//         LEFT JOIN lz_masters as m on (c.${masterId} = m.id)
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and m.option_type = '${masterId}' and us.team_leader = ${teamID} OR c.created_by = ${userID} OR c.created_by = ${teamID} ${querydatebetween} ${roleCheck}
//         group by m.option_value`
//       }
//       console.log("Teamsssssssss");
//     }
//     // console.log('userID', userID);
//     // console.log("teamID", teamID);
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };
// exports.getDashboardLocalityCount = async (req, res) => {
//   try {
//     const module = req.params.moduleId;
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 
//     const masterId = req.params.option_type 

//     const userID = req.params.created_by;
//     const teamID = req.params.team_leader;

//     let thisQuery1 = ` `

//     const queryString = req.query;

//     let querydatebetween = await datebetween(queryString).then(dateBetween => {
//       return dateBetween;
//     });

//     let roleCheck = ``
//     if (role_id == 1) {
//       roleCheck = ` `
//     }
//     if (role_id == 2) {
//       roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//       roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
//     }
//     if (role_id >= 3) {
//       roleCheck = ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//     }
//       if(teamID == 0) {
//         thisQuery1 += ` SELECT c.country as country, c.state as state, c.city as city FROM ${module == 1 ? 'lz_contact_address' : module == 2 ? 'lz_lead_requirements' :  module == 3 ? ' lz_property_addresses' :  module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : ""} as c
//         LEFT JOIN lz_user as us on (us.id = co.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         LEFT JOIN  ${module == 1 ? `lz_contacts` : module == 2 ? `lz_lead_requirements` : module == 3 ? `lz_property_addresses` : ''} as co on (co.id = c.id)
//         where co.status = 1 and co.created_by = ${userID} ${querydatebetween} ${roleCheck}
//         group by c.id
//        `
//        console.log("Teamsssssssss");
       
//       } else if(userID == 0) {
//         thisQuery1 += ` SELECT c.country as country, c.state as state, c.city as city FROM ${module == 1 ? 'lz_contact_address' : module == 2 ? 'lz_lead_requirements' :  module == 3 ? ' lz_property_addresses' :  module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : "" } as c
//         LEFT JOIN  ${module == 1 ? `lz_contacts` : module == 2 ? `lz_leads` : module == 3 ? `lz_properties` : ''} as co on (co.id = c.id)
//         LEFT JOIN lz_user as us on (us.id = co.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where co.status = 1 and us.team_leader = ${teamID} OR co.created_by = ${userID} OR co.created_by = ${teamID} ${querydatebetween} ${roleCheck}
//         group by c.id `
//       }
//       console.log("Teamsssssssss");
//     // console.log('userID', userID);
//     // console.log("teamID", teamID);
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);

//   const localityCountryData = dashboardData1[0][0]?.country
//   const localityStateData = dashboardData1[0][0]?.state
//   const localityCityData = dashboardData1[0][0]?.city
//   const countryData = await db['country'].findOne({
//     where: {
//       status: 1, id:localityCountryData
//     },
//     attributes:['name'],
//   });
//   const stateData = await db['state'].findOne({
//     where: {
//       status: 1, id:localityStateData
//     },
//     attributes:['name'],
//   });
//   const cityData = await db['city'].findOne({
//     where: {
//       status: 1, id:localityCityData
//     },
//     attributes:['name'],
//   });

//   // let thisQuery = ` `

//   // thisQuery = ` select co.name as country_name, s.name as state_name, ci.name as city_name from lz_country as co
//   // left join lz_state as s on (s.country_id = co.id)
//   // left join lz_city as c on (c.country_id = co.id)
//   // left join lz_city as ci on (c.state_id = s.id)
  
//   // `
//   // const localityData1 = await db.sequelize.query(thisQuery);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0],
//       locality: { country_name: countryData?.dataValues.name ?? "",  state_name: stateData?.dataValues.name ?? "",  city_name: cityData?.dataValues.name ?? ""}
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };
// exports.getDashboardTaskCount = async (req, res) => {
//   try {
//     const module = req.params.moduleId;
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 
//     const masterId = req.params.option_type 

//     let thisQuery1 = ` `

//     const queryString = req.query;

//     let querydatebetween = await datebetween(queryString).then(dateBetween => {
//       return dateBetween;
//     });

//     let roleCheck = ``
//     if (role_id == 1) {
//       roleCheck = ` `
//     }
//     if (role_id == 2) {
//       roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//       roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
//     }
//     if (role_id >= 3) {
//       roleCheck = ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//     }

//     if (module == 'contact') {
//         thisQuery1 += ` SELECT COUNT(c.task_status) as count, m.option_value as task_status FROM lz_tasks as c
//         LEFT JOIN lz_contacts as co on (c.contact = co.id)
//         LEFT JOIN lz_masters as m on (c.task_status = m.id)
//         where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} ${roleCheck}
//         group by m.option_value
//        `
//     }
//     if (module == 'project') {
//         thisQuery1 += ` SELECT COUNT(c.task_status) as count, m.option_value as task_status FROM lz_tasks as c
//         LEFT JOIN lz_properties as p on (c.project = p.id)
//         LEFT JOIN lz_masters as m on (c.task_status = m.id)
//         where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} ${roleCheck}
//         group by m.option_value
//        `
//     }
//     if (module == 'lead') {
//         thisQuery1 += ` SELECT COUNT(c.task_status) as count, m.option_value as task_status FROM lz_tasks as c
//         LEFT JOIN lz_contacts as co on (c.contact = co.id)
//         LEFT JOIN lz_leads as l on (l.contact_id = co.id)
//         LEFT JOIN lz_masters as m on (c.task_status = m.id)
//         where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} ${roleCheck}
//         group by m.option_value
//        `
//     }
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// exports.getDashboardLeadCount = async (req, res) => {
//   try {
//     const module = req.params.moduleId;
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 
//     const masterId = req.params.option_type 

//     const userID = req.params.created_by;
//     const teamID = req.params.team_leader;

//     let thisQuery1 = ` `

//     const queryString = req.query;

//     let querydatebetween = await datebetween(queryString).then(dateBetween => {
//       return dateBetween;
//     });

//     let roleCheck = ``
//     if (role_id == 1) {
//       roleCheck = ` `
//     }
//     if (role_id == 2) {
//       roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//       roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
//     }
//     if (role_id >= 3) {
//       roleCheck = ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//     }

//     if (masterId) {
//       if(teamID == 0) {
//         thisQuery1 += ` SELECT COUNT(c.${masterId}) as count, m.option_value as ${masterId} FROM lz_leads as c
//         LEFT JOIN lz_lead_requirements as lr on (c.lead_id = c.id)
//         LEFT JOIN lz_contacts as co on (co.lead_id = c.id)
//         ${masterId ? `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)` : `LEFT JOIN lz_masters as m on (lr.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and m.option_type = '${masterId}' and c.created_by = ${userID} ${querydatebetween} ${roleCheck}
//         group by m.option_value
//        `
//        console.log("Teamsssssssss");
       
//       } else if(userID == 0) {
//         thisQuery1 += ` SELECT COUNT(c.${masterId}) as count, m.option_value as ${masterId} FROM lz_leads as c
//         LEFT JOIN lz_lead_requirements as lr on (c.lead_id = c.id)
//         ${masterId ? `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)` : `LEFT JOIN lz_masters as m on (lr.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and m.option_type = '${masterId}' us.team_leader = ${teamID} OR c.created_by = ${userID} ${querydatebetween} ${roleCheck}
//         group by m.option_value
//        `
//       }
//       console.log("Teamsssssssss");
//     }
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };

// exports.getDashboardContactMasters = async (req, res) => {
//   try {
//     const module = req.params.moduleId;
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 
//     const masterId = req.params.option_type 

//     let thisQuery1 = ` `
//     // let todayCheck = ` (DATE(c.created_at) = DATE(NOW())) `
//     // let yesterdayCheck = ` (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//     // let monthCheck = ` SELECT m.month, 
//     // IFNULL(n.count,0) count FROM 
//     // (SELECT 'January' AS MONTH UNION 
//     // SELECT 'February' AS MONTH UNION 
//     // SELECT 'March' AS MONTH UNION 
//     // SELECT 'April' AS MONTH UNION 
//     // SELECT 'May' AS MONTH UNION 
//     // SELECT 'June' AS MONTH UNION 
//     // SELECT 'July' AS MONTH UNION 
//     // SELECT 'August' AS MONTH UNION 
//     // SELECT 'September' AS MONTH UNION 
//     // SELECT 'October' AS MONTH UNION 
//     // SELECT 'November' AS MONTH UNION 
//     // SELECT 'December' AS MONTH ) m 
//     // LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//     // COUNT(contact_status) AS count FROM lz_contacts `

//     const queryString = req.query;

//     let querydatebetween = await datebetween(queryString).then(dateBetween => {
//       return dateBetween;
//     });

//     if (masterId) {
//       // thisQuery1 += `SELECT COUNT(contact_status) as contacts_status FROM lz_contacts where status = 1 `
//       // if(timeLimit == 0) {
//         thisQuery1 += ` SELECT COUNT(c.${masterId}) as count, m.option_value as ${masterId} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' :  module == 3 ? 'lz_properties' :  module == 4 ? 'lz_tasks' : 'lz_transactions'} as c
//         LEFT JOIN lz_masters as m on (c.${masterId} = m.id)
//         where c.status = 1 and m.option_type = '${masterId}' and ${querydatebetween}
//         group by m.option_value
//        `
//       // }
//       // if(timeLimit == 1) {
//       //   // thisQuery1 += `SELECT COUNT(contact_status) as contacts_status_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       //   thisQuery1 +=  `SELECT COUNT(c.contact_status) as count, m.option_value as contact_status FROM lz_contacts as c
//       //   LEFT JOIN lz_masters as m on (c.contact_status = m.id)
//       //   where c.status = 1 and m.option_type = 'contact_status' and ${todayCheck}
//       //   group by m.option_value
//       //   `
//       // }
//       // if(timeLimit == 2) {
//       //   thisQuery1 +=  `SELECT COUNT(c.contact_status) as count, m.option_value as contact_status FROM lz_contacts as c
//       //   LEFT JOIN lz_masters as m on (c.contact_status = m.id)
//       //   where c.status = 1 and m.option_type = 'contact_status' and ${yesterdayCheck}
//       //   group by m.option_value
//       //   `
//       // }
//       // if (timeLimit == 6) {
//       //   thisQuery1 += `${monthCheck}
//       //   where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//       //   group by monthname(created_at), 
//       //   month(created_at) 
//       //   order by month(created_at))n ON m.MONTH = n.MONTH `
//       // }
//     }
//     if (masterId == 2) {
//       // thisQuery1 += `SELECT COUNT(contact_type) as contact_type FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(contact_type) as contact_type FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(contact_type) as contact_type_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(contact_type) as contact_type_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(contact_type) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
//     if (masterId == 3) {
//       // thisQuery1 += `SELECT COUNT(contact_category) as contact_category FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(contact_category) as contact_category FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(contact_category) as contact_category_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(contact_category) as contact_category_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(contact_category) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
//     if (masterId == 4) {
//       // thisQuery1 += `SELECT COUNT(source) as contacts_source FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(source) as source FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(source) as source_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(source) as source_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(source) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
//     if (masterId == 5) {
//       // thisQuery1 += `SELECT COUNT(contact_group) as contact_group FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(contact_group) as contact_group FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(contact_group) as contact_group_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(contact_group) as contact_group_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(contact_group) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };



// exports.getDashboardContactCount = async (req, res) => {
//   try {

//     const module = req.params.moduleId;

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 

//   // let thisQuery1 = ` `

//   // if (timeLimit == 1) {
//   //   thisQuery1 += ` SELECT COUNT(id) as today_contact_count FROM lz_contacts where (DATE(created_at) = DATE(NOW()))`
//   // }
//   // if (timeLimit == 2) {
//   //   thisQuery1 += ` SELECT COUNT(id) as yesterday_contact_count FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//   // }
//   // if (timeLimit == 3) {
//   //   thisQuery1 += ` SELECT COUNT(id) as lastweek_contact_count, WEEK(created_at) as week_name FROM lz_contacts where (created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) group by DAY(created_at) order by DAY(created_at) `
//   // }
//   // if (timeLimit == 4) {
//   //   thisQuery1 += ` SELECT COUNT(id) as lastweek_contact_count FROM lz_contacts where (created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND created_at < last_day(curdate() - interval 1 month)) group by DATE(created_at) order by DATE(created_at) `
//   // }

//   // if (timeLimit == 6) {
//   //     thisQuery1 += `SELECT m.month, 
//   //     IFNULL(n.count,0) count FROM 
//   //     (SELECT 'January' AS MONTH UNION 
//   //     SELECT 'February' AS MONTH UNION 
//   //     SELECT 'March' AS MONTH UNION 
//   //     SELECT 'April' AS MONTH UNION 
//   //     SELECT 'May' AS MONTH UNION 
//   //     SELECT 'June' AS MONTH UNION 
//   //     SELECT 'July' AS MONTH UNION 
//   //     SELECT 'August' AS MONTH UNION 
//   //     SELECT 'September' AS MONTH UNION 
//   //     SELECT 'October' AS MONTH UNION 
//   //     SELECT 'November' AS MONTH UNION 
//   //     SELECT 'December' AS MONTH ) m 
//   //     LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//   //     COUNT(id) AS count FROM lz_contacts 
//   //     where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//   //     group by monthname(created_at), 
//   //     month(created_at) 
//   //     order by month(created_at))n ON m.MONTH = n.MONTH `
//   // }

//   let thisQuery1 = ` `

//   const queryString = req.query;

//   let querydatebetween = await datebetween(queryString).then(dateBetween => {
//     return dateBetween;
//   });

//       thisQuery1 += ` SELECT COUNT(c.id) as count, DAYNAME(c.created_at) as dayname FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' :  module == 3 ? 'lz_properties' :  module == 4 ? 'lz_tasks' : 'lz_transactions'} as c
//       where c.status = 1 ${querydatebetween}
//       group by c.id
//      `
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// const roleCheck = async () => {

//   const module = req.params.moduleId;
//   const created_id = req.user.id
//   const created_by = created_id.id
//   console.log('created_by', created_by);

//   const organ_id = req.user.id
//   const org_id = organ_id.org_id
//   console.log('organ_id', org_id);

//   const role = req.user.id
//   const role_id = 1
//   console.log('role_id', role_id);

//   if (role_id == 1) {
//     thisQuery += ` `
//   }
//   if (role_id == 2) {

//     thisQuery += ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `

//     thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
//   }
//   if (role_id >= 3) {
//     thisQuery += ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//   }
//   return thisQuery;
// }


// exports.getDashboardCount = async (req, res) => {
//   try {

//   // let thisQuery = ` SELECT designation from lz_user where id ='${created_by}' limit 1 `
//   // const dashboardData = await db2.sequelize.query(thisQuery);
//   // const dataDashboard = dashboardData[0]
//   // console.log("dashboardData", dataDashboard);

//   // const role = dataDashboard[0] ? dataDashboard[0]["designation"] : 0 role.designation

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//   let thisQuery1 = ` `

  // if (role_id == 1) {
  //     thisQuery1 += `SELECT`
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 ) AS contacts, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 ) AS leads, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 ) AS properties, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 ) AS tasks, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 ) AS transactions `
  //   }
  // if (role_id == 2) {
  //     thisQuery1 += `SELECT`
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}) AS contacts, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS leads, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS properties, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS tasks, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 and created_by = ${created_by} ) AS transactions `
  // }
//   if (role_id >= 2) {
//       thisQuery1 += `SELECT`
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS contacts, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS leads, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS properties, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS tasks, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 and created_by = ${created_by} ) AS transactions `
//   }

//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0][0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// exports.getDashboardCount = async (req, res) => {
//   try {

//     const module = req.params.moduleId;

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 4
//     console.log('role_id', role_id);

//   let thisQuery1 = ` `

//   let roleCheck = ``
//   if (role_id == 1) {
//     roleCheck = ` `
//   }
//   if (role_id == 2) {
//     roleCheck = ` where FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//     roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
//   }
//   if (role_id >= 3) {
//     roleCheck = ` where c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//   }

//   if (role_id == 1) {
//     thisQuery1 += `SELECT`
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 ) AS contacts, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 ) AS leads, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 ) AS properties, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 ) AS tasks, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 ) AS transactions `
//   }
//   if (role_id >= 2) {
//       thisQuery1 += `SELECT`
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts ${roleCheck}) AS contacts, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads ${roleCheck} ) AS leads, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties ${roleCheck} ) AS properties, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks ${roleCheck} ) AS tasks, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions ${roleCheck} ) AS transactions `
//   }

//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0][0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };