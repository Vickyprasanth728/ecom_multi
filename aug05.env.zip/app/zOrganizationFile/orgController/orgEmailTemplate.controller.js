const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

exports.create = async (req, res) => {
    try {
      const created_by = req.user.id
      console.log('created_by', created_by.id);

      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);
  
      const data = await db2['emailTemplate'].create({
        name_of_template: req.body.name_of_template,
        title: req.body.title,
        subject: req.body.subject,
        share_with: req.body.share_with,
        body: req.body.body,
        status: req.body.status,
        created_by: created_by.id
      });
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.findAll = async (req, res) => {
    try {
        const organ_id = req.user.id
        const org_id = organ_id.org_id
        console.log('organ_id', org_id);

      var condition = {
        where:{
          status:1
        },
        order: [['id', 'DESC']], // ASC, DESC
        attributes:{exclude:['createdAt','updatedAt']}
      };
      var offset = parseInt(req.query.offset);
      var limit = parseInt(req.query.limit);
  
      if (offset >= 0 && limit >= 0) {
        condition.offset = offset;
        condition.limit = limit;
      }
  
      const data = await db2['emailTemplate'].findAll(condition);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.findOne = async (req, res) => {

try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;
    const data = await db2[req.params.document].findAll({
    where: {
        id: id, status:1
        },
        attributes: {exclude :['createdAt','updatedAt']}
    }
    );
    if (data) {
    res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.update = async (req, res) => {
try {
    const id = req.params.id;
    const num = await db2['emailTemplate'].update(req.body, {
    where: { id: id },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Updated successfully."
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};
exports.delete = async (req, res) => {
const MastersData = {
    status: 0,
}
try {
    const id = req.params.id;
    const num = await db2['emailTemplate'].update(MastersData,{
    where: { id: id },
    });
    if (num == 1) {
    res.status(200).send({
        status:200,
        message: "Deleted successfully!"
    });
    } else {
    res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
    });
    }
} catch (error) {
    res.status(500).send({
    message: error.message,
    });
}
};