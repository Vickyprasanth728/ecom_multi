const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;
const dbConfig = require("../../config/db.config.js");
const mailer = require("../orgModel/mailer.model.js");
const DbName = dbConfig.DB_DATABASE

exports.saveTransaction = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const data = await db2['transaction'].create({
      org_id: org_id,
      lead_id: req.body.lead_id,
      booking_date: req.body.booking_date,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      lead_source: req.body.lead_source,
      team_leader: req.body.team_leader,
      shared_with: req.body.shared_with,
      closed_by: req.body.closed_by,
      transaction_status: req.body.transaction_status,
      developer_name: req.body.developer_name,
      project_name: req.body.project_name,
      client_name: req.body.client_name,
      contact_number: req.body.contact_number,
      email_id: req.body.email_id,
      dob: req.body.dob,
      anniversary_date: req.body.anniversary_date,
      discount_amount: req.body.discount_amount,
      block_no: req.body.block_no,
      unit_no: req.body.unit_no,
      floor_no: req.body.floor_no,
      bhk_type: req.body.bhk_type,
      unit_size: req.body.unit_size,
      plot_size: req.body.plot_size,
      frc: req.body.frc,
      plc: req.body.plc,
      basic_price: req.body.basic_price,
      car_parking_cost: req.body.basic_price,
      pan: req.body.pan,
      agreement_value: req.body.agreement_value,
      brokerage_percentage	: req.body.brokerage_percentage	,
      brokerage_value: req.body.brokerage_value,
      aop_percentage: req.body.aop_percentage,
      discount_value: req.body.discount_value,
      discount_paid_status: req.body.discount_paid_status,
      tds_value: req.body.tds_value,
      revenue: req.body.revenue,
      created_by: created_by
    });
    
    const TransactionID = data?.dataValues.id
    const data1 = await db2['transactionBrokerageDetails'].create({
        transaction_id: TransactionID,
        s_gst_per: req.body.s_gst_per,
        c_gst_per: req.body.c_gst_per,
        i_gst_per: req.body.i_gst_per,
        gst_amount: req.body.gst_amount,
        gross_brokerage_value: req.body.gross_brokerage_value,
        tds_reducted_by_builder: req.body.tds_reducted_by_builder,
        tds_per: req.body.tds_per,
        tds_amount: req.body.tds_amount,
        after_tds_brokerage: req.body.after_tds_brokerage,
        actual_receivable_amount: req.body.actual_receivable_amount,
        incentive_per: req.body.incentive_per,
        incentive_without_tds: req.body.incentive_without_tds,
        net_incentive_earned: req.body.net_incentive_earned,
        invoice_status: req.body.invoice_status,
    })
    const data2 = await db2['transactionInvoicingDetails'].create({
        transaction_id: TransactionID,
        raised: req.body.raised || null,
        pending: req.body.pending || null,
        payment_status: req.body.payment_status || null,
        amount_received: req.body.amount_received || null,
        receiving_date: req.body.receiving_date || null,
        pending_brokerage: req.body.pending_brokerage || null,
        s_gst_2: req.body.s_gst_2 || null,
        c_gst_3: req.body.c_gst_3 || null,
        i_gst_4: req.body.i_gst_4 || null,
        gst_amount2: req.body.gst_amount2 || null,
        gross_brokerage_value2: req.body.gross_brokerage_value2 || null,
        tds_reducted_by_builder3: req.body.tds_reducted_by_builder3 || null,
        tds_amount2: req.body.tds_amount2 || null,
        after_tds_brokearge5: req.body.after_tds_brokearge5 || null,
        pending_receivable_amount: req.body.pending_receivable_amount || null
    })
    const TransactionLogs = await db2['logs'].create({
        org_id: org_id,
        module_id: TransactionID,
        module_name: "5",
        note: "Transaction created at",
        user_id: created_by
    })

    // Email Trigger
    const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where module_id = 5 and status = 1 `);
    // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
    const emailTri = email_settings[0][0]["status"]
    console.log("emailTri", emailTri);

    //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
    
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let thisQueryPro = `select p.id as id, pa.name_of_building as property_name
      from lz_properties p
      left join lz_property_addresses as pa on (p.id = pa.property_id)
      where p.status = 1 and pa.property_id = '${req.body.project_name}' `;

      const project_name_data = await db2.sequelize.query(thisQueryPro)
      console.log("project_name_data", project_name_data[0][0]);

      const project_name = project_name_data[0][0] ? project_name_data[0][0].property_name : 0
      console.log('project_name', project_name);

      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1].join(', '),
        subject: "New Transaction Created",
        html:
          "<h3> New Transaction has been created with </h3>" +
          "<h3> Project Id: </h3>" +
          req.body.project_name +
          "<h3>Project Name:</h3>" +
          project_name + "",
      };
      console.log("message", message);
      mailer.sendMail(message, function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getTransactions = async (req, res) => {
    try {
      const created_id = req.user.id
      const created_by = created_id.id
      console.log('created_by', created_by);
    
      const organ_id = req.user.id
      const org_id = organ_id.org_id
      console.log('organ_id', org_id);
    
      const role = req.user.id
      const role_id = role.designation
      console.log('role_id', role_id);
    
    let thisQuery = `SELECT t.*, GROUP_CONCAT(distinct CONCAT(us1.first_name,' ',IFNULL(us1.last_name, ''),'-',us1.id)) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us.first_name,' ',IFNULL(us.last_name, ''),'-',us.id)) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us2.first_name,' ',IFNULL(us2.last_name, ''),'-',us2.id)) as closed_by_name, CONCAT(us3.first_name,' ',IFNULL(us1.last_name, '')) as created_by_name, CONCAT(c.first_name,' ',IFNULL(c.last_name, '')) as contact_client_name, c1.developer_name as developer_full_name, p.name_of_building as property_name_of_building, cou.name as country_name, st.name as state_name, ci.name as city_name, ca.address_1 as client_address_1, ca.address_2 as client_address_2, ca.locality as client_address_locality, ca.country as client_address_country,ca.city as client_address_city,ca.state as client_address_state, tpd.s_gst_per as s_gst_per, tpd.c_gst_per as c_gst_per, tpd.i_gst_per as i_gst_per, tpd.gst_amount as gst_amount, tpd.gross_brokerage_value as gross_brokerage_value, tpd.tds_per as tds, tpd.tds_amount as tds_amount, tpd.after_tds_brokerage as after_tds_brokerage, tpd.actual_receivable_amount as actual_receivable_amount, tpd.incentive_per as incentive_per, tpd.incentive_without_tds as incentive_without_tds, tpd.tds_per as tds_per, tpd.net_incentive_earned as net_incentive_earned, tpd.invoice_status as invoice_status, tps.raised as raised, tps.pending as pending, tps.payment_status as payment_status, tps.amount_received as amount_received, tps.receiving_date as receiving_date, tps.pending_brokerage as pending_brokerage, tps.s_gst_2 as s_gst_2, tps.c_gst_3 as c_gst_3, tps.i_gst_4 as i_gst_4, tps.gst_amount2 as gst_amount2, tps.gross_brokerage_value2 as gross_brokerage_value2, tps.tds_reducted_by_builder3 as tds_reducted_by_builder3, tps.tds_amount2 as tds_amount2, tps.after_tds_brokearge5 as after_tds_brokearge5, tps.pending_receivable_amount as pending_receivable_amount, so.option_value as source_name, ts.option_value as transaction_status_name, tpd.tds_reducted_by_builder as tds_reducted_by_builder,

    (SELECT COUNT(id) FROM lz_notes where status = 1 and (module_id = t.id and module_name = 5 or (module_id = t.client_name and module_name = 1) or (module_id = t.lead_id and module_name = 2) or (module_id = t.project_name and module_name = 3))) as notes_count,
    (SELECT COUNT(id) FROM lz_file_uploads where module_id = t.id and module_name = 5) as files_count
    FROM lz_transactions as t
    left join lz_transaction_brokerage_details as tpd on (tpd.transaction_id = t.id)
    left join lz_transaction_invoicing_details as tps on (tps.transaction_id = t.id)
    LEFT JOIN lz_leads as l on (l.id = t.lead_id)
    LEFT JOIN lz_contacts as c on (c.id = t.client_name)
    LEFT JOIN lz_contacts as c1 on (c1.id = t.developer_name)
    LEFT JOIN lz_contact_address as ca on (ca.contact_id = c.id)
    LEFT JOIN lz_properties as pro on (pro.id = t.project_name)
    LEFT JOIN lz_property_addresses as p on (pro.id = p.property_id)
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.shared_with)>0
    LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,t.team_leader)>0
    LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,t.closed_by)>0
    LEFT JOIN lz_user as us3 on FIND_IN_SET(us3.id,t.created_by)>0
    left join lz_masters as so on (so.id = t.lead_source) 
    left join lz_masters as ts on (ts.id = t.transaction_status) 
    LEFT JOIN ${DbName}.lz_country as cou on (cou.id = t.country)
    LEFT JOIN ${DbName}.lz_state as st on (st.id = t.state)
    LEFT JOIN ${DbName}.lz_city as ci on (ci.id = t.city)
    where t.status = 1 `

    if (role_id == 1) {
      thisQuery += ` `
    }
    if (role_id == 2) {
      thisQuery += ` and (us3.team_leader = ${created_by} or us3.portfolio_head = ${created_by} or t.created_by = ${created_by}) `
    }
    if (role_id == 3) {
      thisQuery += ` and (us3.team_leader = ${created_by} or us3.portfolio_head = ${created_by} or t.created_by = ${created_by}) `
    }
    if (role_id == 4) {
      thisQuery += ` and (t.created_by = ${created_by}) `
    }
    if (role_id == 5) {
      thisQuery += ` `
    }
    if (role_id == 6) {
      thisQuery += `and t.created_by = ${created_by} `
    }
    if (role_id >= 7) {
      thisQuery += `and t.created_by = ${created_by} `
    }

    const filters = req.query;

    // if (filters.source) {
    //   var a = filters.source;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', t.lead_source, ',') REGEXP ',(${a}),' `
    // }
    if (filters.source) {
      var a = filters.source;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (t.lead_source IN (" + a1 + ")" + ` OR CONCAT(',', t.lead_source, ',') REGEXP ',(${a}),' )`
    }
    if (filters.transaction_status) {
      var a = filters.transaction_status;
      var b = a.replace(/[,]/g, ",");
      thisQuery += `and CONCAT(',', t.transaction_status, ',') REGEXP ',(${a}),' `
    }
    // if (filters.city) {
    //   var a = filters.city;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', t.city, ',') REGEXP ',(${a}),' `
    // }
    if (filters.city) {
      var a = filters.city;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (t.city IN (" + a1 + ")" + ` OR CONCAT(',', t.city, ',') REGEXP ',(${a}),' )`
    }
    // if (filters.team_leader) {
    //   var a = filters.team_leader;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', t.team_leader, ',') REGEXP ',(${a}),' `
    // }
    if (filters.team_leader) {
      var a = filters.team_leader;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (t.team_leader IN (" + a1 + ")" + ` OR CONCAT(',', t.team_leader, ',') REGEXP ',(${a}),' )`
    }
    // if (filters.shared_with) {
    //   var a = filters.shared_with;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', t.shared_with, ',') REGEXP ',(${a}),' `
    // }
    if (filters.shared_with) {
      var a = filters.shared_with;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (t.shared_with IN (" + a1 + ")" + ` OR CONCAT(',', t.shared_with, ',') REGEXP ',(${a}),' )`
    }
    // if (filters.closed_by) {
    //   var a = filters.closed_by;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', t.closed_by, ',') REGEXP ',(${a}),' `
    // }
    if (filters.closed_by) {
      var a = filters.closed_by;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (t.closed_by IN (" + a1 + ")" + ` OR CONCAT(',', t.closed_by, ',') REGEXP ',(${a}),' )`
    }
    // if (filters.project_id) {
    //   var a = filters.project_id;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', t.project_name, ',') REGEXP ',(${a}),' `
    // }
    if (filters.project_id) {
      var a = filters.project_id;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (t.project_name IN (" + a1 + ")" + ` OR CONCAT(',', t.project_name, ',') REGEXP ',(${a}),' )`
    }
    // if (filters.developer_name) {
    //   var a = filters.developer_name;
    //   var b = a.replace(/[,]/g, ",");
    //   thisQuery += `and CONCAT(',', t.developer_name, ',') REGEXP ',(${a}),' `
    // }
    if (filters.developer_name) {
      var a = filters.developer_name;
      let a1 = a.split(',').map(item => `'${item}'`).join(',');
      // thisQuery += `and CONCAT(',', c.assign_to, ',') REGEXP ',(${a1}),' `
      thisQuery += " and (t.developer_name IN (" + a1 + ")" + ` OR CONCAT(',', t.developer_name, ',') REGEXP ',(${a}),' )`
    }
    if (filters.booking_from_date && filters.booking_to_date) {
      // thisQuery += "and c.created_at = " + `'${filters.created_at}' `
      thisQuery += ` and (DATE_FORMAT(t.booking_date,'%Y-%m-%d') >= '${filters.booking_from_date}' AND DATE_FORMAT(t.booking_date,'%Y-%m-%d') <= '${filters.booking_to_date}') `
    }
    if (filters.bhk_type_min && filters.bhk_type_max) {
        thisQuery += " and t.bhk_type between " + `'${filters.bhk_type_min}'` + ` and '${filters.bhk_type_max}' `
    }
    if (filters.agreement_value_min && filters.agreement_value_max) {
        thisQuery += " and t.agreement_value between " + `'${filters.agreement_value_min}'` + ` and '${filters.agreement_value_max}' `
    }
    if (filters.brokerage_percentage_min && filters.brokerage_percentage_max) {
        thisQuery += " and t.brokerage_percentage between " + `'${filters.brokerage_percentage_min}'` + ` and '${filters.brokerage_percentage_max}' `
    }
    if (filters.brokerage_value_min && filters.brokerage_value_max) {
        thisQuery += " and t.brokerage_value between " + `'${filters.brokerage_value_min}'` + ` and '${filters.brokerage_value_max}' `
    }
    if (filters.brokerage_value_min && filters.brokerage_value_max) {
        thisQuery += " and t.brokerage_value between " + `'${filters.brokerage_value_min}'` + ` and '${filters.brokerage_value_max}' `
    }
    if (filters.discount_value_min && filters.discount_value_max) {
        thisQuery += " and t.discount_value between " + `'${filters.discount_value_min}'` + ` and '${filters.discount_value_max}' `
    }
    if (filters.revenue_min && filters.revenue_max) {
        thisQuery += " and t.revenue between " + `'${filters.revenue_min}'` + ` and '${filters.revenue_max}' `
    }

    thisQuery += ' group by t.id '

    if (filters.order_by) {
      let orderByString = filters.order_by.split('|')
      thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
    }
    const data1 = await db2.sequelize.query(thisQuery);

    if (filters.order_by =="" || filters.order_by == undefined) {
      thisQuery += ' order by t.id DESC '
    }

    if (filters.limit) {
        thisQuery += ` limit ${filters.limit},12 `
    }

    const data = await db2.sequelize.query(thisQuery);

    const count_filter = (data1[0])

      res.status(200).send({
        status:200,
        message:'Success',
        count: count_filter.length,
        output:data[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.editTransaction = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const DbName = dbConfig.DB_DATABASE
    console.log("dbName", DbName);

    const TransactionId = req.params.id
    
    let thisQuery = `SELECT t.*, GROUP_CONCAT(distinct CONCAT(us1.first_name,' ',IFNULL(us1.last_name, ''),'-',us1.id)) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us.first_name,' ',IFNULL(us.last_name, ''),'-',us.id)) as shared_with_name, GROUP_CONCAT(distinct CONCAT(us2.first_name,' ',IFNULL(us2.last_name, ''),'-',us2.id)) as closed_by_name, CONCAT(us3.first_name,' ',us3.last_name,'-',us3.id) as created_by_name, CONCAT(c.first_name,' ',c.last_name) as contact_client_name, CONCAT(c1.first_name,' ',c1.last_name) as developer_fullname,p.name_of_building as property_name_of_building, ca.address_1 as client_address_1, ca.address_2 as client_address_2, ca.locality as client_address_locality, ca.country as client_address_country,ca.city as client_address_city,ca.state as client_address_state, tpd.s_gst_per as s_gst_per, tpd.c_gst_per as c_gst_per, tpd.i_gst_per as i_gst_per, tpd.gst_amount as gst_amount, tpd.gross_brokerage_value as gross_brokerage_value, tpd.tds_per as tds, tpd.tds_amount as tds_amount, tpd.after_tds_brokerage as after_tds_brokerage, tpd.actual_receivable_amount as actual_receivable_amount, tpd.incentive_per as incentive_per, tpd.incentive_without_tds as incentive_without_tds, tpd.tds_per as tds_per, tpd.net_incentive_earned as net_incentive_earned, tpd.invoice_status as invoice_status, tps.raised as raised, tps.pending as pending, tps.payment_status as payment_status, tps.amount_received as amount_received, tps.receiving_date as receiving_date, tps.pending_brokerage as pending_brokerage, tps.s_gst_2 as s_gst_2, tps.c_gst_3 as c_gst_3, tps.i_gst_4 as i_gst_4, tps.gst_amount2 as gst_amount2, tps.gross_brokerage_value2 as gross_brokerage_value2, tps.tds_reducted_by_builder3 as tds_reducted_by_builder3, tpd.tds_reducted_by_builder as tds_reducted_by_builder, tps.tds_amount2 as tds_amount2, tps.after_tds_brokearge5 as after_tds_brokearge5, tps.pending_receivable_amount as pending_receivable_amount, so.option_value as source_name, ts.option_value as transaction_status_name  
    FROM lz_transactions as t
    left join lz_transaction_brokerage_details as tpd on (tpd.transaction_id = t.id)
    left join lz_transaction_invoicing_details as tps on (tps.transaction_id = t.id)
    LEFT JOIN lz_leads as l on (l.id = t.lead_id)
    LEFT JOIN lz_contacts as c on (c.id = l.contact_id)
    LEFT JOIN lz_contacts as c1 on (c1.id = t.developer_name)
    LEFT JOIN lz_contact_address as ca on (ca.contact_id = c.id)
    LEFT JOIN lz_property_addresses as p on (p.property_id=t.project_name)
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.shared_with)>0
    LEFT JOIN lz_user as us1 on FIND_IN_SET(us1.id,t.team_leader)>0
    LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,t.closed_by)>0
    LEFT JOIN lz_user as us3 on (us3.id=t.created_by) 
    left join lz_masters as so on (so.id = t.lead_source) 
    left join lz_masters as ts on (ts.id = t.transaction_status) 
    LEFT JOIN ${DbName}.lz_country as cou on (cou.id = t.country)
    LEFT JOIN ${DbName}.lz_state as st on (st.id = t.state)
    LEFT JOIN ${DbName}.lz_city as ci on (ci.id = t.city)
    where t.status = 1  and t.id = ${TransactionId} `

    thisQuery += ' group by t.id '

    const data = await db2.sequelize.query(thisQuery);

    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0][0]
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateTransaction = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;
    const TransactionID = req.params.id;

    let thisQuery = ` select t.client_name as contact_id, c.first_name as contact_name, t.lead_source as source, so.option_value as source_name, t.transaction_status as transaction_status, cs.option_value as transaction_status_name, t.project_name as property_id, pa.name_of_building as property_name, t.contact_number as contact_number, t.email_id as email_id
    from lz_transactions as t
    left join lz_contacts as c on (c.id = t.client_name)
    left join lz_properties as p on (p.id = t.project_name)
    left join lz_property_addresses as pa on (p.id = pa.property_id)
    left join lz_masters as so on (so.id = t.lead_source)
    left join lz_masters as cs on (cs.id = t.transaction_status)
    where t.status = 1 and t.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery);

    const dataContactID = data123[0][0]?.contact_id
    const dataContactName = data123[0][0]?.contact_name
    const dataContactNumber = data123[0][0]?.contact_number
    const dataContactEmail = data123[0][0]?.email_id
    const dataSource = data123[0][0]?.source
    const dataSourceName = data123[0][0]?.source_name
    const dataStatus = data123[0][0]?.transaction_status
    const dataStatusName = data123[0][0]?.transaction_status_name
    const dataProperty = data123[0][0]?.property_id
    const dataPropertyName = data123[0][0]?.property_name
    
    console.log("dataContactNumber", dataContactNumber);
    console.log("dataContactEmail", dataContactEmail);
    console.log("dataContactID", dataContactID);
    console.log("dataContactName", dataContactName);
    console.log("dataSource", dataSource);
    console.log("dataSourceName", dataSourceName);
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);
    console.log("dataProperty", dataProperty);
    console.log("dataPropertyName", dataPropertyName);

    const data = {
        lead_id: req.body.lead_id,
        booking_date: req.body.booking_date,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city,
        lead_source: req.body.lead_source,
        team_leader: req.body.team_leader,
        shared_with: req.body.shared_with,
        closed_by: req.body.closed_by,
        transaction_status: req.body.transaction_status,
        developer_name: req.body.developer_name,
        project_name: req.body.project_name,
        client_name: req.body.client_name,
        contact_number: req.body.contact_number,
        email_id: req.body.email_id,
        dob: req.body.dob,
        anniversary_date: req.body.anniversary_date,
        discount_amount: req.body.discount_amount,
        block_no: req.body.block_no,
        unit_no: req.body.unit_no,
        floor_no: req.body.floor_no,
        bhk_type: req.body.bhk_type,
        unit_size: req.body.unit_size,
        plot_size: req.body.plot_size,
        frc: req.body.frc,
        plc: req.body.plc,
        basic_price: req.body.basic_price,
        car_parking_cost: req.body.basic_price,
        pan: req.body.pan,
        agreement_value: req.body.agreement_value,
        brokerage_percentage	: req.body.brokerage_percentage	,
        brokerage_value: req.body.brokerage_value,
        aop_percentage: req.body.aop_percentage,
        discount_value: req.body.discount_value,
        discount_paid_status: req.body.discount_paid_status,
        tds_value: req.body.tds_value,
        revenue: req.body.revenue,
    }
    const num = await db2['transaction'].update(data, {
      where: { id: id },
    });
    if (num == 1) {
        // Source
        if(req.body.lead_source) {
          let thisQuery456 = ` select t.lead_source as l_source, so.option_value as l_source_name
          from lz_transactions as t
          left join lz_masters as so on (so.id = t.lead_source)
          where t.status = 1 and t.lead_source = ${req.body.lead_source}
          `
          const dataSO = await db2.sequelize.query(thisQuery456);
          const dataSO1 = dataSO[0][0]?.l_source
          const dataSO2 = dataSO[0][0]?.l_source_name
          console.log("dataSO1", dataSO1);
          console.log("dataSO2", dataSO2);

        if(dataSource.toString() !== req.body.lead_source.toString()) {
          const TransactionSourceLog = await db2['logs'].create({
            org_id: org_id,
            module_id: TransactionID,
            module_name: "5",
            note: 'Transaction lead source : ' + dataSourceName + ' to '+ dataSO2,
            user_id: created_by.id
          })
          console.log("Transaction Lead Source",TransactionSourceLog.dataValues.note);
        }
        }
        // Lead Status
        if(req.body.transaction_status) {
          let thisQuery456 = ` select t.transaction_status as l_status, ts.option_value as l_status_name
          from lz_transactions as t
          left join lz_masters as ts on (ts.id = t.transaction_status)
          where t.status = 1 and t.transaction_status = ${req.body.transaction_status}
          `
          const dataCS = await db2.sequelize.query(thisQuery456);
          const dataCS1 = dataCS[0][0]?.l_status
          const dataCS2 = dataCS[0][0]?.l_status_name
          console.log("dataCS1", dataCS1);
          console.log("dataCS2", dataCS2);

        if(dataStatus.toString() !== req.body.transaction_status.toString()) {
          const TransactionStatusLog = await db2['logs'].create({
            org_id: org_id,
            module_id: TransactionID,
            module_name: "5",
            note: 'Transaction lead status : ' + dataStatusName + ' to '+ dataCS2,
            user_id: created_by.id
          })
          console.log("Transaction Lead Status",TransactionStatusLog.dataValues.note);
        }
        }
        // Contact Name
        if(req.body.client_name) {
          let thisQuery456 = ` select t.client_name as l_contact_id, c.first_name as l_contact_name
          from lz_transactions as t
          left join lz_contacts as c on (c.id = t.client_name)
          where t.status = 1 and t.client_name = ${req.body.client_name}
          `
          const dataC = await db2.sequelize.query(thisQuery456);
          const dataC1 = dataC[0][0]?.l_contact_id
          const dataC2 = dataC[0][0]?.l_contact_name
          console.log("dataC1", dataC1);
          console.log("dataC2", dataC2);

        if(dataContactID.toString() !== req.body.client_name.toString()) {
          const TransactionContactLog = await db2['logs'].create({
            org_id: org_id,
            module_id: TransactionID,
            module_name: "5",
            note: 'Transaction contact name : ' + dataContactName + ' to '+ dataC2,
            user_id: created_by.id
          })
          console.log("Transaction Contact name",TransactionContactLog.dataValues.note);
        }
        }
          // Property Name
        if(req.body.project_name) {
          let thisQueryPro = ` select t.project_name as l_property_id, pa1.name_of_building as l_property_name
          from lz_transactions as t
          left join lz_properties as p on (p.id = t.project_name)
          left join lz_property_addresses as pa1 on (p.id = pa1.property_id)
          where t.status = 1 and t.project_name = ${req.body.project_name}
          `
          const dataPro = await db2.sequelize.query(thisQueryPro);
          const dataPro1 = dataPro[0][0]?.l_property_id
          const dataPro2 = dataPro[0][0]?.l_property_name
          console.log("dataPro1", dataPro1);
          console.log("dataPro2", dataPro2);

        if(dataProperty.toString() !== req.body.project_name.toString()) {
          const TransactionPropertyLog = await db2['logs'].create({
            org_id: org_id,
            module_id: TransactionID,
            module_name: "5",
            note: 'Transaction propery name : ' + dataPropertyName + ' to '+ dataPro2,
            user_id: created_by.id
          })
          console.log("Transaction Property name", TransactionPropertyLog.dataValues.note);
        }
        }
        // Contact Number
        if(req.body.contact_number) {
          if(dataContactNumber.toString() !== req.body.contact_number.toString()) {
            const contactMobLog = await db2['logs'].create({
              org_id: org_id,
              module_id: TransactionID,
              module_name: "5",
              note: 'Transaction Mobile : ' + dataContactNumber + ' TO '+ req.body.contact_number,
              user_id: created_by.id
            })
            console.log("Mobile_no",contactMobLog.dataValues.note);
          }
        }
        // Email ID
        if(req.body.email_id) {
          if(dataContactEmail !== req.body.email_id) {
            const contactEmailLog = await db2['logs'].create({
              org_id: org_id,
              module_id: TransactionID,
              module_name: "5",
              note: 'Transaction Email : ' + dataContactEmail + ' TO '+ req.body.email_id,
              user_id: created_by.id
            })
            console.log("email",contactEmailLog.dataValues.note);
          }
        }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateBrokerageDetails = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const id = req.params.id;
    const transaction_id = req.params.transaction_id;
    const data = {
      s_gst_per: req.body.s_gst_per,
      c_gst_per: req.body.c_gst_per,
      i_gst_per: req.body.i_gst_per,
      gst_amount: req.body.gst_amount,
      gross_brokerage_value: req.body.gross_brokerage_value,
      tds_reducted_by_builder: req.body.tds_reducted_by_builder,
      tds_per: req.body.tds_per,
      tds_amount: req.body.tds_amount,
      after_tds_brokerage: req.body.after_tds_brokerage,
      actual_receivable_amount: req.body.actual_receivable_amount,
      incentive_per: req.body.incentive_per,
      incentive_without_tds: req.body.incentive_without_tds,
      net_incentive_earned: req.body.net_incentive_earned,
      invoice_status: req.body.invoice_status,
    }
    const num = await db2['transactionBrokerageDetails'].update(data, {
      where: { transaction_id: transaction_id },
    });
    console.log("ggyyggh", num);

    if (num == 1) {
        const TransactionLogs = await db2['logs'].create({
            org_id: org_id,
            module_id: transaction_id,
            module_name: "5",
            note: "Transaction brokerage details updated at",
            user_id: created_by.id
        })

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${transaction_id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateInvoicingDetails = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const id = req.params.id;
    const transaction_id = req.params.transaction_id;
    console.log('transaction_id', transaction_id);

    const data = {
      raised: req.body.raised,
      pending: req.body.pending,
      payment_status: req.body.payment_status,
      amount_received: req.body.amount_received,
      receiving_date: req.body.receiving_date,
      pending_brokerage: req.body.pending_brokerage,
      s_gst_2: req.body.s_gst_2,
      c_gst_3: req.body.c_gst_3,
      i_gst_4: req.body.i_gst_4,
      gst_amount2: req.body.gst_amount2,
      gross_brokerage_value2: req.body.gross_brokerage_value2,
      tds_reducted_by_builder3: req.body.tds_reducted_by_builder3,
      tds_amount2: req.body.tds_amount2,
      after_tds_brokearge5: req.body.after_tds_brokearge5,
      pending_receivable_amount: req.body.pending_receivable_amount
    }
    const num = await db2['transactionInvoicingDetails'].update(data, {
      where: {transaction_id: transaction_id },
    });

    console.log("ggyyggh", num);    

    if (num == 1) {
        const TransactionLogs = await db2['logs'].create({
            org_id: org_id,
            module_id: transaction_id,
            module_name: "5",
            note: "Transaction invoicing details updated at",
            user_id: created_by.id
        })

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${transaction_id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteTransaction = async (req, res) => {
  const TransactionData = {
    status: 0,
  }
  try {
    const id = req.params.id;
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let x = req.params.id
      
    console.log("id111", x);

    let thisQuery  = ` UPDATE lz_transactions SET status = 0 `;
        thisQuery += " WHERE id IN (" + x + ") "
        thisQuery += ` and status = 1 `;

    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Transaction Status
exports.updateTransactionStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;
    const TransactionID = req.params.id;

    let thisQuery = ` select t.transaction_status as transaction_status, cs.option_value as transaction_status_name
    from lz_transactions as t
    left join lz_masters as cs on (cs.id = t.transaction_status)
    where t.status = 1 and t.id = ${id} `

    const data123= await db2.sequelize.query(thisQuery);

    const dataStatus = data123[0][0]?.transaction_status
    const dataStatusName = data123[0][0]?.transaction_status_name
    
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);

    const data = {
      transaction_status: req.body.transaction_status,
      }

      const transactionStatus = req.body.transaction_status
      console.log("transactionStatussssssss", transactionStatus);

    const num = await db2['transaction'].update(data, {
      where: { id: id },
    });
    if (num == 1) {

      let thisQuery = ` select option_value from lz_masters where option_type = "transaction_status" and id = ${transactionStatus}`
      const data = await db2.sequelize.query(thisQuery);
      const dataValue = data[0][0].option_value
      console.log("dataaaaa", dataValue);

      // Lead Status
      if(req.body.transaction_status) {
        let thisQuery456 = ` select t.transaction_status as l_status, ts.option_value as l_status_name
        from lz_transactions as t
        left join lz_masters as ts on (ts.id = t.transaction_status)
        where t.status = 1 and t.transaction_status = ${req.body.transaction_status}
        `
        const dataCS = await db2.sequelize.query(thisQuery456);
        const dataCS1 = dataCS[0][0]?.l_status
        const dataCS2 = dataCS[0][0]?.l_status_name
        console.log("dataCS1", dataCS1);
        console.log("dataCS2", dataCS2);

      if(dataStatus.toString() !== req.body.transaction_status.toString()) {
        const TransactionStatusLog = await db2['logs'].create({
          org_id: org_id,
          module_id: TransactionID,
          module_name: "5",
          note: 'Transaction lead status : ' + dataStatusName + ' to '+ dataCS2,
          user_id: created_by.id
        })
        console.log("Transaction Lead Status",TransactionStatusLog.dataValues.note);
      }
    }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getTransactionTasks = async (req, res) => {
  try {
  const LeadID = req.params.lead_id;
  console.log('LeadIDDD', LeadID);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = `SELECT t.*, DATE_FORMAT(t.task_time,'%Y-%m-%d %H:%i:%s') as task_time, c.id as contact_id, c.company_name as company_name, CONCAT(c.first_name,' ',c.last_name)as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name,
  pra.name_of_building as property_name, GROUP_CONCAT(us.first_name,' ',us.last_name,'-',us.id) as assign_to_name, org.organization_name as org_name, ms2.option_value as task_type_name, ms.option_value as task_status_name, ms1.option_value as priority_name, rem.option_value as reminder_name
  FROM lz_tasks as t
  LEFT JOIN lz_properties as pr on (pr.id = t.project) 
  LEFT JOIN lz_property_addresses as pra on (pra.id = pr.id)
  LEFT JOIN lz_transactions as tra on (t.contact = tra.lead_id)
  LEFT JOIN lz_contacts as c on (c.id = tra.lead_id)
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.assign_to)>0
  LEFT JOIN lz_organization as org on (org.id = t.org_id)
  LEFT JOIN lz_masters as ms on (ms.id = t.task_status)
  LEFT JOIN lz_masters as ms1 on (ms1.id = t.priority)
  LEFT JOIN lz_masters as ms2 on (ms2.id = t.task_type)
  LEFT JOIN lz_masters as rem on (rem.id = t.reminder)
  where t.contact = ${LeadID} group by t.id `

  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Transaction Filter
exports.saveTransactionFilter = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let thisQuery1 = ` SELECT id FROM lz_transaction_filter `
    const data1 = await db2.sequelize.query(thisQuery1);
    const transactionContact = data1[0].length
    console.log("transactionContact", transactionContact);
    
    if (transactionContact < 5) {

    const data = await db2['transactionFilter'].create({
      booking_from_date: req.body.booking_from_date,
      booking_to_date: req.body.booking_to_date,
      city: req.body.city,
      source: req.body.source,
      team_leader: req.body.team_leader,
      shared_with: req.body.shared_with,
      closed_by: req.body.closed_by,
      developer_name: req.body.developer_name,
      property_id: req.body.property_id,
      filter_name: req.body.filter_name,
      bhk_type_min: req.body.bhk_type_min,
      bhk_type_max: req.body.bhk_type_max,
      agreement_value_min: req.body.agreement_value_min,
      agreement_value_max: req.body.agreement_value_max,
      brokerage_percentage_min: req.body.brokerage_percentage_min,
      brokerage_percentage_max: req.body.brokerage_percentage_max,
      brokerage_value_min: req.body.brokerage_value_min,
      brokerage_value_max: req.body.brokerage_value_max,
      discount_percentage_min: req.body.discount_percentage_min,
      discount_percentage_max: req.body.discount_percentage_max,
      discount_value_min: req.body.discount_value_min,
      discount_value_max: req.body.discount_value_max,
      revenue_min: req.body.revenue_min,
      revenue_max: req.body.revenue_max,
      transaction_status: req.body.transaction_status,
      created_by: created_by.id
    });  
    
    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });
  }
  else {
    res.status(200).send({
      status: 400,
      message: 'Only 5 filters can add',
      output: []
    });
  }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getTransactionFilter = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = `select l.*
  from lz_transaction_filter as l
  group by l.id
  `;

  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output: data[0],
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteTransactionFilter = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db2['transactionFilter'].destroy({
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
