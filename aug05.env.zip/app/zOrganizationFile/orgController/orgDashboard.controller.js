const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const Moment = require('moment')
const dbConfig = require("../../config/db.config.js");
const DbName = dbConfig.DB_DATABASE

// ${DbName}
const datebetween = async (queryString) => {
  let dateBetween;

  if (queryString.filter_by == '' || queryString.filter_by == undefined ) {
    dateBetween = ` `
  }
  if (queryString.filter_by == 1) {
    dateBetween = ` and (DATE(c.created_at) = DATE(NOW())) `
  }
  else if (queryString.filter_by == 2) {
    dateBetween = ` and (DATE(c.created_at) = DATE(NOW())-1) `
  }
  else if (queryString.filter_by == 3) {
    dateBetween = ` and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)  `
  }
  else if (queryString.filter_by == 4) {
    dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day ) `
  }
  else if (queryString.filter_by == 5) {
    dateBetween = ` and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day ) `
  }
  else if (queryString.filter_by == 6) {
    dateBetween = ` and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day ) `
  }
  else if (queryString.filter_by == 7) {
    dateBetween = ` and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') `
  }
  return dateBetween;
}
exports.getDashboardCount = async (req, res) => {
  try {

  // let thisQuery = ` SELECT designation from lz_user where id ='${created_by}' limit 1 `
  // const dashboardData = await db2.sequelize.query(thisQuery);
  // const dataDashboard = dashboardData[0]
  // console.log("dashboardData", dataDashboard);

  // const role = dataDashboard[0] ? dataDashboard[0]["designation"] : 0 role.designation

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

  let thisQuery1 = ` SELECT `

  thisQuery1 += ` (SELECT ifnull(COUNT(*),0) 
  FROM lz_contacts as c
  ${role_id == 1 ? `LEFT JOIN lz_user as us on (us.id = c.assign_to) ` : `LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 `}
  where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
  ${role_id == 1 ? `` : 
  role_id == 2 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by}) ` : 
  role_id == 3 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by}) ` : 
  role_id == 4 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 ) ` : ` and c.created_by = ${created_by} `}) AS contacts, `

  thisQuery1 += ` (SELECT ifnull(COUNT(*),0) 
  FROM lz_leads as c
  ${role_id == 1 ? `LEFT JOIN lz_user as us on (us.id = c.assign_to) ` : `LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 `}
  where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
  ${role_id == 1 ? `` : 
  role_id == 2 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or c.created_by = ${created_by}) ` : 
  role_id == 3 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by} OR c.created_by = ${created_by}) ` : 
  role_id == 4 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR c.created_by = ${created_by}) ` : ` and c.created_by = ${created_by} `}) AS leads, `

  thisQuery1 += ` (SELECT ifnull(COUNT(*),0) 
  FROM lz_properties as c
  ${role_id == 1 ? `LEFT JOIN lz_user as us on (us.id = c.assign_to) ` : `LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 `}
  where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
  ${role_id == 1 ? `` : 
  role_id == 2 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by} OR c.created_by = ${created_by}) ` : 
  role_id == 3 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by} OR c.created_by = ${created_by}) ` : 
  role_id == 4 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR c.created_by = ${created_by}) ` : ` and c.created_by = ${created_by} `}) AS properties, `

  thisQuery1 += ` (SELECT ifnull(COUNT(*),0) 
  FROM lz_tasks as c
  ${role_id == 1 ? `LEFT JOIN lz_user as us on (us.id = c.assign_to) ` : `LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 `}
  where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
  ${role_id == 1 ? `` : 
  role_id == 2 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or c.created_by = ${created_by}) ` : 
  role_id == 3 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR us.team_leader = ${created_by} OR us.portfolio_head = ${created_by} OR c.created_by = ${created_by}) ` : 
  role_id == 4 ? ` and (FIND_IN_SET(${created_by},c.assign_to)>0 OR c.created_by = ${created_by}) ` : ` and c.created_by = ${created_by} `}) AS tasks, `

  thisQuery1 += ` (SELECT ifnull(COUNT(*),0) 
  FROM lz_transactions as c
  LEFT JOIN lz_leads as le on (le.id = c.lead_id)
  LEFT JOIN lz_user as us on (us.id = le.assign_to) 
  LEFT JOIN lz_user as us1 on (us1.id = c.created_by)
  where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
  ${role_id == 1 ? `` : 
  role_id == 2 ? ` and (FIND_IN_SET(${created_by},le.assign_to)>0 OR us1.team_leader = ${created_by} OR us1.portfolio_head = ${created_by} OR c.created_by = ${created_by}) ` : 
  role_id == 3 ? ` and (FIND_IN_SET(${created_by},le.assign_to)>0 OR us1.team_leader = ${created_by} OR us1.portfolio_head = ${created_by} OR c.created_by = ${created_by}) ` : 
  role_id == 4 ? ` and (FIND_IN_SET(${created_by},le.assign_to)>0 OR c.created_by = ${created_by}) ` : ` and c.created_by = ${created_by} `}) AS transactions `

  const dashboardData1 = await db2.sequelize.query(thisQuery1);
  console.log("dashboardData1" , thisQuery1);

    res.status(200).send({
      status:200,
      message:'Success',
      output:dashboardData1[0][0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getDashboardBarCount = async (req, res) => {
  try {
    const module = req.params.moduleId;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;
    // const subTeamID = req.params.portfolio_head;

    let thisQuery1 = ` `
     
    const queryString = req.query;

    const timeLimit = req.params.id;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    // ${findAdmin == 1 ? ` and c.created_by = ${userID} ` : ` and FIND_IN_SET(${userID},c.assign_to)>0 `} 

    //  USERS
    if(teamID == 0) {
      if (timeLimit == 1) {
        thisQuery1 += ` SELECT 
        ${module == 3 ? `COUNT(con.property_id) as count, pa.name_of_building as property_name ` : `  COUNT(c.id) as count `} 
        FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
        ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
        ${module == 3 ? `left join lz_contacts as con on (con.property_id = c.id) left join lz_property_addresses as pa on (pa.property_id = c.id) ` : ``}
        where ${module == 3 ? `con.status = 1`: ` c.status = 1 `} and ${module == 3 ? `(DATE(con.created_at) = DATE(NOW())) ` : `(DATE(c.created_at) = DATE(NOW()))`}
        ${module == 5 ? `and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ` : module == 1 ? `and (FIND_IN_SET(${userID},c.assign_to)>0) ` : module == 3 ? `and (con.property_id = ${userID}) ` : `and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `} 
        `
      }
      if (timeLimit == 2) {
        thisQuery1 += ` SELECT 
        ${module == 3 ? `COUNT(con.property_id) as count, pa.name_of_building as property_name ` : `  COUNT(c.id) as count `} 
        FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
        ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
        ${module == 3 ? `left join lz_contacts as con on (con.property_id = c.id) left join lz_property_addresses as pa on (pa.property_id = c.id) ` : ``}
        where ${module == 3 ? `con.status = 1`: ` c.status = 1 `} and ${module == 3 ? `(DATE(con.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY))` : ` (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) ` } 
        ${module == 5 ? `and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ` : module == 1 ? `and (FIND_IN_SET(${userID},c.assign_to)>0) ` : module == 3 ? `and (con.property_id = ${userID}) ` : `and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `} 
        `
      }
      // Last Week
      if (timeLimit == 3) {
        thisQuery1 += ` SELECT 
        ${module == 3 ? `COUNT(con.property_id) as count, pa.name_of_building as property_name ` : `  COUNT(c.id) as count `}, DAYNAME(c.created_at) as dayname, 
        ${module == 3 ? `DATE_FORMAT(con.created_at,'%Y-%m') as date` : ` DATE_FORMAT(c.created_at,'%Y-%m') as date `} 
        FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
        ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
        ${module == 3 ? `left join lz_contacts as con on (con.property_id = c.id) left join lz_property_addresses as pa on (pa.property_id = c.id) ` : ``}
        where ${module == 3 ? `con.status = 1`: ` c.status = 1 `} and ${module == 3 ? `(con.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND con.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)` : `(c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY)` } 
        ${module == 5 ? `and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ` : module == 1 ? `and (FIND_IN_SET(${userID},c.assign_to)>0) ` : module == 3 ? `and (con.property_id = ${userID}) ` : `and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `} 
        ${module == 3 ? ` GROUP BY DAYNAME(con.created_at) ` : `GROUP BY DAYNAME(c.created_at)`} ` 
      }
      // Last Month
      if (timeLimit == 4) {
        thisQuery1 += ` SELECT 
        ${module == 3 ? `COUNT(con.property_id) as count, pa.name_of_building as property_name ` : `  COUNT(c.id) as count `}, 
        ${module == 3 ? `DATE_FORMAT(con.created_at,'%Y-%m-%d') as date` : `DATE_FORMAT(c.created_at,'%Y-%m-%d') as date`},  
        ${module == 3 ? ` MONTHNAME(con.created_at) as month ` : `MONTHNAME(c.created_at) as month`} 
        FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
        ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
        ${module == 3 ? `left join lz_contacts as con on (con.property_id = c.id) left join lz_property_addresses as pa on (pa.property_id = c.id) ` : ``}
        where ${module == 3 ? `con.status = 1`: ` c.status = 1 `} and ${module == 3 ? `(con.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND con.created_at < last_day(curdate() - interval 1 month))` : `(c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 1 month))`} 
        ${module == 5 ? `and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ` : module == 1 ? `and (FIND_IN_SET(${userID},c.assign_to)>0) ` : module == 3 ? `and (con.property_id = ${userID}) ` : `and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `} 
        ${module == 3 ? ` GROUP BY DATE(con.created_at) ` : `GROUP BY DATE(c.created_at)`} ` 
      }
      // This Month
      if (timeLimit == 5) {
        thisQuery1 += ` SELECT 
        ${module == 3 ? `COUNT(con.property_id) as count, pa.name_of_building as property_name ` : `  COUNT(c.id) as count `}, 
        ${module == 3 ? `DATE_FORMAT(con.created_at,'%Y-%m-%d') as date` : `DATE_FORMAT(c.created_at,'%Y-%m-%d') as date`}, 
        ${module == 3 ? ` MONTHNAME(con.created_at) as month ` : `MONTHNAME(c.created_at) as month`} 
        FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
        ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
        ${module == 3 ? `left join lz_contacts as con on (con.property_id = c.id) left join lz_property_addresses as pa on (pa.property_id = c.id) ` : ``}
        where ${module == 3 ? `con.status = 1`: ` c.status = 1 `} and ${module == 3 ? `(con.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND con.created_at < last_day(curdate() - interval 0 month))` : `(c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 month))`} 
        ${module == 5 ? `and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ` : module == 1 ? `and (FIND_IN_SET(${userID},c.assign_to)>0) ` : module == 3 ? `and (con.property_id = ${userID}) ` : `and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `} 
        ${module == 3 ? ` GROUP BY DATE(con.created_at) ` : `GROUP BY DATE(c.created_at)`} ` 
      }
      // This Year
      if (timeLimit == 6) {
        thisQuery1 += ` SELECT 
        ${module == 3 ? `COUNT(con.property_id) as count, pa.name_of_building as property_name ` : ` COUNT(c.id) as count `}, 
        ${module == 3 ? `DATE_FORMAT(con.created_at,'%Y-%m-%d') as date` : `DATE_FORMAT(c.created_at,'%Y-%m-%d') as date`}, 
        ${module == 3 ? ` MONTHNAME(con.created_at) as month ` : `MONTHNAME(c.created_at) as month`} 
        FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
        ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
        ${module == 3 ? `left join lz_contacts as con on (con.property_id = c.id) left join lz_property_addresses as pa on (pa.property_id = c.id) ` : ``}
        where ${module == 3 ? `con.status = 1 `: ` c.status = 1 `} and ${module == 3 ? `(con.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND con.created_at < last_day(curdate() - interval 0 year))` : `(c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day AND c.created_at < last_day(curdate() - interval 0 year))` } 
        ${module == 5 ? `and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ` : module == 1 ? `and (FIND_IN_SET(${userID},c.assign_to)>0) ` : module == 3 ? `and (con.property_id = ${userID}) ` : `and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `}  
        ${module == 3 ? ` GROUP BY MONTH(con.created_at) ORDER BY MONTH(con.created_at) ASC ` : `GROUP BY MONTH(c.created_at) ORDER BY MONTH(c.created_at) ASC `} ` 
      }
      if (timeLimit == 7) {
        thisQuery1 += ` SELECT 
        ${module == 3 ? `COUNT(con.property_id) as count, pa.name_of_building as property_name ` : ` COUNT(c.id) as count `}, 
        ${module == 3 ? `DATE_FORMAT(con.created_at,'%Y-%m-%d') as date` : ` DATE_FORMAT(c.created_at,'%Y-%m-%d') as date `} 
        FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
        ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
        ${module == 3 ? `left join lz_contacts as con on (con.property_id = c.id) left join lz_property_addresses as pa on (pa.property_id = c.id) ` : ``}
        where ${module == 3 ? `con.status = 1`: ` c.status = 1 `} and ${module == 3 ? `(date(con.created_at) >= '${queryString.start_date}' AND date(con.created_at) <= '${queryString.end_date}')` : `(date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}')` }
        ${module == 5 ? `and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ` : module == 1 ? `and (FIND_IN_SET(${userID},c.assign_to)>0) ` : module == 3 ? `and (con.property_id = ${userID}) ` : `and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) `} 
        ${module == 3 ? ` GROUP BY DATE(con.created_at) ` : `GROUP BY DATE(c.created_at)`} ` 
      }
  
      } 
      else if (userID == 0) {
        // Today
        if (timeLimit == 1) {
          thisQuery1 += ` SELECT COUNT(c.id) as count FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
          ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
          ${module == 5 ? `LEFT JOIN lz_user as us on (us.id = le.assign_to)` : `LEFT JOIN lz_user as us on (us.id = c.assign_to) `}
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  and (DATE(c.created_at) = DATE(NOW())) 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 ${module != 1 ? `or c.created_by = ${teamID} ` : ``} ) ` }
          `
        }
        // Yesterday
        if (timeLimit == 2) {
          thisQuery1 += ` SELECT COUNT(c.id) as count FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
          ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
          ${module == 5 ? `LEFT JOIN lz_user as us on (us.id = le.assign_to)` : `LEFT JOIN lz_user as us on (us.id = c.assign_to)`}
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  and (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID}  or us.portfolio_head = ${teamID}
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 ${module != 1 ? `or c.created_by = ${teamID} ` : ``} ) ` }
          `
        }
        // Last Week
        if (timeLimit == 3) {
          thisQuery1 += ` SELECT COUNT(c.id) as count, DAYNAME(c.created_at) as dayname, DATE_FORMAT(c.created_at,'%Y-%m') as date FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
          ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
          ${module == 5 ? `LEFT JOIN lz_user as us on (us.id = le.assign_to)` : `LEFT JOIN lz_user as us on (us.id = c.assign_to)`}
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  and (c.created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND c.created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID}  or us.portfolio_head = ${teamID}
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 ${module != 1 ? `or c.created_by = ${teamID} ` : ``} ) ` }
          GROUP BY DAYNAME(c.created_at) `
        }
        // Last Month
        if (timeLimit == 4) {
          thisQuery1 += ` SELECT COUNT(c.id) as count, ${module == 5 ? `le.assign_to` : `c.assign_to`}, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
          ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
          ${module == 5 ? `LEFT JOIN lz_user as us on (us.id = le.assign_to)` : `LEFT JOIN lz_user as us on (us.id = c.assign_to)`}
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  and (c.created_at >= last_day(curdate() - interval 2 month) + interval 1 day ) 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 ${module != 1 ? `or c.created_by = ${teamID} ` : ``} ) ` }
          GROUP BY DATE(c.created_at) `
        }
        // This Month
        if (timeLimit == 5) {
          thisQuery1 += ` SELECT COUNT(c.id) as count, ${module == 5 ? `le.assign_to` : `c.assign_to`}, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
          ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
          ${module == 5 ? `LEFT JOIN lz_user as us on (us.id = le.assign_to)` : `LEFT JOIN lz_user as us on (us.id = c.assign_to)`}
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  and (c.created_at >= last_day(curdate() - interval 1 month) + interval 1 day ) 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 ${module != 1 ? `or c.created_by = ${teamID} ` : ``} ) ` }
          GROUP BY DATE(c.created_at) `
        }
        // This Year
        if (timeLimit == 6) {
          thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m') as date, MONTHNAME(c.created_at) as month FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
          ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
          ${module == 5 ? `LEFT JOIN lz_user as us on (us.id = le.assign_to)` : `LEFT JOIN lz_user as us on (us.id = c.assign_to)`}
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  and (c.created_at >= last_day(curdate() - interval 2 year) + interval 1 day )
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 ${module != 1 ? `or c.created_by = ${teamID} ` : ``} ) ` }
          GROUP BY MONTH(c.created_at) ORDER BY MONTH(c.created_at) ASC
          `
        }
        // Date Range
        if (timeLimit == 7) {
          thisQuery1 += ` SELECT COUNT(c.id) as count, DATE_FORMAT(c.created_at,'%Y-%m-%d') as date FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : 'lz_transactions'} as c 
          ${module == 5 ? `left join lz_leads as le on (le.id = c.lead_id)` : ``}
          ${module == 5 ? `LEFT JOIN lz_user as us on (us.id = le.assign_to)` : `LEFT JOIN lz_user as us on (us.id = c.assign_to)`}
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  and (date(c.created_at) >= '${queryString.start_date}' AND date(c.created_at) <= '${queryString.end_date}') 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 
          ${module != 1 ? `or c.created_by = ${teamID} ` : ``}) ` : ` and (FIND_IN_SET(${teamID},${module == 5 ? `le.assign_to` : `c.assign_to`})>0 ${module != 1 ? `or c.created_by = ${teamID} ` : ``} ) ` }
          GROUP BY DATE(c.created_at) `
        }
      }
    const dashboardData1 = await db2.sequelize.query(thisQuery1);
    // const count_filter = (dashboardData1[0][0].count)
    
    console.log("dashboardData1", thisQuery1);
    // console.log("count_filter", count_filter);
    console.log("thisQuery1", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      // count: count_filter,
      output: dashboardData1[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getDashboardMastersCount = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const timeLimit = req.params.id
    const masterId = req.params.option_type

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    let thisQuery1 = ` `

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });

    let roleCheck = ``
    if (role_id == 1) {
      roleCheck = ` `
    }
    if (role_id == 2) {
      roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
      roleCheck = ` and c.created_by = ${created_by} `
    }
    if (role_id >= 3) {
      roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
    }
    
    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    if (masterId) {
      if (teamID == 0) {
        if (module == 1) {
          thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count, pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name ` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'gender' ? `COUNT(cd.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'gender' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : ""} as c
          ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id)` :
              masterId == 'country' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country) ` :
                masterId == 'state' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
                  masterId == 'city' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
                  masterId == 'locality' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) ` :
                  masterId == 'gender' ? `LEFT JOIN lz_contact_details as cd on (cd.contact_id = c.id) LEFT JOIN lz_masters as m on (cd.${masterId} = m.id)` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
          LEFT JOIN lz_user as us on (us.id = c.created_by)
          LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
          where c.status = 1 and (FIND_IN_SET(${userID},c.assign_to)>0) ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id' && masterId !== 'locality' && masterId !== 'gender' ? `and m.option_type = '${masterId}' ` : ''} 
          ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? `and cou.name IS NOT NULL group by cou.name` : masterId == 'state' ? `and st.name IS NOT NULL group by st.name ` : masterId == 'city' ? ` and ci.name IS NOT NULL group by ci.name` : masterId == 'locality' ? ` and lr.locality != "" and lr.locality IS NOT NULL group by lr.locality` : masterId == 'gender' ? `and m.option_value IS NOT NULL group by cd.gender` : ` and m.option_value IS NOT NULL group by m.option_value`} `
        }
        if (module == 2) {
          thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count,pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name ` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}`  : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_leads as c
        ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id) ` :
              masterId == 'country' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country) ` :
                masterId == 'state' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
                  masterId == 'city' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
                    masterId == 'locality' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) ` :
                    masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id' && masterId !== 'locality' ? `and m.option_type = '${masterId}' ` : ''} 
        ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? ` and cou.name IS NOT NULL group by cou.name ` : masterId == 'state' ? ` and st.name IS NOT NULL group by st.name ` : masterId == 'city'  ? ` and ci.name IS NOT NULL group by ci.name ` : masterId == 'locality' ? `group by lr.locality` : `group by m.option_value`}
       `
        }
        // Property Dashboard Users
        if (module == 3) {
          thisQuery1 += ` SELECT pa.name_of_building as property_name,
          ${masterId == 'users' ? `COUNT(us.id) as count, CONCAT(us.first_name,' ', IFNULL(us.last_name, '')) as users_name ` : 
          masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : 
          masterId == 'state' ? `COUNT(lr.${masterId}) as count,  st.name as state_name ` : 
          masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : 
          masterId == 'source' ? `COUNT(c.source) as count,` : 
          masterId == 'property_status' ? `COUNT(c.contact_status) as count, ` : 
          masterId == 'property_type' ? ` ` : 
          `COUNT(c.${masterId}) as count,`}

          ${masterId == 'users' ? ` ,us.id as id1 ` : 
          masterId == 'country' ? `lr.country as ${masterId}` : 
          masterId == 'state' ? `lr.state as ${masterId}` : 
          masterId == 'city' ? `lr.city as ${masterId}` : 
          masterId == 'source' ? `m.option_value as ${masterId}` : 
          masterId == 'property_status' ? ` cs.option_value as property_status ` : 
          masterId == 'property_type' ? `  p.id as id1 ` : 
          `m.option_value as ${masterId}`} 
          FROM lz_properties as p
          LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
          LEFT JOIN lz_contacts as c on (p.id = c.property_id)
          ${masterId == 'country' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country) ` :
                masterId == 'state' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
                  masterId == 'city' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id)  LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
                  masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.source = m.id) ` :
                  masterId == 'users' ? `LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0 ` :
                  masterId == 'property_status' ? `LEFT JOIN lz_masters as cs on (c.contact_status = cs.id) ` :
                  masterId == 'property_type' ? ` ` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
        where c.status = 1 and (c.property_id = ${userID}) ${querydatebetween} 
        ${masterId !== 'country' && 
        masterId !== 'state' && 
        masterId !== 'city' && 
        masterId !== 'property_type' && 
        masterId !== 'users' ? ` ` : 
        masterId == 'property_status' ? `and m.option_type = 'contact_status' ` : 
        ''} 

        ${masterId == 'country' ? `and cou.name IS NOT NULL group by lr.country` : 
        masterId == 'state' ? `and st.name IS NOT NULL group by lr.state` : 
        masterId == 'city' ? ` and ci.name IS NOT NULL group by lr.city` :
        masterId == 'property_status' ? ` group by cs.option_value` :  
        masterId == 'users' ? `group by us.id` : `group by m.option_value`
        }
       `
        }
        if (module == 4) {
          thisQuery1 += ` SELECT ${masterId == 'contact' ? `COUNT(c.${masterId}) as count` : masterId == 'project' ? `COUNT(c.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'contact' ? `lr.first_name as ${masterId}` : masterId == 'project' ? `pa.name_of_building as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_tasks as c
          ${masterId == 'contact' ? `LEFT JOIN lz_contacts as lr on (c.${masterId} = lr.id) ` :
                masterId == 'project' ? `LEFT JOIN lz_properties as p on (c.${masterId} = p.id) LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id) ` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID}) ${querydatebetween} ${masterId !== 'contact' && masterId !== 'project' ? `and m.option_type = '${masterId}' ` : ''} 
        ${masterId == 'contact' ? `group by c.contact` : masterId == 'project' ? `group by c.project` : `group by m.option_value`}
       `
        }
        if (module == 5) {
          thisQuery1 += ` SELECT ${masterId == 'country' ? `COUNT(lre.${masterId}) as count` : masterId == 'state' ? `COUNT(lre.${masterId}) as count` : masterId == 'city' ? `COUNT(lre.${masterId}) as count` : masterId == 'locality' ? `COUNT(lre.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : masterId == 'property_status' ? `COUNT(pro.property_status) as count` : `COUNT(le.${masterId}) as count`}, ${masterId == 'country' ? `cou.name as ${masterId}` : masterId == 'state' ? `st.name as ${masterId}` : masterId == 'city' ? `ci.name as ${masterId}` : masterId == 'locality' ? `lre.locality as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : masterId == 'property_status' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_transactions as c
          LEFT JOIN lz_leads as le on (le.id = c.lead_id)
          LEFT JOIN lz_properties as p on (p.id = le.property_id)
          ${masterId == 'country' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = lr.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lre.country) ` :
                masterId == 'state' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = lr.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lre.state)` :
                  masterId == 'city' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = lr.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lre.city)` :
                  masterId == 'locality' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = c.id) ` :
                  masterId == 'property_status' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_properties as pro on (lr.property_id = pro.id) LEFT JOIN lz_masters as m on (pro.property_status = m.id)` :
                  masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
                    `LEFT JOIN lz_masters as m on (le.${masterId} = m.id)`}
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        where c.status = 1 and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${userID}) ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'locality' && masterId !== 'property_status' ? `and m.option_type = '${masterId}' ` : ''} 
        ${masterId == 'country' ? ` and cou.name IS NOT NULL group by cou.name ` : masterId == 'state' ? ` and st.name IS NOT NULL group by st.name ` : masterId == 'city' ? `
        and ci.name IS NOT NULL group by ci.name ` : masterId == 'locality' ? `group by lre.locality` : masterId == 'property_status' ? `group by m.option_value` : `group by m.option_value`}
       `
        }
        console.log("Teamsssssssss");

      } 
      else if (userID == 0) {
        if (module == 1) {
          thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count, pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'gender' ? `COUNT(cd.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'gender' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : ""} as c
          ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id)` :
              masterId == 'country' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)` :
                masterId == 'state' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)` :
                  masterId == 'city' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)` :
                  masterId == 'locality' ? `LEFT JOIN lz_contact_address as lr on (lr.contact_id = c.id) ` :
                  masterId == 'gender' ? `LEFT JOIN lz_contact_details as cd on (cd.contact_id = c.id) LEFT JOIN lz_masters as m on (cd.${masterId} = m.id) ` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
          LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0 
          where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
          ${findTeamAdmin == 1 ? `` : 
          findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}) ` : 
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 ` : ` and FIND_IN_SET(${teamID},c.assign_to)>0) ` } 
          ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id' && masterId !== 'locality' && masterId !== 'gender' ? `and m.option_type = '${masterId}' ` : ''}
          ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? `and cou.name IS NOT NULL group by cou.name ` : masterId == 'state' ? `and st.name IS NOT NULL group by st.name` : masterId == 'city' ? `and ci.name IS NOT NULL group by ci.name ` : masterId == 'locality' ? `and lr.locality != "" and lr.locality IS NOT NULL group by lr.locality` : masterId == 'gender' ? ` and m.option_value IS NOT NULL group by cd.gender` : ` and m.option_value IS NOT NULL group by m.option_value`} `
        }
        if (module == 2) {
          thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count,pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name ` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_leads as c
        ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id) ` :
              masterId == 'country' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)` :
                masterId == 'state' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
                  masterId == 'city' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
                  masterId == 'locality' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) ` :
                  masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0
        where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` }  
        ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id'  && masterId !== 'locality' ? `and m.option_type = '${masterId}' ` : ''}
        ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? ` and cou.name IS NOT NULL group by cou.name ` : masterId == 'state' ? ` and st.name IS NOT NULL group by st.name ` : masterId == 'city' ? ` and ci.name IS NOT NULL group by ci.name ` : masterId == 'locality' ? `group by lr.locality` : `group by m.option_value`}
       `
        }
        if (module == 3) {
          thisQuery1 += ` SELECT ${masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name ` : masterId == 'source' ? `COUNT(c.property_source) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_properties as c
          ${masterId == 'country' ? `LEFT JOIN lz_property_addresses as lr on (lr.property_id = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)` :
                masterId == 'state' ? `LEFT JOIN lz_property_addresses as lr on (lr.property_id = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)` :
                  masterId == 'city' ? `LEFT JOIN lz_property_addresses as lr on (lr.property_id = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)` :
                  masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.property_source = m.id) ` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to) > 0
        where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`} 
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID} ) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID} )` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID} ) ` }  
        ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' ? `and m.option_type = '${masterId}' ` : ''} 
        ${masterId == 'country' ? ` and cou.name IS NOT NULL group by cou.name ` : masterId == 'state' ? ` and st.name IS NOT NULL group by st.name ` : masterId == 'city' ? `
        and ci.name IS NOT NULL group by ci.name ` : `group by m.option_value`}
       `
        }
        if (module == 4) {
          thisQuery1 += ` SELECT ${masterId == 'contact' ? `COUNT(c.${masterId}) as count` : masterId == 'project' ? `COUNT(c.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'contact' ? `lr.first_name as ${masterId}` : masterId == 'project' ? `pa.name_of_building as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_tasks as c
          ${masterId == 'contact' ? `LEFT JOIN lz_contacts as lr on (c.${masterId} = lr.id) ` :
                masterId == 'project' ? `LEFT JOIN lz_properties as p on (c.${masterId} = p.id) LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id) ` :
                    `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID} ) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID} )` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID} ) ` } 
        ${querydatebetween} ${masterId !== 'contact' && masterId !== 'project' ? `and m.option_type = '${masterId}' ` : ''} 
        ${masterId == 'contact' ? `group by c.contact` : masterId == 'project' ? `and p.status = 1 group by c.project` : `group by m.option_value`}
       `
        }
        if (module == 5) {
          thisQuery1 += ` SELECT ${masterId == 'country' ? `COUNT(lre.${masterId}) as count` : masterId == 'state' ? `COUNT(lre.${masterId}) as count` : masterId == 'city' ? `COUNT(lre.${masterId}) as count` : masterId == 'locality' ? `COUNT(lre.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : masterId == 'property_status' ? `COUNT(pro.property_status) as count` : `COUNT(le.${masterId}) as count`}, ${masterId == 'country' ? `cou.name as ${masterId}` : masterId == 'state' ? `st.name as ${masterId}` : masterId == 'city' ? `ci.name as ${masterId}` : masterId == 'locality' ? `lre.locality as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : masterId == 'property_status' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_transactions as c
          LEFT JOIN lz_leads as le on (le.id = c.lead_id)
          LEFT JOIN lz_properties as p on (p.id = le.property_id)
          ${masterId == 'country' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = lr.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lre.country) ` :
                masterId == 'state' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = lr.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lre.state) ` :
                  masterId == 'city' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = lr.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lre.city) ` :
                  masterId == 'locality' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = c.id) ` :
                  masterId == 'property_status' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_properties as pro on (lr.property_id = pro.id) LEFT JOIN lz_masters as m on (pro.property_status = m.id) ` :
                  masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
                    `LEFT JOIN lz_masters as m on (le.${masterId} = m.id)`}
        LEFT JOIN lz_user as us on (us.id = c.created_by)
        LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
        LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
        where ${role_id == 1 ? `c.status IN (1,2) ` : `c.status = 1`}  
        ${findTeamAdmin == 1 ? `` : 
        findTeamAdmin == 2 ? ` and (FIND_IN_SET(${userID},le.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${userID},le.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` : 
        findTeamAdmin == 4 ? ` and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${teamID})` : ` and (FIND_IN_SET(${userID},le.assign_to)>0 or c.created_by = ${teamID}) ` } 
        ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city'  && masterId !== 'locality' && masterId !== 'property_status'  ? `and m.option_type = '${masterId}' ` : ''} 
        ${masterId == 'country' ? ` and cou.name IS NOT NULL group by cou.name ` : masterId == 'state' ? ` and st.name IS NOT NULL group by st.name ` : masterId == 'city' ? `
        and ci.name IS NOT NULL group by ci.name ` : masterId == 'locality' ? `and lre.locality !="" group by lre.locality` : masterId == 'property_status' ? `group by m.option_value` : `group by m.option_value `}
       `
        }
      }
      console.log("Teamsssssssss");
  }

    const dashboardData1 = await db2.sequelize.query(thisQuery1);
    console.log("dashboardData1", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: dashboardData1[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getDashboardTaskCount = async (req, res) => {
  try {
    const module = req.params.moduleId;
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const timeLimit = req.params.id
    const masterId = req.params.option_type

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    let thisQuery123 = ` select designation from lz_user where id = ${userID} `
    const adminData = await db2.sequelize.query(thisQuery123);

    let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
    const adminTeamData = await db2.sequelize.query(thisQuery1234);

    const findAdmin = adminData[0][0]?.designation
    console.log('adminData', findAdmin);

    const findTeamAdmin = adminTeamData[0][0]?.designation
    console.log('findTeamAdmin', findTeamAdmin);

    let thisQuery1 = ` `

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });

    if(userID == 0 && teamID == 0) {
      if (module == 1) {
        thisQuery1 += ` SELECT co.id as contact_id, c.id as task_id, COUNT(c.task_status) as count, m.option_value as task_status 
        FROM lz_tasks as c
        LEFT JOIN lz_contacts as co on (c.contact = co.id)
        LEFT JOIN lz_masters as m on (c.task_status = m.id)
        where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} and (c.id = 0)
        group by m.option_value `
      }
      if (module == 2) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as count, m.option_value as task_status, co.id as contact_id, c.id as task_id, l.id as lead_id
        FROM lz_contacts as co
        LEFT JOIN lz_leads as l on (l.contact_id = co.id)
        LEFT JOIN lz_tasks as c on (c.contact = l.id)
        LEFT JOIN lz_masters as m on (c.task_status = m.id)
        where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} and (co.id = 0)
        group by m.option_value `
      }
      if (module == 3) {
        thisQuery1 += ` SELECT p.id as project_id, c.id as task_id, COUNT(c.task_status) as count, m.option_value as task_status, pa.name_of_building as property_name
        FROM lz_properties as p
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_tasks as c on (c.project = p.id)
        LEFT JOIN lz_masters as m on (c.task_status = m.id)
        where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} and (p.id = 0)
        group by m.option_value `
        console.log("0/0");
      }
    }
    else if (teamID == 0) {
      if (module == 1) {
        thisQuery1 += ` SELECT co.id as contact_id, c.id as task_id, COUNT(c.task_status) as count, m.option_value as task_status 
        FROM lz_tasks as c
        LEFT JOIN lz_contacts as co on (c.contact = co.id)
        LEFT JOIN lz_masters as m on (c.task_status = m.id)
        where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID})
        group by m.option_value `
      }
      if (module == 2) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as count, m.option_value as task_status, co.id as contact_id, c.id as task_id, l.id as lead_id
        FROM lz_contacts as co
        LEFT JOIN lz_leads as l on (l.contact_id = co.id)
        LEFT JOIN lz_tasks as c on (c.contact = l.id)
        LEFT JOIN lz_masters as m on (c.task_status = m.id)
        where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} and (FIND_IN_SET(${userID},c.assign_to)>0 or c.created_by = ${userID})
        group by m.option_value `
      }
      if (module == 3) {
        thisQuery1 += ` SELECT p.id as project_id, c.id as task_id, COUNT(c.task_status) as count, m.option_value as task_status, pa.name_of_building as property_name
        FROM lz_properties as p
        LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id)
        LEFT JOIN lz_tasks as c on (c.project = p.id)
        LEFT JOIN lz_masters as m on (c.task_status = m.id)
        where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} and (p.id = ${userID})
        group by m.option_value `
      }
    }
    else if (userID == 0) {
      if (module == 1) {
        thisQuery1 += ` SELECT co.id as contact_id, c.id as task_id, COUNT(c.task_status) as count, m.option_value as task_status 
      FROM lz_tasks as c
      LEFT JOIN lz_contacts as co on (c.contact = co.id)
      LEFT JOIN lz_masters as m on (c.task_status = m.id)
      LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
      where c.status = 1 and m.option_type = 'task_status' ${querydatebetween} 
      ${findTeamAdmin == 1 ? `` :
      findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID}  or c.created_by = ${teamID}) ` :
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0  or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID})  `}
      group by m.option_value `
      }
      if (module == 2) {
        thisQuery1 += ` SELECT COUNT(c.task_status) as count, m.option_value as task_status 
        FROM lz_contacts as co
        LEFT JOIN lz_leads as l on (l.contact_id = co.id)
        LEFT JOIN lz_tasks as c on (c.contact = l.id)
        LEFT JOIN lz_masters as m on (c.task_status = m.id)
        LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
      where c.status = 1 and m.option_type = 'task_status' ${querydatebetween}
      ${findTeamAdmin == 1 ? `` :
      findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID})  `}
      group by m.option_value `
      }
      if (module == 3) {
        thisQuery1 += ` SELECT p.id as project_id, c.id as task_id, COUNT(c.task_status) as count, m.option_value as task_status
      FROM lz_tasks as c
      LEFT JOIN lz_properties as p on (c.project = p.id)
      LEFT JOIN lz_masters as m on (c.task_status = m.id)
      LEFT JOIN lz_user as us on FIND_IN_SET(us.id,c.assign_to)>0
      where c.status = 1 and m.option_type = 'task_status' ${querydatebetween}
      ${findTeamAdmin == 1 ? `` :
      findTeamAdmin == 2 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
        findTeamAdmin == 3 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} or c.created_by = ${teamID}) ` :
          findTeamAdmin == 4 ? ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID}) ` : ` and (FIND_IN_SET(${teamID},c.assign_to)>0 or c.created_by = ${teamID})  `}
      group by m.option_value `
      }
    }

    const dashboardData1 = await db2.sequelize.query(thisQuery1);
    console.log("dashboardData1", thisQuery1);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: dashboardData1[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getDashboardUsers = async (req, res) => {
  try {
    const module = req.params.moduleId;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    let thisQuery1 = ``
    let thisQuery2 = ``
    
      // if(role_id == 1) {
        // thisQuery1 += ` SELECT us.id as user_id, CONCAT(us.first_name) as user_name, GROUP_CONCAT( CONCAT(us1.first_name,' ',IFNULL(us.last_name,''),'-',us1.id)) as user_name
        // FROM lz_user as us
        // LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
        // LEFT JOIN lz_user as us2 on (us.id = us2.portfolio_head)
        // where us.status = 1
        // group by us.id
        // `
      // }
  if(role_id == 1) {
        thisQuery1 += ` SELECT us.id as user_id, CONCAT(us.first_name) as user_name
        FROM lz_user as us
        where us.status = 1 and us.id IS NOT NULL
        group by us.id
        `
        thisQuery2 += ` SELECT us1.team_leader as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT(CONCAT(us1.first_name,' ',IFNULL(us1.last_name,''))) as user_name
        FROM lz_user as us
        LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
        where us.status = 1 and us1.team_leader IS NOT NULL
        group by us1.team_leader
        `
        const dataFromUsers = await db2.sequelize.query(thisQuery1);
        const dataFromTeam = await db2.sequelize.query(thisQuery2);

        const aaa = dataFromUsers[0]
        const bbb = dataFromTeam[0]

        res.status(200).send({
            message: "Users & Teams List",
            status: 200,
            output: {users:aaa, teams:bbb}
        })
    }
  if(role_id == 2) {
        thisQuery1 += ` SELECT us1.id as user_id, CONCAT(us.first_name) as user_name, CONCAT(us1.first_name,' ',IFNULL(us1.last_name,'')) as user_name
        FROM lz_user as us
        LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
        where us.status = 1 and (us1.team_leader = ${created_by} OR us1.portfolio_head =${created_by} OR us1.id = ${created_by})
        `
        thisQuery2 += ` SELECT us1.team_leader as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT(CONCAT(us1.first_name,' ',IFNULL(us1.last_name,''))) as user_name
        FROM lz_user as us
        LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
        where us.status = 1 and us1.team_leader = ${created_by} OR us.team_leader = ${created_by} and us.designation != 4
        group by us1.team_leader
        `
        const dataFromUsers = await db2.sequelize.query(thisQuery1);
        const dataFromTeam = await db2.sequelize.query(thisQuery2);

        const aaa = dataFromUsers[0]
        const bbb = dataFromTeam[0]

        res.status(200).send({
            message: "Users & Teams List",
            status: 200,
            output: {users:aaa ?? {}, teams:bbb ?? {}}
        })
    }
  if(role_id == 3) {
        thisQuery1 += ` SELECT us1.id as user_id, CONCAT(us.first_name) as user_name, CONCAT(us1.first_name,' ',IFNULL(us1.last_name,'')) as user_name
        FROM lz_user as us
        LEFT JOIN lz_user as us1 on (us.id = us1.portfolio_head)
        where us.status = 1 and (us1.portfolio_head = ${created_by} OR us1.team_leader = ${created_by} OR us1.id = ${created_by})
        `
        thisQuery2 += ` SELECT us1.portfolio_head as team_leader_id, CONCAT(us.first_name) as team_leader_name, GROUP_CONCAT(distinct CONCAT(us1.id)) as user_id, GROUP_CONCAT(CONCAT(us1.first_name,' ',IFNULL(us1.last_name,''))) as user_name
        FROM lz_user as us
        LEFT JOIN lz_user as us1 on (us.id = us1.portfolio_head)
        where us.status = 1 and us1.portfolio_head = ${created_by} OR us.portfolio_head = ${created_by} and us.designation != 4
        group by us1.portfolio_head
        `
        const dataFromUsers = await db2.sequelize.query(thisQuery1);
        const dataFromTeam = await db2.sequelize.query(thisQuery2);

        const aaa = dataFromUsers[0]
        const bbb = dataFromTeam[0]

        res.status(200).send({
            message: "Users & Teams List",
            status: 200,
            output: {users:aaa ?? {}, teams:bbb ?? {}}
        })
    }
  if(role_id >= 4) {
    thisQuery1 += ` SELECT us.id as user_id, CONCAT(us.first_name,' ',IFNULL(us.last_name,'')) as user_name
    FROM lz_user as us
    where us.status = 1 and us.id = ${created_by}
    `
    const dataFromUsers = await db2.sequelize.query(thisQuery1);

    const aaa = dataFromUsers[0]

    res.status(200).send({
        message: "Executives Users List",
        status: 200,
        output: {users:aaa}
    })
  }
  }
  catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal Server Error' });
  }
};
exports.getDashboardGoals = async (req, res) => {
  try {
    const module = req.params.moduleId;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    let roleCheck = ``
    if (role_id == 1) {
      roleCheck = ` `
    }
    if (role_id == 2) {
      roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
      roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
    }
    if (role_id >= 3) {
      roleCheck = ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
    }

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });

    let thisQuery1 = ``

    if(teamID == 0) {
      if(module == 1) {
        thisQuery1 += `SELECT usg.status_changed as goal_status_changed, COUNT(c.note) as Achieved
        FROM lz_logs as c 
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
        LEFT JOIN lz_users_goals as usg on (us.id = usg.user_id)
        where c.note = 'Contact status updated to - New Contact' or c.note = 'Contact status updated to - unanswered' or c.note = 'Contact status updated to - verified' or c.note = 'Contact status updated to - invalid' or c.note = 'Contact status updated to - drop' or c.note = 'Contact status updated to - re-assign'
        and us.created_by = ${created_by} ${querydatebetween} ${roleCheck}
        `
    }
    if(module == 2) {
        thisQuery1 += `SELECT SUM(usg.goal_leads_generated) as goal_leads_generated, COUNT(l.id) as Achieved
        FROM lz_user as c
        LEFT JOIN lz_user as us1 on (c.id = us1.team_leader)
        LEFT JOIN lz_users_goals as usg on (usg.user_id = c.id)
        LEFT JOIN lz_leads as l on (usg.user_id = l.created_by)
        where l.status = 1 and usg.user_id = ${created_by} ${querydatebetween} ${roleCheck}
        `
    }
    } 
    if(userID == 0) {

      if(module == 1) {
        thisQuery1 += `SELECT usg.status_changed as goal_status_changed, COUNT(c.note) as Achieved
        FROM lz_logs as c 
        LEFT JOIN lz_user as us on (us.id = c.user_id)
        LEFT JOIN lz_user as us1 on (us.id = us1.team_leader)
        LEFT JOIN lz_users_goals as usg on (us.id = usg.user_id)
        where c.note = 'Contact status updated to - New Contact' or c.note = 'Contact status updated to - unanswered' or c.note = 'Contact status updated to - verified' or c.note = 'Contact status updated to - invalid' or c.note = 'Contact status updated to - drop' or c.note = 'Contact status updated to - re-assign'
        and us1.team_leader = ${created_by} OR us.created_by = ${created_by} ${querydatebetween} ${roleCheck}
        `
    }
    if(module == 2) {
        thisQuery1 += `SELECT SUM(usg.goal_leads_generated) as goal_leads_generated, COUNT(l.id) as Achieved
        FROM lz_user as c
        LEFT JOIN lz_user as us1 on (c.id = us1.team_leader)
        LEFT JOIN lz_users_goals as usg on (usg.user_id = c.id)
        LEFT JOIN lz_leads as l on (usg.user_id = l.created_by)
        where l.status = 1 and us1.team_leader = ${created_by} OR usg.user_id = ${created_by} ${querydatebetween} ${roleCheck}
        `
      }
    }

      const data = await db2.sequelize.query(thisQuery1);

      res.status(200).send({
          message: "Goals List",
          status: 200,
          output: data[0]
      })
  }
  catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal Server Error' });
  }
};
exports.getDashboardHR = async (req, res) => {
  try {
    const module = req.params.moduleId;

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const userID = req.params.created_by;
    const teamID = req.params.team_leader;

    let roleCheck = ``
    if (role_id == 1) {
      roleCheck = ` `
    }
    if (role_id == 2) {
      roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
      roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
    }
    if (role_id >= 3) {
      roleCheck = ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
    }

    const queryString = req.query;

    let querydatebetween = await datebetween(queryString).then(dateBetween => {
      return dateBetween;
    });

    const todayAtt = Moment.utc().format('YYYY-MM-DD')

    let thisQuery1 = ` SELECT att.user_id as user_id, us.first_name as first_name FROM lz_attendance as att
    LEFT JOIN lz_user as us on (us.id = att.user_id) where us.status = 1 and (DATE(att.start) = DATE(NOW()))
    group by us.id
    `
    const data = await db2.sequelize.query(thisQuery1);

    let thisQuery2 = ` select att.id as id, DAYNAME(att.start) as day_name,
    DATE_FORMAT(att.start,'%Y-%m-%d %H:%i:%s') as start_date, 
    count(case when att.attendance_status ='160' then 1 end) as absent_count, 
    count(case when att.attendance_status ='159' then 1 end) as present_count,
    count(case when att.attendance_status ='161' then 1 end) as half_count 
    from lz_attendance as att 
    left join lz_masters as m on (m.id = att.attendance_status) 
    where (att.status = 1) and (att.start >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND att.start < curdate() - INTERVAL DAYOFWEEK(curdate())-3 DAY) 
    GROUP BY DAYNAME(att.start)
    `
    const data2 = await db2.sequelize.query(thisQuery2);

      res.status(200).send({
          message: "Hr",
          status: 200,
          output: {list:data[0], report:data2[0]}
      })
  }
  catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal Server Error' });
  }
};



// exports.getDashboardContactMasters = async (req, res) => {
//   try {
//     const module = req.params.moduleId;
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 
//     const masterId = req.params.option_type 

//     let thisQuery1 = ` `
//     // let todayCheck = ` (DATE(c.created_at) = DATE(NOW())) `
//     // let yesterdayCheck = ` (DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//     // let monthCheck = ` SELECT m.month, 
//     // IFNULL(n.count,0) count FROM 
//     // (SELECT 'January' AS MONTH UNION 
//     // SELECT 'February' AS MONTH UNION 
//     // SELECT 'March' AS MONTH UNION 
//     // SELECT 'April' AS MONTH UNION 
//     // SELECT 'May' AS MONTH UNION 
//     // SELECT 'June' AS MONTH UNION 
//     // SELECT 'July' AS MONTH UNION 
//     // SELECT 'August' AS MONTH UNION 
//     // SELECT 'September' AS MONTH UNION 
//     // SELECT 'October' AS MONTH UNION 
//     // SELECT 'November' AS MONTH UNION 
//     // SELECT 'December' AS MONTH ) m 
//     // LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//     // COUNT(contact_status) AS count FROM lz_contacts `

//     const queryString = req.query;

//     let querydatebetween = await datebetween(queryString).then(dateBetween => {
//       return dateBetween;
//     });

//     if (masterId) {
//       // thisQuery1 += `SELECT COUNT(contact_status) as contacts_status FROM lz_contacts where status = 1 `
//       // if(timeLimit == 0) {
//         thisQuery1 += ` SELECT COUNT(c.${masterId}) as count, m.option_value as ${masterId} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' :  module == 3 ? 'lz_properties' :  module == 4 ? 'lz_tasks' : 'lz_transactions'} as c
//         LEFT JOIN lz_masters as m on (c.${masterId} = m.id)
//         where c.status = 1 and m.option_type = '${masterId}' and ${querydatebetween}
//         group by m.option_value
//        `
//       // }
//       // if(timeLimit == 1) {
//       //   // thisQuery1 += `SELECT COUNT(contact_status) as contacts_status_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       //   thisQuery1 +=  `SELECT COUNT(c.contact_status) as count, m.option_value as contact_status FROM lz_contacts as c
//       //   LEFT JOIN lz_masters as m on (c.contact_status = m.id)
//       //   where c.status = 1 and m.option_type = 'contact_status' and ${todayCheck}
//       //   group by m.option_value
//       //   `
//       // }
//       // if(timeLimit == 2) {
//       //   thisQuery1 +=  `SELECT COUNT(c.contact_status) as count, m.option_value as contact_status FROM lz_contacts as c
//       //   LEFT JOIN lz_masters as m on (c.contact_status = m.id)
//       //   where c.status = 1 and m.option_type = 'contact_status' and ${yesterdayCheck}
//       //   group by m.option_value
//       //   `
//       // }
//       // if (timeLimit == 6) {
//       //   thisQuery1 += `${monthCheck}
//       //   where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//       //   group by monthname(created_at), 
//       //   month(created_at) 
//       //   order by month(created_at))n ON m.MONTH = n.MONTH `
//       // }
//     }
//     if (masterId == 2) {
//       // thisQuery1 += `SELECT COUNT(contact_type) as contact_type FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(contact_type) as contact_type FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(contact_type) as contact_type_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(contact_type) as contact_type_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(contact_type) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
//     if (masterId == 3) {
//       // thisQuery1 += `SELECT COUNT(contact_category) as contact_category FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(contact_category) as contact_category FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(contact_category) as contact_category_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(contact_category) as contact_category_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(contact_category) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
//     if (masterId == 4) {
//       // thisQuery1 += `SELECT COUNT(source) as contacts_source FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(source) as source FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(source) as source_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(source) as source_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(source) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
//     if (masterId == 5) {
//       // thisQuery1 += `SELECT COUNT(contact_group) as contact_group FROM lz_contacts where status = 1 `
//       if(timeLimit == 0) {
//         thisQuery1 += `SELECT COUNT(contact_group) as contact_group FROM lz_contacts where status = 1 `
//       }
//       if(timeLimit == 1) {
//         thisQuery1 += `SELECT COUNT(contact_group) as contact_group_today FROM lz_contacts where status = 1 and (DATE(created_at) = DATE(NOW())) `
//       }
//       if(timeLimit == 2) {
//         thisQuery1 += `SELECT COUNT(contact_group) as contact_group_yesterday FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//       }
//       if (timeLimit == 6) {
//         thisQuery1 += `SELECT m.month, 
//         IFNULL(n.count,0) count FROM 
//         (SELECT 'January' AS MONTH UNION 
//         SELECT 'February' AS MONTH UNION 
//         SELECT 'March' AS MONTH UNION 
//         SELECT 'April' AS MONTH UNION 
//         SELECT 'May' AS MONTH UNION 
//         SELECT 'June' AS MONTH UNION 
//         SELECT 'July' AS MONTH UNION 
//         SELECT 'August' AS MONTH UNION 
//         SELECT 'September' AS MONTH UNION 
//         SELECT 'October' AS MONTH UNION 
//         SELECT 'November' AS MONTH UNION 
//         SELECT 'December' AS MONTH ) m 
//         LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//         COUNT(contact_group) AS count FROM lz_contacts 
//         where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//         group by monthname(created_at), 
//         month(created_at) 
//         order by month(created_at))n ON m.MONTH = n.MONTH `
//     }
//     }
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };



// exports.getDashboardContactCount = async (req, res) => {
//   try {

//     const module = req.params.moduleId;

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id 

//   // let thisQuery1 = ` `

//   // if (timeLimit == 1) {
//   //   thisQuery1 += ` SELECT COUNT(id) as today_contact_count FROM lz_contacts where (DATE(created_at) = DATE(NOW()))`
//   // }
//   // if (timeLimit == 2) {
//   //   thisQuery1 += ` SELECT COUNT(id) as yesterday_contact_count FROM lz_contacts where (DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)) `
//   // }
//   // if (timeLimit == 3) {
//   //   thisQuery1 += ` SELECT COUNT(id) as lastweek_contact_count, WEEK(created_at) as week_name FROM lz_contacts where (created_at >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY AND created_at < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY) group by DAY(created_at) order by DAY(created_at) `
//   // }
//   // if (timeLimit == 4) {
//   //   thisQuery1 += ` SELECT COUNT(id) as lastweek_contact_count FROM lz_contacts where (created_at >= last_day(curdate() - interval 1 month) + interval 1 day AND created_at < last_day(curdate() - interval 1 month)) group by DATE(created_at) order by DATE(created_at) `
//   // }

//   // if (timeLimit == 6) {
//   //     thisQuery1 += `SELECT m.month, 
//   //     IFNULL(n.count,0) count FROM 
//   //     (SELECT 'January' AS MONTH UNION 
//   //     SELECT 'February' AS MONTH UNION 
//   //     SELECT 'March' AS MONTH UNION 
//   //     SELECT 'April' AS MONTH UNION 
//   //     SELECT 'May' AS MONTH UNION 
//   //     SELECT 'June' AS MONTH UNION 
//   //     SELECT 'July' AS MONTH UNION 
//   //     SELECT 'August' AS MONTH UNION 
//   //     SELECT 'September' AS MONTH UNION 
//   //     SELECT 'October' AS MONTH UNION 
//   //     SELECT 'November' AS MONTH UNION 
//   //     SELECT 'December' AS MONTH ) m 
//   //     LEFT JOIN( SELECT MONTHNAME(created_at) AS MONTH, 
//   //     COUNT(id) AS count FROM lz_contacts 
//   //     where YEAR(created_at) = YEAR(NOW() - INTERVAL 0 YEAR) 
//   //     group by monthname(created_at), 
//   //     month(created_at) 
//   //     order by month(created_at))n ON m.MONTH = n.MONTH `
//   // }

//   let thisQuery1 = ` `

//   const queryString = req.query;

//   let querydatebetween = await datebetween(queryString).then(dateBetween => {
//     return dateBetween;
//   });

//       thisQuery1 += ` SELECT COUNT(c.id) as count, DAYNAME(c.created_at) as dayname FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' :  module == 3 ? 'lz_properties' :  module == 4 ? 'lz_tasks' : 'lz_transactions'} as c
//       where c.status = 1 ${querydatebetween}
//       group by c.id
//      `
    
//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// const roleCheck = async () => {

//   const module = req.params.moduleId;
//   const created_id = req.user.id
//   const created_by = created_id.id
//   console.log('created_by', created_by);

//   const organ_id = req.user.id
//   const org_id = organ_id.org_id
//   console.log('organ_id', org_id);

//   const role = req.user.id
//   const role_id = 1
//   console.log('role_id', role_id);

//   if (role_id == 1) {
//     thisQuery += ` `
//   }
//   if (role_id == 2) {

//     thisQuery += ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `

//     thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
//   }
//   if (role_id >= 3) {
//     thisQuery += ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//   }
//   return thisQuery;
// }


// exports.getDashboardCount = async (req, res) => {
//   try {

//   // let thisQuery = ` SELECT designation from lz_user where id ='${created_by}' limit 1 `
//   // const dashboardData = await db2.sequelize.query(thisQuery);
//   // const dataDashboard = dashboardData[0]
//   // console.log("dashboardData", dataDashboard);

//   // const role = dataDashboard[0] ? dataDashboard[0]["designation"] : 0 role.designation

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 1
//     console.log('role_id', role_id);

//   let thisQuery1 = ` `

  // if (role_id == 1) {
  //     thisQuery1 += `SELECT`
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 ) AS contacts, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 ) AS leads, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 ) AS properties, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 ) AS tasks, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 ) AS transactions `
  //   }
  // if (role_id == 2) {
  //     thisQuery1 += `SELECT`
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}) AS contacts, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS leads, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS properties, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS tasks, `
  //     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 and created_by = ${created_by} ) AS transactions `
  // }
//   if (role_id >= 2) {
//       thisQuery1 += `SELECT`
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by} ) AS contacts, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS leads, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS properties, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status= 1 and FIND_IN_SET(${created_by},assign_to)>0 or created_by = ${created_by}  ) AS tasks, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 and created_by = ${created_by} ) AS transactions `
//   }

//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0][0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// exports.getDashboardCount = async (req, res) => {
//   try {

//     const module = req.params.moduleId;

//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);
  
//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);
  
//     const role = req.user.id
//     const role_id = 4
//     console.log('role_id', role_id);

//   let thisQuery1 = ` `

//   let roleCheck = ``
//   if (role_id == 1) {
//     roleCheck = ` `
//   }
//   if (role_id == 2) {
//     roleCheck = ` where FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//     roleCheck = ` and c.status= 1 and c.created_by = ${created_by} `
//   }
//   if (role_id >= 3) {
//     roleCheck = ` where c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//   }

//   if (role_id == 1) {
//     thisQuery1 += `SELECT`
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts where status = 1 ) AS contacts, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads where status = 1 ) AS leads, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties where status = 1 ) AS properties, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks where status = 1 ) AS tasks, `
//     thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions where status = 1 ) AS transactions `
//   }
//   if (role_id >= 2) {
//       thisQuery1 += `SELECT`
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_contacts ${roleCheck}) AS contacts, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_leads ${roleCheck} ) AS leads, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_properties ${roleCheck} ) AS properties, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_tasks ${roleCheck} ) AS tasks, `
//       thisQuery1 += ` (SELECT ifnull(COUNT(*),0) FROM lz_transactions ${roleCheck} ) AS transactions `
//   }

//   const dashboardData1 = await db2.sequelize.query(thisQuery1);
//   console.log("dashboardData1" , thisQuery1);

//     res.status(200).send({
//       status:200,
//       message:'Success',
//       output:dashboardData1[0][0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };


// 10 july 
// exports.getDashboardMastersCount = async (req, res) => {
//   try {
//     const module = req.params.moduleId;
//     const created_id = req.user.id
//     const created_by = created_id.id
//     console.log('created_by', created_by);

//     const organ_id = req.user.id
//     const org_id = organ_id.org_id
//     console.log('organ_id', org_id);

//     const role = req.user.id
//     const role_id = role.designation
//     console.log('role_id', role_id);

//     const timeLimit = req.params.id
//     const masterId = req.params.option_type

//     const userID = req.params.created_by;
//     const teamID = req.params.team_leader;

//     let thisQuery1 = ` `

//     const queryString = req.query;

//     let querydatebetween = await datebetween(queryString).then(dateBetween => {
//       return dateBetween;
//     });

//     let roleCheck = ``
//     if (role_id == 1) {
//       roleCheck = ` `
//     }
//     if (role_id == 2) {
//       roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}  `
//       roleCheck = ` and c.created_by = ${created_by} `
//     }
//     if (role_id >= 3) {
//       roleCheck = ` and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by} `
//     }
    
//     let thisQuery123 = ` select designation from lz_user where id = ${userID} `
//     const adminData = await db2.sequelize.query(thisQuery123);

//     let thisQuery1234 = ` select designation from lz_user where id = ${teamID} `
//     const adminTeamData = await db2.sequelize.query(thisQuery1234);

//     const findAdmin = adminData[0][0]?.designation
//     console.log('adminData', findAdmin);

//     const findTeamAdmin = adminTeamData[0][0]?.designation
//     console.log('findTeamAdmin', findTeamAdmin);

//     if (masterId) {
//       if (teamID == 0) {
//         if (module == 1) {
//           thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count, pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name ` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'gender' ? `COUNT(cd.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'gender' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : ""} as c
//           ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id)` :
//               masterId == 'country' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country) ` :
//                 masterId == 'state' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
//                   masterId == 'city' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
//                   masterId == 'locality' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) ` :
//                   masterId == 'gender' ? `LEFT JOIN lz_contact_details as cd on (cd.contact_id = c.id) LEFT JOIN lz_masters as m on (cd.${masterId} = m.id)` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//           LEFT JOIN lz_user as us on (us.id = c.created_by)
//           LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//           where c.status = 1 and FIND_IN_SET(${userID},c.assign_to)>0 ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id' && masterId !== 'locality' && masterId !== 'gender' ? `and m.option_type = '${masterId}' ` : ''} 
//           ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? `group by lr.country` : masterId == 'state' ? `group by lr.state` : masterId == 'city' ? `group by lr.city` : masterId == 'locality' ? `group by lr.locality` : masterId == 'gender' ? `group by cd.gender` : `group by m.option_value`} `
//         }
//         if (module == 2) {
//           thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count,pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name ` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}`  : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_leads as c
//         ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id) ` :
//               masterId == 'country' ? `LEFT JOIN lz_lead_requirements as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country) ` :
//                 masterId == 'state' ? `LEFT JOIN lz_lead_requirements as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
//                   masterId == 'city' ? `LEFT JOIN lz_lead_requirements as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
//                     masterId == 'locality' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) ` :
//                     masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and FIND_IN_SET(${userID},c.assign_to)>0  ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id' && masterId !== 'locality' ? `and m.option_type = '${masterId}' ` : ''} 
//         ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? `group by lr.country` : masterId == 'state' ? `group by lr.state` : masterId == 'city'  ? `group by lr.city` : masterId == 'locality' ? `group by lr.locality` : `group by m.option_value`}
//        `
//         }
//         if (module == 3) {
//           thisQuery1 += ` SELECT ${masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count,  st.name as state_name ` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : masterId == 'source' ? `COUNT(c.property_source) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_properties as c
//           ${masterId == 'country' ? `LEFT JOIN lz_property_addresses as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country) ` :
//                 masterId == 'state' ? `LEFT JOIN lz_property_addresses as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
//                   masterId == 'city' ? `LEFT JOIN lz_property_addresses as lr on (lr.${masterId} = c.id)  LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
//                   masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.property_source = m.id) ` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and FIND_IN_SET(${userID},c.assign_to)>0 ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' ? `and m.option_type = '${masterId}' ` : ''} 
//         ${masterId == 'country' ? `group by lr.country` : masterId == 'state' ? `group by lr.state` : masterId == 'city' ? `group by lr.city` : `group by m.option_value`}
//        `
//         }
//         if (module == 4) {
//           thisQuery1 += ` SELECT ${masterId == 'contact' ? `COUNT(c.${masterId}) as count` : masterId == 'project' ? `COUNT(c.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'contact' ? `lr.first_name as ${masterId}` : masterId == 'project' ? `pa.name_of_building as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_tasks as c
//           ${masterId == 'contact' ? `LEFT JOIN lz_contacts as lr on (c.${masterId} = lr.id) ` :
//                 masterId == 'project' ? `LEFT JOIN lz_properties as p on (c.${masterId} = p.id) LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id) ` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and FIND_IN_SET(${userID},c.assign_to)>0 ${querydatebetween} ${masterId !== 'contact' && masterId !== 'project' ? `and m.option_type = '${masterId}' ` : ''} 
//         ${masterId == 'contact' ? `group by c.contact` : masterId == 'project' ? `group by c.project` : `group by m.option_value`}
//        `
//         }
//         if (module == 5) {
//           thisQuery1 += ` SELECT ${masterId == 'country' ? `COUNT(lre.${masterId}) as count` : masterId == 'state' ? `COUNT(lre.${masterId}) as count` : masterId == 'city' ? `COUNT(lre.${masterId}) as count` : masterId == 'locality' ? `COUNT(lre.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : masterId == 'property_status' ? `COUNT(pro.property_status) as count` : `COUNT(le.${masterId}) as count`}, ${masterId == 'country' ? `lre.country as ${masterId}` : masterId == 'state' ? `lre.state as ${masterId}` : masterId == 'city' ? `lre.city as ${masterId}` : masterId == 'locality' ? `lre.locality as ${masterId}` : masterId == 'source' ? `COUNT(c.lead_source) as count` : masterId == 'property_status' ? `pro.property_status as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_transactions as c
//           LEFT JOIN lz_leads as le on (le.id = c.lead_id)
//           LEFT JOIN lz_properties as p on (p.id = le.property_id)
//           ${masterId == 'country' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.${masterId} = lr.id) ` :
//                 masterId == 'state' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.${masterId} = lr.id) ` :
//                   masterId == 'city' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.${masterId} = lr.id) ` :
//                   masterId == 'locality' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = c.id) ` :
//                   masterId == 'property_status' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_properties as pro on (lr.property_id = pro.id) ` :
//                   masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
//                     `LEFT JOIN lz_masters as m on (le.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         where c.status = 1 and p.status = 1 and le.status = 1 and c.created_by = ${userID} ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'locality' && masterId !== 'property_status' ? `and m.option_type = '${masterId}' ` : ''} 
//         ${masterId == 'country' ? `group by lre.country` : masterId == 'state' ? `group by lre.state` : masterId == 'city' ? `group by lre.city` : masterId == 'locality' ? `group by lre.locality` : masterId == 'property_status' ? `group by pro.property_status` : `group by m.option_value`}
//        `
//         }
//         console.log("Teamsssssssss");

//       } 
//       else if (userID == 0) {
//         if (module == 1) {
//           thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count, pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'gender' ? `COUNT(cd.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'gender' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM ${module == 1 ? 'lz_contacts' : module == 2 ? 'lz_leads' : module == 3 ? 'lz_properties' : module == 4 ? 'lz_tasks' : module == 5 ? 'lz_transactions' : module == 6 ? 'lz_contact_address' : ""} as c
//           ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id)` :
//               masterId == 'country' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)` :
//                 masterId == 'state' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)` :
//                   masterId == 'city' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)` :
//                   masterId == 'locality' ? `LEFT JOIN lz_contact_address as lr on (lr.${masterId} = c.id) ` :
//                   masterId == 'gender' ? `LEFT JOIN lz_contact_details as cd on (cd.contact_id = c.id) LEFT JOIN lz_masters as m on (cd.${masterId} = m.id) ` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//           LEFT JOIN lz_user as us on (us.id = c.created_by)
//           LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)      
//           LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
//           where c.status = 1 
//           ${findTeamAdmin == 1 ? `` : 
//           findTeamAdmin == 2 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} ` : 
//           findTeamAdmin == 3 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} ` : 
//           findTeamAdmin == 4 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` : ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` } 
//           ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id' && masterId !== 'locality' && masterId !== 'gender' ? `and m.option_type = '${masterId}' ` : ''}
//           ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? `group by lr.country` : masterId == 'state' ? `group by lr.state` : masterId == 'city' ? `group by lr.city` : masterId == 'locality' ? `group by lr.locality` : `group by m.option_value`} `
//         }
//         if (module == 2) {
//           thisQuery1 += ` SELECT ${masterId == 'property_id' ? `COUNT(c.${masterId}) as count,pa.name_of_building as property_name` : masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name ` : masterId == 'locality' ? `COUNT(lr.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'property_id' ? `c.property_id as ${masterId}` : masterId == 'locality' ? `lr.locality as ${masterId}` : masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_leads as c
//         ${masterId == 'property_id' ? `LEFT JOIN lz_properties as p on (c.property_id = p.id) LEFT JOIN lz_property_addresses as pa on (pa.${masterId} = p.id) ` :
//               masterId == 'country' ? `LEFT JOIN lz_lead_requirements as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)` :
//                 masterId == 'state' ? `LEFT JOIN lz_lead_requirements as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state) ` :
//                   masterId == 'city' ? `LEFT JOIN lz_lead_requirements as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city) ` :
//                   masterId == 'locality' ? `LEFT JOIN lz_lead_requirements as lr on (lr.lead_id = c.id) ` :
//                   masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
//         where c.status = 1
//         ${findTeamAdmin == 1 ? `` : 
//         findTeamAdmin == 2 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 3 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 4 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` : ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` }  
//         ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' && masterId !== 'property_id'  && masterId !== 'locality' ? `and m.option_type = '${masterId}' ` : ''}
//         ${masterId == 'property_id' ? `and p.status = 1 group by pa.name_of_building` : masterId == 'country' ? `group by lr.country` : masterId == 'state' ? `group by lr.state` : masterId == 'city' ? `group by lr.city` : masterId == 'locality' ? `group by lr.locality` : `group by m.option_value`}
//        `
//         }
//         if (module == 3) {
//           thisQuery1 += ` SELECT ${masterId == 'country' ? `COUNT(lr.${masterId}) as count, cou.name as country_name` : masterId == 'state' ? `COUNT(lr.${masterId}) as count, st.name as state_name` : masterId == 'city' ? `COUNT(lr.${masterId}) as count, ci.name as city_name ` : masterId == 'source' ? `COUNT(c.property_source) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'country' ? `lr.country as ${masterId}` : masterId == 'state' ? `lr.state as ${masterId}` : masterId == 'city' ? `lr.city as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_properties as c
//           ${masterId == 'country' ? `LEFT JOIN lz_property_addresses as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_country as cou on (cou.id = lr.country)` :
//                 masterId == 'state' ? `LEFT JOIN lz_property_addresses as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_state as st on (st.id = lr.state)` :
//                   masterId == 'city' ? `LEFT JOIN lz_property_addresses as lr on (lr.${masterId} = c.id) LEFT JOIN ${DbName}.lz_city as ci on (ci.id = lr.city)` :
//                   masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.property_source = m.id) ` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
//         where c.status = 1
//         ${findTeamAdmin == 1 ? `` : 
//         findTeamAdmin == 2 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 3 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 4 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` : ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` }  
//         ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city' ? `and m.option_type = '${masterId}' ` : ''} 
//         ${masterId == 'country' ? `group by lr.country` : masterId == 'state' ? `group by lr.state` : masterId == 'city' ? `group by lr.city` : `group by m.option_value`}
//        `
//         }
//         if (module == 4) {
//           thisQuery1 += ` SELECT ${masterId == 'contact' ? `COUNT(c.${masterId}) as count` : masterId == 'project' ? `COUNT(c.${masterId}) as count` : `COUNT(c.${masterId}) as count`}, ${masterId == 'contact' ? `lr.first_name as ${masterId}` : masterId == 'project' ? `pa.name_of_building as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_tasks as c
//           ${masterId == 'contact' ? `LEFT JOIN lz_contacts as lr on (c.${masterId} = lr.id) ` :
//                 masterId == 'project' ? `LEFT JOIN lz_properties as p on (c.${masterId} = p.id) LEFT JOIN lz_property_addresses as pa on (pa.property_id = p.id) ` :
//                     `LEFT JOIN lz_masters as m on (c.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
//         where c.status = 1 
//         ${findTeamAdmin == 1 ? `` : 
//         findTeamAdmin == 2 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 3 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 4 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` : ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` } 
//         ${querydatebetween} ${masterId !== 'contact' && masterId !== 'project' ? `and m.option_type = '${masterId}' ` : ''} 
//         ${masterId == 'contact' ? `group by c.contact` : masterId == 'project' ? `and p.status = 1 group by c.project` : `group by m.option_value`}
//        `
//         }
//         if (module == 5) {
//           thisQuery1 += ` SELECT ${masterId == 'country' ? `COUNT(lre.${masterId}) as count` : masterId == 'state' ? `COUNT(lre.${masterId}) as count` : masterId == 'city' ? `COUNT(lre.${masterId}) as count` : masterId == 'locality' ? `COUNT(lre.${masterId}) as count` : masterId == 'source' ? `COUNT(c.lead_source) as count` : masterId == 'property_status' ? `COUNT(pro.property_status) as count` : `COUNT(le.${masterId}) as count`}, ${masterId == 'country' ? `lre.country as ${masterId}` : masterId == 'state' ? `pro.state as ${masterId}` : masterId == 'city' ? `lre.city as ${masterId}` : masterId == 'locality' ? `lre.locality as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : masterId == 'source' ? `m.option_value as ${masterId}` : masterId == 'property_status' ? `pro.property_status as ${masterId}` : `m.option_value as ${masterId}`} FROM lz_transactions as c
//           LEFT JOIN lz_leads as le on (le.id = c.lead_id)
//           LEFT JOIN lz_properties as p on (p.id = le.property_id)
//           ${masterId == 'country' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.${masterId} = lr.id) ` :
//                 masterId == 'state' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.${masterId} = lr.id) ` :
//                   masterId == 'city' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.${masterId} = lr.id) ` :
//                   masterId == 'locality' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_lead_requirements as lre on (lre.lead_id = c.id) ` :
//                   masterId == 'property_status' ? `LEFT JOIN lz_leads as lr on (lr.id = c.lead_id) LEFT JOIN lz_properties as pro on (lr.property_id = pro.id) ` :
//                   masterId == 'source' ? `LEFT JOIN lz_masters as m on (c.lead_source = m.id) ` :
//                     `LEFT JOIN lz_masters as m on (le.${masterId} = m.id)`}
//         LEFT JOIN lz_user as us on (us.id = c.created_by)
//         LEFT JOIN lz_user as us1 on (us1.id = us.team_leader)
//         LEFT JOIN lz_user as us2 on (us2.id = us.portfolio_head)
//         where c.status = 1 
//         ${findTeamAdmin == 1 ? `` : 
//         findTeamAdmin == 2 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.team_leader = ${teamID} or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 3 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 or us.portfolio_head = ${teamID} ` : 
//         findTeamAdmin == 4 ? ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` : ` and FIND_IN_SET(${teamID},c.assign_to)>0 ` } 
//         ${querydatebetween} ${masterId !== 'country' && masterId !== 'state' && masterId !== 'city'  && masterId !== 'locality' && masterId !== 'property_status'  ? `and m.option_type = '${masterId}' ` : ''} 
//         ${masterId == 'country' ? `group by lre.country` : masterId == 'state' ? `group by lre.state` : masterId == 'city' ? `group by lre.city` : masterId == 'locality' ? `group by lre.locality` : masterId == 'property_status' ? `group by pro.property_status` : `group by m.option_value`}
//        `
//         }
//       }
//       console.log("Teamsssssssss");
//   }

//     const dashboardData1 = await db2.sequelize.query(thisQuery1);
//     console.log("dashboardData1", thisQuery1);

//     res.status(200).send({
//       status: 200,
//       message: 'Success',
//       output: dashboardData1[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };