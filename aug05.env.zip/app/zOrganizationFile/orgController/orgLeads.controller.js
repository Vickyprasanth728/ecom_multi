const orgDbConfig = require("../orgConfig/orgDb.config.js");
const db2 = require("../orgModel/orgIndex.js");
const db = require("../../models");
const Op = db2.Sequelize.Op;
const path = require("path");
const fs = require("fs");
var Sequelize = require('sequelize');
const util = require('util');
const sql = require("../orgConfig/orgDb.config.js");
const readXlsxFile = require('read-excel-file/node');
const mailer = require("../orgModel/mailer.model.js");

exports.saveLeads = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const data = await db2['leads'].create({
      org_id: org_id,
      contact_id: req.body.contact_id,
      property_id: req.body.property_id,
      looking_for: req.body.looking_for,
      property_type: req.body.property_type,
      // city: req.body.city,
      lead_source: req.body.lead_source,
      lead_group: req.body.lead_group,
      segment: req.body.segment,
      lead_priority: req.body.lead_priority,
      fee_oppurtunity: req.body.fee_oppurtunity,
      lead_status: req.body.lead_status,
      assign_to: req.body.assign_to,
      sales_manager: req.body.sales_manager,
      created_by: created_by
    });
    let leadID = data?.dataValues.id

    const data1 = await db2['leadRequirement'].create({
        lead_id: leadID,
        requirement_location: req.body.requirement_location,
        budget_min: req.body.budget_min,
        budget_max: req.body.budget_max,
        money_term_min: req.body.money_term_min,
        money_term_max: req.body.money_term_max,
        no_of_bedrooms_min: req.body.no_of_bedrooms_min,
        no_of_bedrooms_max: req.body.no_of_bedrooms_max,
        no_of_bathrooms_min: req.body.no_of_bathrooms_min,
        no_of_bathrooms_max: req.body.no_of_bathrooms_max,
        built_up_area_min: req.body.built_up_area_min,
        built_up_area_max: req.body.built_up_area_max,
        plot_area_min: req.body.plot_area_min,
        plot_area_max: req.body.plot_area_max,
        possession_status: req.body.possession_status,
        age_of_property: req.body.age_of_property,
        vasthu_compliant: req.body.vasthu_compliant,
        property_facing: req.body.property_facing,
        furnishing: req.body.furnishing,
        car_park_min: req.body.car_park_min,
        car_park_max: req.body.car_park_max,
        timeline_for_closure_min: req.body.timeline_for_closure_min,
        timeline_for_closure_max: req.body.timeline_for_closure_max,
        amenities: req.body.amenities,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city,
        locality: req.body.locality,
        zipcode: req.body.zipcode,
    });

    console.log('leadIDDD',leadID);

    const LeadLogs = await db2['logs'].create({
      org_id: org_id,
      module_id: leadID,
      module_name: "2",
      note: "Lead created at",
      user_id: created_by
    })
    // console.log("LeadLogs", LeadLogs);
    // Email Trigger
    const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where module_id = 1 and status = 1 `);
    // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
    const emailTri = email_settings[0][0]["status"]
    console.log("emailTri", emailTri);

    //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
      // Team Leader
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      // Sub TL
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      // Admin
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
      // Assign To
      const assignEmail = await db2.sequelize.query(`select us.id as id, us.email as email from lz_user as us where us.id IN (${req.body.assign_to}) `);
      const assEmail = assignEmail[0].map(item => item.email).join(', ')
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
      console.log("assign_to",assEmail);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let thisQueryPro = `select p.id as id, pa.name_of_building as property_name
      from lz_properties p
      left join lz_property_addresses as pa on (p.id = pa.property_id)
      where p.status = 1 and pa.property_id = '${req.body.property_id}' `;

      const project_name_data = await db2.sequelize.query(thisQueryPro)
      console.log("project_name_data", project_name_data[0][0]);

      const project_name = project_name_data[0][0] ? project_name_data[0][0].property_name : 0
      console.log('project_name', project_name);

      let message = {
        from: cEmail,
        to: [checkAdmin1,checkTl1,checksubTL1, assEmail].join(', '),
        subject: "New Lead Created",
        html:
          "<h3> New Lead has been created with </h3>" +
          "<h3> Project Id: </h3>" +
          req.body.property_id +
          "<h3>Project Name:</h3>" +
          project_name + "",
      };
      console.log("message", message);
      mailer.sendMail(message, function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }
    
    res.status(200).send({
      status:200,
      message:'Success',
      output:data,
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getLeadFinal = async (req, res) => {
    try {
      
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.body.id
    
      var condition = {
        where:{
          status:1, 
        },
        order: [['id', 'DESC']], // ASC, DESC
        attributes: {exclude :['createdAt','updatedAt']},
        include: [
          {
            model: db2['contacts'],
            // attributes:['id','first_name'],
            where: {status:1},
            as:'contact_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'looking_for_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'property_type_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_source_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_group_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'segment_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_priority_name',
            required: false,
          },
          {
            model: db2['masters'],
            attributes: ['option_type','option_value'],
            where: {},
            as:'lead_status_name',
            required: false,
          },
          {
            model: db2['leadRequirement'],
            attributes:{exclude:['createdAt','updatedAt']},
            where: {},
            as:'lead_requirement_name',
            required: false,
            include: [
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where: {},
              as:'age_of_property_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where: {},
              as:'vasthu_compliant_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where: {},
              as:'property_facing_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'amenities_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'furnishing_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'requirement_location_name',
              required: false,
              },
              {
              model: db2['masters'],
              attributes: ['option_type','option_value'],
              where:{status:1},
              as:'possession_status_name',
              required: false,
              },
          ],
          },
        ],
          offset :parseInt(req.query.offset) || 0,
        //   limit: parseInt(req.query.limit) || 12
          limit : (req.query.offset ? 12 : null)
      };
    //   var offset = parseInt(req.query.offset);
    //   var limit = parseInt(req.query.limit);
  
    //   if (offset >= 0 && limit >= 0) {
    //     condition.offset = offset;
    //     condition.limit = limit;
    //   }
  
      const data = await db2['leads'].findAll(condition);
      
      const filters = req.query;
      const filteredLeads = data.filter(user => {
        let isValid = true;
        for (key in filters) {
          if(key != "offset" ) {
          console.log('keyyyyyyy',key, user[key], filters[key]);
          isValid = isValid && user[key] == filters[key];
          }
        }
        return isValid;
      });
      const data2 = await db2['leads'].findAll({
        where:{status:1},
        attributes: [[Sequelize.fn('COUNT', Sequelize.col('id')), 'leads_count']],
      });
      const contact = data2[0]?.dataValues.contact_count
      
      const count_filter = (filteredLeads)
      console.log('count_filter', count_filter.length);

      const leadR = filteredLeads[1]?.dataValues?.lead_requirement_name[0]?.dataValues
      console.log("leadR", leadR);


      res.status(200).send({
        status:200,
        message:'Success',
        count:count_filter.length,
        output:filteredLeads,
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.getLeads = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
  
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

  let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, CONVERT(l.sales_manager USING utf8) as sales_manager, c.company_name as company_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name, lr.age_of_property as age_of_property, lr.vasthu_compliant as vasthu_compliant,  CONVERT(lr.furnishing USING utf8) as furnishing, CONVERT(lr.amenities USING utf8) as amenities, CONVERT(lr.possession_status USING utf8) as possession_status,
  lr.budget_min as budget_min, lr.budget_max as budget_max, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max, lr.no_of_bathrooms_min as no_of_bathrooms_min, lr.no_of_bathrooms_max as no_of_bathrooms_max, lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.car_park_min as car_park_min, lr.car_park_max as car_park_max, lr.timeline_for_closure_min as timeline_for_closure_min, lr.timeline_for_closure_max as timeline_for_closure_max, lr.property_facing as property_facing, lr.country as country, lr.state as state, lr.city as city, lr.zipcode as zipcode,
  lr.locality as locality,
  lrn.option_value as looking_for_name, 
  pt.option_value as property_type_name, 
  ls.option_value as lead_source_name,
  lg.option_value as lead_group_name,
  seg.option_value as segment_name,
  lp.option_value as lead_priority_name,
  lss.option_value as lead_status_name,
  aop.option_value as age_of_property_name,
  vc.option_value as vasthu_compliant_name,
  pf.option_value as property_facing_name,
  GROUP_CONCAT(distinct CONCAT(amen.option_value),'-',amen.id) as amenities_name,
  GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as possession_status_name,
  GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,

  (SELECT COUNT(id) FROM lz_notes where status = 1 and (module_id = l.id and module_name = 2 or module_id = l.contact_id)) as notes_count,
  (SELECT COUNT(id) FROM lz_file_uploads where module_id = l.id and module_name = 2 ) as files_count,
  (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_leads on (lz_leads.id = l.contact_id) where t.contact = l.contact_id) as task_count,
  (SELECT reply FROM lz_notes where module_name = 2 and module_id = l.id order by id desc limit 1 ) as last_note,
  (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time <= curdate() order by ta.task_time DESC limit 1) as last_task_date,
  (SELECT DATE_FORMAT(ta.task_time,'%Y-%m-%d') FROM lz_tasks as ta where ta.contact = l.contact_id and ta.task_time >= curdate() order by ta.task_time limit 1) as next_task_date

  from lz_leads as l
  LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
  LEFT JOIN lz_lead_requirements as lr on (l.id = lr.lead_id) 
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
  LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,l.created_by) > 0 
  LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
  LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
  LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
  LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
  LEFT JOIN lz_masters as seg on (seg.id = l.segment)
  LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
  LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
  LEFT JOIN lz_masters as aop on (aop.id = lr.age_of_property)
  LEFT JOIN lz_masters as vc on (vc.id = lr.vasthu_compliant)
  LEFT JOIN lz_masters as pf on (pf.id = lr.property_facing) 
  LEFT JOIN lz_user as us1 on (us1.id = l.created_by)

  LEFT JOIN lz_user as us5 on FIND_IN_SET(us5.id,c.assign_to) > 0 
  left join lz_user as us4 on (us5.team_leader = us4.id) 
  LEFT JOIN lz_user as us6 on FIND_IN_SET(us6.id,c.assign_to) > 0 
  left join lz_user as us7 on (us6.portfolio_head = us7.id) 
  `

  thisQuery += 'LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,lr.amenities) > 0 '
  thisQuery += 'LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,lr.furnishing) > 0 '
  thisQuery += 'LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,lr.possession_status) > 0 '
  thisQuery += `where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`}`


  // LEFT JOIN lz_user as us5 on (c.created_by = us5.id) 
  // LEFT JOIN lz_user as us4 on (us5.team_leader = us4.id) 
  // if (role_id == 1) {
  //   thisQuery += ` `
  // }
  // if (role_id == 2) {

  //   let thisQuery1 =`select GROUP_CONCAT(distinct CONCAT(us.id)) as exec, us.team_leader as team_leader from lz_user as us where us.team_leader = ${created_by} limit 1 `
  //   const data = await db2.sequelize.query(thisQuery1);
  //   console.log('dataaaaaaaaaaaaa',data[0]);

  //   thisQuery += ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 or us5.team_leader = ${created_by}  `

  //   // thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
  // }
  // if (role_id >= 3) {
  //   thisQuery += ` and c.status= 1 and FIND_IN_SET(${created_by},c.assign_to)>0 `
  // }

  if (role_id == 1) {
    thisQuery += ` `
  }
  if (role_id == 2) {
    thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or l.created_by = ${created_by}) `
    // thisQuery += ` and c.created_by = ${created_by} `
  }
  if (role_id == 3) {
    thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or us.portfolio_head = ${created_by} or l.created_by = ${created_by}) `
    // thisQuery += ` and c.created_by = ${created_by} `
  }
  if (role_id == 4) {
    thisQuery += ` and (FIND_IN_SET(${created_by},l.assign_to)>0 or l.created_by = ${created_by}) `
  }
  if (role_id == 5) {
    thisQuery += ` `
  }
  if (role_id == 6) {
    thisQuery += `and l.created_by = ${created_by} `
  }
  if (role_id >= 7) {
    thisQuery += `and l.created_by = ${created_by} `
  }

  const filters = req.query;
  // for (key in filters) {
    if (filters.looking_for) {
      thisQuery += " and l.looking_for = " + `${filters.looking_for} `
    }
    if (filters.lead_source) {
      thisQuery += "and l.lead_source = " + `${filters.lead_source} `
    }
    if (filters.lead_group) {
      thisQuery += "and l.lead_group = " + `${filters.lead_group} `
    }
    if (filters.fee_oppurtunity) {
      thisQuery += "and l.fee_oppurtunity = " + `${filters.fee_oppurtunity} `
    }
    if (filters.lead_status) {
      thisQuery += "and l.lead_status = " + `${filters.lead_status} `
    }
    if (filters.assign_to) {
      var a = filters.assign_to;
      var b = a.replace(/[,]/g, ",");
      thisQuery += `and CONCAT(',', l.assign_to, ',') REGEXP ',(${a}),' `
    }

    // WHERE Price BETWEEN 50 AND 60;
    // WHERE CategoryID and SupplierID BETWEEN 7 AND 28;
    // thisQuery += ` and no_of_bedrooms_min >= ${filters.no_of_bedrooms_min} and no_of_bedrooms_max <= ${filters.no_of_bedrooms_max} `

    if (filters.no_of_bedrooms_min && filters.no_of_bedrooms_max) {
      thisQuery += ` and no_of_bedrooms_min and no_of_bedrooms_max BETWEEN ${filters.no_of_bedrooms_min} and ${filters.no_of_bedrooms_max} ` 
    }
    if (filters.no_of_bathrooms_min && filters.no_of_bathrooms_max) {
      thisQuery += ` and no_of_bathrooms_min and no_of_bathrooms_max BETWEEN ${filters.no_of_bathrooms_min} and ${filters.no_of_bathrooms_max} ` 
    }
    if (filters.budget_min && filters.budget_max) {
      thisQuery += ` and budget_min and budget_max BETWEEN ${filters.budget_min} and ${filters.budget_max} ` 
    }
    if (filters.built_up_area_min && filters.built_up_area_max) {
      thisQuery += ` and built_up_area_min and built_up_area_max BETWEEN ${filters.built_up_area_min} and ${filters.built_up_area_max} ` 
    }
    if (filters.plot_area_min && filters.plot_area_max) {
      thisQuery += ` and plot_area_min and plot_area_max BETWEEN ${filters.plot_area_min} and ${filters.plot_area_max} ` 
    }
    if (filters.possession_status) {
      var a = filters.possession_status;
      var b = a.replace(/[,]/g, ",");
      thisQuery += `and CONCAT(',', lr.possession_status, ',') REGEXP ',(${a}),' `
    }
    if (filters.age_of_property) {
      thisQuery += " and lr.age_of_property = " + `${filters.age_of_property} `
    }
    if (filters.vasthu_compliant) {
      thisQuery += " and lr.vasthu_compliant = " + `${filters.vasthu_compliant} `
    }
    if (filters.property) {
      thisQuery += " and l.property_id = " + `${filters.property} `
    }
    if (filters.priority) {
      thisQuery += " and l.lead_priority = " + `${filters.priority} `
    }
    if (filters.property_type) {
      thisQuery += " and l.property_type = " + `${filters.property_type} `
    }
    if (filters.furnishing) {
      var a = filters.furnishing;
      var b = a.replace(/[,]/g, ",");
      thisQuery += `and CONCAT(',', lr.furnishing, ',') REGEXP ',(${a}),' `
    }
    if (filters.car_park_min) {
      thisQuery += " and lr.car_park_min = " + `${filters.car_park_min} `
    }
    if (filters.car_park_max) {
      thisQuery += " and lr.car_park_max = " + `${filters.car_park_max} `
    }
    if (filters.timeline_for_closure_min) {
      thisQuery += " and lr.timeline_for_closure_min = " + `${filters.timeline_for_closure_min} `
    }
    if (filters.timeline_for_closure_max) {
      thisQuery += " and lr.timeline_for_closure_max = " + `${filters.timeline_for_closure_max} `
    }
    if (filters.amenities) {
      var a = filters.amenities;
      var b = a.replace(/[,]/g, ",");
      thisQuery += `and CONCAT(',', lr.amenities, ',') REGEXP ',(${a}),' `
    }
    if (filters.created_at) {
      thisQuery += " and l.created_at = " + `${filters.created_at} `
    }
  // }
  thisQuery += ' group by l.id '

  if (filters.order_by) {
    let orderByString = filters.order_by.split('|')
    thisQuery += " order by " + `${orderByString[0]} ${orderByString[1]} `
  }
  const data1 = await db2.sequelize.query(thisQuery);

  if (filters.order_by =="" || filters.order_by == undefined) {
    thisQuery += '  order by l.id DESC '
  }

  if (filters.limit) {
    thisQuery += ` limit ${filters.limit},12 `
  }

  const data = await db2.sequelize.query(thisQuery);

  const count_filter = (data1[0])

    res.status(200).send({
      status:200,
      message:'Success',
      count: count_filter.length,
      output: data[0],
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editLead = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
      
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    const id = req.params.id;
    let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, CONVERT(l.sales_manager USING utf8) as sales_manager, c.company_name as company_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as contact_email, c.mobile as contact_mobile, c.mobile as contact_mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name,  pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name,  lr.age_of_property as age_of_property, lr.vasthu_compliant as vasthu_compliant, CONVERT(lr.furnishing USING utf8) as furnishing, CONVERT(lr.amenities USING utf8) as amenities, CONVERT(lr.possession_status USING utf8) as possession_status, lr.property_facing as property_facing,
    lr.budget_min as budget_min, lr.budget_max as budget_max, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max, lr.no_of_bathrooms_min as no_of_bathrooms_min, lr.no_of_bathrooms_max as no_of_bathrooms_max, lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.car_park_min as car_park_min, lr.car_park_max as car_park_max, lr.timeline_for_closure_min as timeline_for_closure_min, lr.timeline_for_closure_max as timeline_for_closure_max, lr.country as country, lr.state as state, lr.city as city, lr.zipcode as zipcode,
    lr.locality as locality,
    lrn.option_value as looking_for_name, 
    pt.option_value as property_type_name, 
    ls.option_value as lead_source_name,
    lg.option_value as lead_group_name,
    seg.option_value as segment_name,
    lp.option_value as lead_priority_name,
    lss.option_value as lead_status_name,
    aop.option_value as age_of_property_name,
    vc.option_value as vasthu_compliant_name,
    pf.option_value as property_facing_name,
    GROUP_CONCAT(distinct CONCAT(amen.option_value),'-',amen.id) as amenities_name,
    GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as possession_status_name,
    GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,
    (SELECT COUNT(id) FROM lz_notes where module_id = l.id and module_name = 2 and status = 1) as notes_count,
    (SELECT COUNT(id) FROM lz_file_uploads where module_id = l.id and module_name = 2 ) as files_count,
    (SELECT ifnull(COUNT(*),0) FROM lz_tasks as t LEFT JOIN lz_leads on (lz_leads.id = l.contact_id) where t.contact = l.contact_id) as task_count
    from lz_leads as l
    LEFT JOIN lz_contacts as c on (c.id = l.contact_id) 
    LEFT JOIN lz_lead_requirements as lr on (l.id = lr.lead_id) 
    LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
    LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
    LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,l.created_by) > 0 
    LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
    LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
    LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
    LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
    LEFT JOIN lz_masters as seg on (seg.id = l.segment)
    LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
    LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
    LEFT JOIN lz_masters as aop on (aop.id = lr.age_of_property)
    LEFT JOIN lz_masters as vc on (vc.id = lr.vasthu_compliant)
    LEFT JOIN lz_masters as pf on (pf.id = lr.property_facing) `;
  
    thisQuery += 'LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,lr.amenities) > 0 '
    thisQuery += 'LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,lr.furnishing) > 0 '
    thisQuery += 'LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,lr.possession_status) > 0 '
    thisQuery += `where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.id = ${id} group by l.id `

    const data1 = await db2.sequelize.query(thisQuery);

    const data = await db2.sequelize.query(thisQuery);
    console.log("dataaaaaaa", data);

    const localityCountryData = data[0][0]?.country
    const localityStateData = data[0][0]?.state
    const localityCityData = data[0][0]?.city
    const countryData = await db['country'].findOne({
      where: {
        status: 1, id:localityCountryData
      },
      attributes:['name'],
    });
    const stateData = await db['state'].findOne({
      where: {
        status: 1, id:localityStateData
      },
      attributes:['name'],
    });
    const cityData = await db['city'].findOne({
      where: {
        status: 1, id:localityCityData
      },
      attributes:['name'],
    });

    if (data1) {
      res.status(200).send({
        status:200,
        message:'Success',
        output: [{...data1[0][0], country_name: countryData?.dataValues.name ?? "",  state_name: stateData?.dataValues.name ?? "",  city_name: cityData?.dataValues.name ?? "" }],
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateLead = async (req, res) => {
  try {
    const id = req.params.id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);
    
    let thisQuery = ` select l.contact_id as contact_id, c.first_name as contact_name, l.lead_source as source, so.option_value as source_name, l.lead_status as lead_status, cs.option_value as lead_status_name, l.property_id as property_id, pa.name_of_building as property_name
    from lz_leads as l
    left join lz_contacts as c on (c.id = l.contact_id)
    left join lz_properties as p on (p.id = l.property_id)
    left join lz_property_addresses as pa on (p.id = pa.property_id)
    left join lz_masters as so on (so.id = l.lead_source)
    left join lz_masters as cs on (cs.id = l.lead_status)
    where l.status = 1 and l.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery);
    const dataContactID = data123[0][0]?.contact_id
    const dataContactName = data123[0][0]?.contact_name
    const dataSource = data123[0][0]?.source
    const dataSourceName = data123[0][0]?.source_name
    const dataStatus = data123[0][0]?.lead_status
    const dataStatusName = data123[0][0]?.lead_status_name
    const dataProperty = data123[0][0]?.property_id
    const dataPropertyName = data123[0][0]?.property_name
    console.log("dataContactID", dataContactID);
    console.log("dataContactName", dataContactName);
    console.log("dataSourceName", dataSourceName);
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);
    console.log("dataProperty", dataProperty);
    console.log("dataPropertyName", dataPropertyName);

    const data = {
      contact_id: req.body.contact_id,
      property_id: req.body.property_id,
      looking_for: req.body.looking_for,
      property_type: req.body.property_type,
      city: req.body.city,
      lead_source: req.body.lead_source,
      lead_group: req.body.lead_group,
      segment: req.body.segment,
      lead_priority: req.body.lead_priority,
      fee_oppurtunity: req.body.fee_oppurtunity,
      lead_status: req.body.lead_status,
      assign_to: req.body.assign_to,
      sales_manager: req.body.sales_manager,
      }
      let LeadId = req.params.id

    const num = await db2['leads'].update(data, {
      where: { id: id },
    });
    if (num == 1) {
          // Source
          if(req.body.lead_source) {
            let thisQuery456 = ` select l.lead_source as l_source, so.option_value as l_source_name
            from lz_leads as l
            left join lz_masters as so on (so.id = l.lead_source)
            where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.lead_source = ${req.body.lead_source}
            `
            const dataSO = await db2.sequelize.query(thisQuery456);
            const dataSO1 = dataSO[0][0]?.l_source
            const dataSO2 = dataSO[0][0]?.l_source_name
            console.log("dataSO1", dataSO1);
            console.log("dataSO2", dataSO2);
  
          if(dataSource?.toString() !== req.body.lead_source?.toString()) {
            const LeadSourceLog = await db2['logs'].create({
              org_id: org_id,
              module_id: LeadId,
              module_name: "2",
              note: 'Lead source : ' + dataSourceName + ' to '+ dataSO2,
              user_id: created_by.id
            })
            console.log("Lead Source",LeadSourceLog.dataValues.note);
          }
        }
          // Lead Status
          if(req.body.lead_status) {
            let thisQuery456 = ` select l.lead_status as l_status, cs.option_value as l_status_name
            from lz_leads as l
            left join lz_masters as cs on (cs.id = l.lead_status)
            where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.lead_status = ${req.body.lead_status}
            `
            const dataCS = await db2.sequelize.query(thisQuery456);
            const dataCS1 = dataCS[0][0]?.l_status
            const dataCS2 = dataCS[0][0]?.l_status_name
            console.log("dataCS1", dataCS1);
            console.log("dataCS2", dataCS2);
  
          if(dataStatus?.toString() !== req.body.lead_status?.toString()) {
            const LeadStatusLog = await db2['logs'].create({
              org_id: org_id,
              module_id: LeadId,
              module_name: "2",
              note: 'Lead status : ' + dataStatusName + ' to '+ dataCS2,
              user_id: created_by.id
            })
            console.log("Lead Status",LeadStatusLog.dataValues.note);
          }
        }
        // Contact Name
          if(req.body.contact_id) {
            let thisQuery456 = ` select l.contact_id as l_contact_id, c.first_name as l_contact_name
            from lz_leads as l
            left join lz_contacts as c on (c.id = l.contact_id)
            where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.contact_id = ${req.body.contact_id}
            `
            const dataC = await db2.sequelize.query(thisQuery456);
            const dataC1 = dataC[0][0]?.l_contact_id
            const dataC2 = dataC[0][0]?.l_contact_name
            console.log("dataC1", dataC1);
            console.log("dataC2", dataC2);
  
          if(dataContactID?.toString() !== req.body.contact_id?.toString()) {
            const LeadContactLog = await db2['logs'].create({
              org_id: org_id,
              module_id: LeadId,
              module_name: "2",
              note: 'Lead contact name : ' + dataContactName + ' to '+ dataC2,
              user_id: created_by.id
            })
            console.log("Lead Contact name",LeadContactLog.dataValues.note);
          }
        }
        // Property Name
        if(req.body.property_id) {
          let thisQueryPro = ` select l.property_id as l_property_id, pa1.name_of_building as l_property_name
          from lz_leads as l
          left join lz_properties as p on (p.id = l.property_id)
          left join lz_property_addresses as pa1 on (p.id = pa1.property_id)
          where ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} and l.property_id = ${req.body.property_id}
          `
          const dataPro = await db2.sequelize.query(thisQueryPro);
          const dataPro1 = dataPro[0][0]?.l_property_id
          const dataPro2 = dataPro[0][0]?.l_property_name
          console.log("dataPro1", dataPro1);
          console.log("dataPro2", dataPro2);

        if(dataProperty?.toString() !== req.body.property_id?.toString()) {
          const contactPropertyLog = await db2['logs'].create({
            org_id: org_id,
            module_id: LeadId,
            module_name: "2",
            note: 'Lead propery name : ' + dataPropertyName + ' to '+ dataPro2,
            user_id: created_by.id
          })
          console.log("Lead Property",contactPropertyLog.dataValues.note);
        }
      }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateLeadRequirement = async (req, res) => {
  try {
    const id = req.params.lead_id;

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const data = {
      requirement_location: req.body.requirement_location,
      budget_min: req.body.budget_min,
      budget_max: req.body.budget_max,
      money_term_min: req.body.money_term_min,
      money_term_max: req.body.money_term_max,
      no_of_bedrooms_min: req.body.no_of_bedrooms_min,
      no_of_bedrooms_max: req.body.no_of_bedrooms_max,
      no_of_bathrooms_min: req.body.no_of_bathrooms_min,
      no_of_bathrooms_max: req.body.no_of_bathrooms_max,
      built_up_area_min: req.body.built_up_area_min,
      built_up_area_max: req.body.built_up_area_max,
      plot_area_min: req.body.plot_area_min,
      plot_area_max: req.body.plot_area_max,
      possession_status: req.body.possession_status,
      age_of_property: req.body.age_of_property,
      vasthu_compliant: req.body.vasthu_compliant,
      property_facing: req.body.property_facing,
      furnishing: req.body.furnishing,
      car_park_min: req.body.car_park_min,
      car_park_max: req.body.car_park_max,
      timeline_for_closure_min: req.body.timeline_for_closure_min,
      timeline_for_closure_max: req.body.timeline_for_closure_max,
      amenities: req.body.amenities,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      zipcode: req.body.zipcode,
      locality: req.body.locality,
      }

    const num = await db2['leadRequirement'].update(data, {
      where: { lead_id: id },
    });
    if (num == 1) {
        const leadLogs = await db2['logs'].create({
          org_id: org_id,
          module_id: id,
          module_name: "2",
          note: "Lead requirement updated at",
          user_id: created_by.id
        })
        // console.log("leadLogs", leadLogs);

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteLead = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const role = req.user.id
  const role_id = role.designation
  console.log('role_id', role_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_leads SET status = 0 `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and ${role_id == 1 ? `l.status IN (1,2) ` : `l.status = 1`} `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.updateLeadStatus = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const id = req.params.id;

    let thisQuery = ` select l.lead_status as lead_status, cs.option_value as lead_status_name
    from lz_leads as l
    left join lz_masters as cs on (cs.id = l.lead_status)
    where l.status = 1 and l.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery);
    const dataStatus = data123[0][0]?.lead_status
    const dataStatusName = data123[0][0]?.lead_status_name
    console.log("dataStatus", dataStatus);
    console.log("dataStatusName", dataStatusName);

    const data = {
      lead_status: req.body.lead_status,
    }

    const leadStatus = req.body.lead_status
    console.log("leadStatusssssss", leadStatus);

    const num = await db2['leads'].update(data, {
      where: { id: id },
    });
    if (num == 1) {

      let thisQuery = ` select option_value from lz_masters where option_type = "lead_status" and id = ${leadStatus} `
      const data = await db2.sequelize.query(thisQuery);
      const dataValue = data[0][0]?.option_value
      console.log("dataaaaa", dataValue);

      let thisQuery1 = `SELECT l.*, c.email as email
      FROM lz_leads as l 
      LEFT JOIN lz_contacts as c on (c.id = l.contact_id)
      WHERE l.status = 1 and l.id = ${id} `
      const data1 = await db2.sequelize.query(thisQuery1);
      const dataV = data1[0][0]
      console.log("LeadList", dataV);

        if(leadStatus == 62) {
          const LeadData = {
            status: 2,
          }
          const leadDrop = await db2['leads'].update(LeadData,{
            where: { id: id },
          });
        }

      if(leadStatus == 61) {
        const data = await db2['transaction'].create({
          org_id: org_id,
          lead_id: id,
          booking_date: req.body.booking_date,
          country: req.body.country,
          state: req.body.state,
          city: req.body.city,
          lead_source: req.body.lead_source,
          team_leader: req.body.team_leader,
          shared_with: req.body.shared_with,
          closed_by: req.body.closed_by,
          transaction_status: 338 ?? req.body.transaction_status,
          developer_name: req.body.developer_name,
          project_name: dataV?.property_id,
          client_name: dataV?.contact_id,
          contact_number: req.body.contact_number,
          email_id: dataV?.email,
          dob: req.body.dob,
          anniversary_date: req.body.anniversary_date,
          discount_amount: req.body.discount_amount,
          block_no: req.body.block_no,
          unit_no: req.body.unit_no,
          floor_no: req.body.floor_no,
          bhk_type: req.body.bhk_type,
          unit_size: req.body.unit_size,
          plot_size: req.body.plot_size,
          frc: req.body.frc,
          plc: req.body.plc,
          basic_price: req.body.basic_price ?? 0,
          car_parking_cost: req.body.basic_price,
          pan: req.body.pan,
          agreement_value: req.body.agreement_value  ?? 0,
          brokerage_percentage	: req.body.brokerage_percentage	,
          brokerage_value: req.body.brokerage_value,
          aop_percentage: req.body.aop_percentage,
          discount_value: req.body.discount_value,
          discount_paid_status: req.body.discount_paid_status,
          tds_value: req.body.tds_value,
          revenue: req.body.revenue,
          created_by: created_by.id
        });
        
        const TransactionID = data?.dataValues.id
        const data1 = await db2['transactionBrokerageDetails'].create({
            transaction_id: TransactionID,
        })
        const data2 = await db2['transactionInvoicingDetails'].create({
            transaction_id: TransactionID,
        })
        const TransactionLogs = await db2['logs'].create({
            org_id: org_id,
            module_id: TransactionID,
            module_name: "5",
            note: "Transaction created at",
            user_id: created_by.id
        })

        const LeadData = {
          status: 0,
        }
        const leadDelete = await db2['leads'].update(LeadData,{
          where: { id: id },
        });
      } 
      let LeadId = req.params.id

      // Lead Status
      if(req.body.lead_status) {
        let thisQuery456 = ` select l.lead_status as l_status, cs.option_value as l_status_name
        from lz_leads as l
        left join lz_masters as cs on (cs.id = l.lead_status)
        where l.status = 1 and l.lead_status = ${req.body.lead_status}
        `
        const dataCS = await db2.sequelize.query(thisQuery456);
        const dataCS1 = dataCS[0][0]?.l_status
        const dataCS2 = dataCS[0][0]?.l_status_name
        console.log("dataCS1", dataCS1);
        console.log("dataCS2", dataCS2);

      if(dataStatus.toString() !== req.body.lead_status.toString()) {
        const LeadStatusLog = await db2['logs'].create({
          org_id: org_id,
          module_id: LeadId,
          module_name: "2",
          note: 'Lead status : ' + dataStatusName + ' to '+ dataCS2,
          user_id: created_by.id
        })
        console.log("Lead Status",LeadStatusLog.dataValues.note);
      }
    }

      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.saveLeadFilter = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let thisQuery1 = ` SELECT id FROM lz_lead_filter `
    const data1 = await db2.sequelize.query(thisQuery1);
    const totalLead = data1[0].length
    console.log("totalLead", totalLead);
    
    if (totalLead < 5) {

    const data = await db2['leadFilter'].create({
      property_id: req.body.property_id,
      looking_for: req.body.looking_for,
      property_type: req.body.property_type,
      requirement_location: req.body.requirement_location,
      lead_source: req.body.lead_source,
      lead_priority: req.body.lead_priority,
      lead_group: req.body.lead_group,
      fee_oppurtunity: req.body.fee_oppurtunity,
      lead_status: req.body.lead_status,
      assign_to: req.body.assign_to,
      no_of_bedrooms_min: req.body.no_of_bedrooms_min,
      no_of_bedrooms_max: req.body.no_of_bedrooms_max,
      no_of_bathrooms_min: req.body.no_of_bathrooms_min,
      no_of_bathrooms_max: req.body.no_of_bathrooms_max,
      budget_min: req.body.budget_min,
      budget_max: req.body.budget_max	,
      built_up_area_min: req.body.built_up_area_min,
      built_up_area_max: req.body.built_up_area_max,
      plot_area_min: req.body.plot_area_min,
      plot_area_max: req.body.plot_area_max,
      car_park_min: req.body.car_park_min,
      car_park_max: req.body.car_park_max,
      timeline_for_closure_min: req.body.timeline_for_closure_min,
      timeline_for_closure_max: req.body.timeline_for_closure_max,
      age_of_property: req.body.age_of_property,
      vasthu_compliant: req.body.vasthu_compliant,
      property_facing: req.body.property_facing,
      furnishing: req.body.furnishing,
      possession_status: req.body.possession_status,
      filter_name: req.body.filter_name,
      created_date: req.body.created_date,
      updated_date: req.body.updated_date,
      amenities: req.body.amenities,
      created_by: created_by.id
    });
    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data
    });
  }
  else {
    res.status(200).send({
      status: 400,
      message: 'Only 5 filters can add',
      output: []
    });
  }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getLeadFilter = async (req, res) => {
  try {
    
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);
  
  let thisQuery = `select l.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''),'-',us.id)) as assign_to_name, CONVERT(l.assign_to USING utf8) as assign_to, pa.name_of_building as property_name,  CONCAT(us2.first_name,' ', IFNULL(us2.last_name, '')) as created_by_name,
  l.budget_min as budget_min, l.budget_max as budget_max, l.no_of_bedrooms_min as no_of_bedrooms_min, l.no_of_bedrooms_max as no_of_bedrooms_max, l.no_of_bathrooms_min as no_of_bathrooms_min, l.no_of_bathrooms_max as no_of_bathrooms_max, l.plot_area_min as plot_area_min, l.plot_area_max as plot_area_max, 
  lrn.option_value as looking_for_name, 
  pt.option_value as property_type_name, 
  ls.option_value as lead_source_name,
  lg.option_value as lead_group_name,
  lp.option_value as lead_priority_name,
  lss.option_value as lead_status_name,
  aop.option_value as age_of_property_name,
  vc.option_value as vasthu_compliant_name,
  GROUP_CONCAT(distinct CONCAT(amen.option_value)) as amenities_name,
  GROUP_CONCAT(distinct CONCAT(ps.option_value)) as possession_status_name,
  GROUP_CONCAT(distinct CONCAT(fur.option_value)) as furnishing_name
  from lz_lead_filter as l
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = l.property_id) 
  LEFT JOIN lz_user as us on FIND_IN_SET(us.id,l.assign_to) > 0 
  LEFT JOIN lz_user as us2 on FIND_IN_SET(us2.id,l.created_by) > 0 
  LEFT JOIN lz_masters as lrn on (lrn.id = l.looking_for) 
  LEFT JOIN lz_masters as pt on (pt.id = l.property_type)
  LEFT JOIN lz_masters as ls on (ls.id = l.lead_source)
  LEFT JOIN lz_masters as lg on (lg.id = l.lead_group)
  LEFT JOIN lz_masters as lp on (lp.id = l.lead_priority)
  LEFT JOIN lz_masters as lss on (lss.id = l.lead_status)
  LEFT JOIN lz_masters as aop on (aop.id = l.age_of_property)
  LEFT JOIN lz_masters as vc on (vc.id = l.vasthu_compliant)
  LEFT JOIN lz_masters as amen on FIND_IN_SET(amen.id,l.amenities) > 0
  LEFT JOIN lz_masters as fur on FIND_IN_SET(amen.id,l.furnishing) > 0
  LEFT JOIN lz_masters as ps on FIND_IN_SET(amen.id,l.possession_status) > 0
  where l.status = 1 group by l.id
  `;

  const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status:200,
      message:'Success',
      output: data[0],
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteLeadFilter = async (req, res) => {
  try {
    const id = req.params.id;
    const num = await db2['leadFilter'].destroy({
      where: { id: id },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getLeadAutoMatch = async (req, res) => {
  try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id

  let thisQuery = `select pr.id,
  pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max,
  pr.furnishing as furnishing, pr.project_stage as project_stage, pr.project_unit_type as project_unit_type, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', '') AS unit_type, 
  REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') AS price_min, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') AS price_max,
  GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name,GROUP_CONCAT(distinct CONCAT(ps.option_value),'-',ps.id) as project_stage_name, pa.locality as locality
  from lz_property_residentials as pr 
  LEFT JOIN lz_property_addresses as pa on (pa.property_id = pr.property_id)
  LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,pr.furnishing) > 0
  LEFT JOIN lz_masters as ps on FIND_IN_SET(ps.id,pr.project_stage) > 0
  where pr.created_at IS NOT NULL
  `
  let thisQuery1 = ` SELECT lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.furnishing as furnishing, lr.locality as locality, lr.possession_status as possession_status, lr.no_of_bedrooms_min as no_of_bedrooms_min, lr.no_of_bedrooms_max as no_of_bedrooms_max ,lr.budget_min as budget_min, lr.budget_max as budget_max
  FROM lz_lead_requirements as lr 
  where lead_id = ${id} `
  
  const data1 = await db2.sequelize.query(thisQuery1);

  const filters = req.query;

    if (data1[0][0].locality == 0 || data1[0][0].locality) {
      thisQuery += " and pa.locality = " + `'${data1[0][0].locality}' `
    }
    if (data1[0][0].furnishing == 0 || data1[0][0].furnishing) {
      var a = data1[0][0].furnishing;
      var b = a.replace(/[,]/g, ",");
      thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
    }
    if (data1[0][0].possession_status == 0 || data1[0][0].possession_status) {
      var a = data1[0][0].possession_status;
      var b = a.replace(/[,]/g, ",");
      thisQuery += ` and CONCAT(',', pr.project_stage, ',') REGEXP ',(${a}),' `
    }
    if ((data1[0][0].plot_area_min == 0 && data1[0][0].plot_area_max == 0) || (data1[0][0].plot_area_min &&  data1[0][0].plot_area_max)) {
      thisQuery += " and pr.plot_area_min <= " + `'${data1[0][0].plot_area_min}' ` + " and pr.plot_area_max >= " + `'${data1[0][0].plot_area_max}' `
    }
    if ((data1[0][0].built_up_area_min == 0 && data1[0][0].built_up_area_max == 0) || (data1[0][0].built_up_area_min &&  data1[0][0].built_up_area_max)) {
      thisQuery += " and pr.built_up_area_min <= " + `'${data1[0][0].built_up_area_min}' ` + " and pr.built_up_area_max >= " + `'${data1[0][0].built_up_area_max}' `
    }

    if (data1[0][0].no_of_bedrooms_min == 0 || data1[0][0].no_of_bedrooms_min) {
      var a = data1[0][0].no_of_bedrooms_min;
      // var b = a.replace(/[,]/g, ",");
      thisQuery += ` and CONCAT(',', REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', ''), ',') REGEXP ',(${a}),' `
    }
    if (data1[0][0].no_of_bedrooms_max == 0 || data1[0][0].no_of_bedrooms_max) {
      var a = data1[0][0].no_of_bedrooms_max;
      // var b = a.replace(/[,]/g, ",");
      thisQuery += ` and CONCAT(',', REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].unit_type'), '\"', ''), ',') REGEXP ',(${a}),' `
    }

    if ((data1[0][0].budget_min == 0 && data1[0][0].budget_max == 0) || (data1[0][0].budget_min &&  data1[0][0].budget_max)) {
      thisQuery += " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') <= " + `'${data1[0][0].budget_min}' ` + " and REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') >= " + `'${data1[0][0].budget_max}' `
    }

    thisQuery += ' group by pr.id '
    thisQuery += ' order by pr.id desc '

    // REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_min'), '\"', '') AS price_min, REPLACE(JSON_EXTRACT(pr.project_unit_type,'$[0].price_max'), '\"', '') AS price_max,

    const data = await db2.sequelize.query(thisQuery);

    console.log("propertyResidentials", data[0]);
    console.log("leadRequirements", data1[0][0]);

      res.status(200).send({
        status:200,
        message:'Success',
        output: data[0],
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getLeadDuplicate = async (req, res) => {
  try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id
  const propertyID = req.params.property_id

  let x = `(select l.contact_id from lz_leads as l left join lz_properties as p on (p.id = l.property_id) where l.id = ${id} and c.property_id = ${propertyID}) `
  let thisQuery = `SELECT * FROM lz_contacts as c 
  where c.status = 1 and c.mobile in (SELECT mobile FROM lz_contacts where id = ${x}) and c.id != ${x} `

  const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output: data[0],
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getLeadTask = async (req, res) => {
  try {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const id = req.params.id

  // let x = `(select contact_id from lz_leads where id = ${id})`
  let thisQuery = `select t.*, CONVERT(t.assign_to USING utf8) as assign_to, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as assign_to_name,CONCAT(us1.first_name,' ', IFNULL(us1.last_name, '')) as created_by_name, CONCAT(c.first_name,' ', IFNULL(c.last_name, '')) as contact_name, c.email as email, c.mobile as mobile, c.mobile as mobile, c.profile_image as contact_profile_image, c.profile_image_original_name as contact_profile_image_original_name, pa.name_of_building as property_name, tt.option_value as task_type_name, pri.option_value as priority_name, ts.option_value as task_status_name
  FROM lz_tasks as t `
  thisQuery += "LEFT JOIN lz_contacts as c on (c.id = t.contact) "
  thisQuery += "LEFT JOIN lz_leads as le on (le.contact_id = t.contact) "
  thisQuery += "LEFT JOIN lz_property_addresses as pa on (pa.property_id = t.project) "
  thisQuery += "LEFT JOIN lz_masters as tt on (t.task_type = tt.id) "
  thisQuery += "LEFT JOIN lz_masters as pri on (t.priority = pri.id) "
  thisQuery += "LEFT JOIN lz_masters as ts on (t.task_status = ts.id) "
  thisQuery += "LEFT JOIN lz_user as us on FIND_IN_SET(us.id,t.assign_to)>0 "
  thisQuery += "LEFT JOIN lz_user as us1 on (us1.id = t.created_by) "
  thisQuery += ` where t.status = 1 `
  thisQuery += ` and t.contact = ${id} group by t.id `

  const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output: data[0],
      });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.bulkLeadReAssign = async (req, res) => {
  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const created_by = req.user.id
  console.log('created_by', created_by.id);

    try {
      let x = req.params.id
      console.log("id111", x);

      let thisQuery  = ` UPDATE lz_leads SET assign_to = '${req.body.assign_to}' `;
          thisQuery += " WHERE id IN (" + x + ") "
          thisQuery += ` and status = 1 `;

      const data = await db2.sequelize.query(thisQuery);

      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });

    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};

exports.importLead = (async (req, res) => {
  // const query = util.promisify;

  readXlsxFile('./uploads/' + req.file.filename).then(async (rows) => {

    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);
  
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const role = req.user.id
    const role_id = role.designation
    console.log('role_id', role_id);

    rows.shift();
    rows.map(async (row, i) => {
        // const company_nameIdFetch = await db2.sequelize.query(`select id from lz_contacts where company_name ='${row[3]}' limit 1`);
        // const company_nameId = company_nameIdFetch[0][0] ? company_nameIdFetch[0][0]["id"] : 0

        // Contacts ID
        const contact_IdFetch = await db2.sequelize.query(`select id from lz_contacts where first_name ='${row[0]}' limit 1`);
        const contact_Id = contact_IdFetch[0][0] ? contact_IdFetch[0][0]["id"] : 0
        console.log("contact_IdFetch", contact_IdFetch[0][0]);
        console.log("contact_Id", contact_Id);
        // Property ID
        const property_IdFetch = await db2.sequelize.query(`select property_id from lz_property_addresses where name_of_building ='${row[1]}' limit 1`);
        const property_Id = property_IdFetch[0][0] ? property_IdFetch[0][0]["property_id"] : 0
        console.log("property_IdFetch", property_IdFetch[0][0]);
        console.log("property_Id", property_Id);
        // Looking For
        // var a = `${row[2]}`;
        // console.log("aaaaaaaaaaaa", a);
        // var b = a.replace(/[,]/g, ",");
        // console.log("bbbbbbbbbbbbbb", b);

        // var c = 'Buy, Sell'
        // var d = c.split(",");
        // console.log("dddddddddddddd", d);

        // Looking For
        const looking_for_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="looking_for" and option_value ='${row[2]}' limit 1`);
        const looking_forId = looking_for_IdFetch[0][0] ? looking_for_IdFetch[0][0]["id"] : 0
        console.log("looking_for_IdFetch", looking_for_IdFetch[0]);
        console.log("looking_forId", looking_forId);
        // Property Type
        const property_type_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="property_type" and option_value ='${row[3]}' limit 1`);
        const property_typeId = property_type_IdFetch[0][0] ? property_type_IdFetch[0][0]["id"] : 0
        // Lead Source
        const lead_source_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="source" and option_value ='${row[4]}' limit 1`);
        const lead_sourceId = lead_source_IdFetch[0][0] ? lead_source_IdFetch[0][0]["id"] : 0
        // Lead Group
        const lead_group_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="lead_group" and option_value ='${row[5]}' limit 1`);
        const lead_groupId = lead_group_IdFetch[0][0] ? lead_group_IdFetch[0][0]["id"] : 0
        // Segment
        const segment_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="segment" and option_value ='${row[6]}' limit 1`);
        const segmentId = segment_IdFetch[0][0] ? segment_IdFetch[0][0]["id"] : 0
        // Priority
        const priority_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="lead_priority" and option_value ='${row[7]}' limit 1`);
        const priorityId = priority_IdFetch[0][0] ? priority_IdFetch[0][0]["id"] : 0
        // Fee Oppurtunity
        // const fee_oppurtunity_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="fee_oppurtunity" and option_value ='${row[8]}' limit 1`);
        // const fee_oppurtunityId = fee_oppurtunity_IdFetch[0][0] ? fee_oppurtunity_IdFetch[0][0]["id"] : 0
        // Lead Status
        const lead_status_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="lead_status" and option_value ='${row[9]}' limit 1`);
        const lead_statusId = lead_status_IdFetch[0][0] ? lead_status_IdFetch[0][0]["id"] : 52
        console.log("lead_status_IdFetch", lead_status_IdFetch[0][0]);
        console.log("lead_statusId", lead_statusId);

        // Project facing
        const project_facing_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="property_facing" and option_value ='${row[27]}' limit 1`);
        const project_facingId = project_facing_IdFetch[0][0] ? project_facing_IdFetch[0][0]["id"] : 0
        console.log("project_facing_IdFetch", project_facing_IdFetch[0][0]);
        console.log("project_facingId", project_facingId);

        // Age Of Property
        const age_of_property_IdFetch = await db2.sequelize.query(`select id from lz_masters where option_type ="age_of_property" and option_value ='${row[25]}' limit 1`);
        const age_of_propertyId = age_of_property_IdFetch[0][0] ? age_of_property_IdFetch[0][0]["id"] : 0
        console.log("age_of_property_IdFetch", age_of_property_IdFetch[0][0]);
        console.log("age_of_propertyId", age_of_propertyId);

        // country
        const countryIdFetch = await db.sequelize.query(`select id from lz_country where name ='${row[34]}' limit 1`);
        const countryId = countryIdFetch[0][0] ? countryIdFetch[0][0]["id"] : 0
        // city
        const cityIdFetch = await db.sequelize.query(`select id from lz_city where name ='${row[36]}' limit 1`);
        const cityId = cityIdFetch[0][0] ? cityIdFetch[0][0]["id"] : 0
        // state
        const stateIdFetch = await db.sequelize.query(`select id from lz_state where name ='${row[35]}' limit 1`);
        const stateId = stateIdFetch[0][0] ? stateIdFetch[0][0]["id"] : 0

        // Multiple Select
        // Assign To
        let userValue = `${row[10]}`;
        let userValue1 = userValue.split(',').map(item => `'${item}'`).join(',');

        const assignIdFetch = await db2.sequelize.query("select id from lz_user where first_name IN (" + userValue1 + ") group by id " );
        const assignId = assignIdFetch[0][0] ? assignIdFetch[0].map(params => params.id).join(',') : 0
        console.log("assignIdFetch", assignIdFetch[0]);
        console.log("assignId", assignId);

        // Amenities
        let amenitiesValue = `${row[33]}`;
        let amenitiesValue1 = amenitiesValue.split(',').map(item => `'${item}'`).join(',');

        const amenities_IdFetch = await db2.sequelize.query("select id from lz_masters where option_type = 'amenities' and option_value IN (" + amenitiesValue1 + ") group by id " );
        const amenitiesId = amenities_IdFetch[0][0] ? amenities_IdFetch[0].map(params => params.id).join(',') : 0
        console.log("amenities_IdFetch", amenities_IdFetch[0]);
        console.log("amenitiesId", amenitiesId);

        // Furnishing        
        let furnishing_Value = `${row[28]}`;
        let furnishing_Value1 = furnishing_Value.split(',').map(item => `'${item}'`).join(',');

        const furnishing_IdFetch = await db2.sequelize.query("select id from lz_masters where option_type = 'furnishing_status' and option_value IN (" + furnishing_Value1 + ") group by id " );
        const furnishingId = furnishing_IdFetch[0][0] ? furnishing_IdFetch[0].map(params => params.id).join(',') : 0
        console.log("furnishing_IdFetch", furnishing_IdFetch[0]);
        console.log("furnishingId", furnishingId);

        // possession_status
        let possession_status_value = `${row[24]}`;
        let possession_status_value1 = possession_status_value.split(',').map(item => `'${item}'`).join(',');

        const possession_status_IdFetch = await db2.sequelize.query("select id from lz_masters where option_type = 'possession_status' and option_value IN (" + possession_status_value1 + ") group by id " );
        const possession_statusId = possession_status_IdFetch[0][0] ? possession_status_IdFetch[0].map(params => params.id).join(',') : 0
        console.log("possession_status_IdFetch", possession_status_IdFetch[0]);
        console.log("possession_statusId", possession_statusId);

        // Sales Manager
        let sales_manager_value = `${row[11]}`;
        let sales_manager_value1 = sales_manager_value.split(',').map(item => `'${item}'`).join(',');

        const sales_managerFetch = await db2.sequelize.query("select id from lz_user where first_name IN (" + sales_manager_value1 + ") group by id " );
        const sales_managerId = sales_managerFetch[0][0] ? sales_managerFetch[0].map(params => params.id).join(',') : 0
        console.log("sales_managerFetch", sales_managerFetch[0]);
        console.log("sales_managerId", sales_managerId);
        
        const data = await db2['leads'].create({
          contact_id: contact_Id,
          property_id: property_Id,
          looking_for: looking_forId,
          property_type: property_typeId,
          lead_source: lead_sourceId,
          lead_group: lead_groupId,
          segment: segmentId,
          lead_priority: priorityId,
          fee_oppurtunity: row[8],
          lead_status:  lead_statusId,
          assign_to: assignId,
          sales_manager: sales_managerId,
          created_by: created_by,
        })

        let leadId = data?.dataValues.id
        console.log('leadID', leadId);

        const data3 = await db2['leadRequirement'].create({
          lead_id: leadId,
          // requirement_location: row[20],
          budget_min: row[12] ?? 0,
          budget_max: row[13] ?? 0,
          money_term_min: row[14] ?? 0,
          money_term_max: row[15] ?? 0,
          no_of_bedrooms_min: row[16] ?? 0,
          no_of_bedrooms_max: row[17] ?? 0,
          no_of_bathrooms_min: row[18] ?? 0,
          no_of_bathrooms_max: row[19] ?? 0,
          built_up_area_min: row[20] ?? 0,
          built_up_area_max: row[21] ?? 0,
          plot_area_min: row[22] ?? 0,
          plot_area_max: row[23] ?? 0,
          possession_status: possession_statusId,
          age_of_property: age_of_propertyId,
          vasthu_compliant: row[26] ?? 0,
          property_facing: project_facingId ?? 0,
          furnishing: furnishingId ?? 0,
          car_park_min: row[29] ?? 0,
          car_park_max: row[30] ?? 0,
          timeline_for_closure_min: row[31] ?? 0,
          timeline_for_closure_max: row[32] ?? 0,
          amenities: amenitiesId,
          country: countryId,
          state: stateId,
          city: cityId,
          zipcode: row[37] ?? 0,
          locality: row[38] ?? 0,
        })

        // const data4 = await db2['logs'].create({
        //   org_id: org_id,
        //   user_id: created_by,
        //   module_id: contactId,
        //   module_name: "1",
        //   note: " contact created at"
        // })
    });

    // res.send("Leads Saved Succesfully");
      res.status(200).send({
        status: 200,
        message: 'Bulk Leads Successfully',
      });
  });
});

exports.sendMailLead = (async (req, res) => {
  try {
    if (!req.body) {
      res.status(400).send({
        message: "Lead Cannot be Empty"
      });
    }
    const leadData = ({
      lead_id: req.body.lead_id || null,
      from: 'listez@admin.com' || null,
      to: req.body.to || null,
      subject: req.body.subject || null,
      message: req.body.message || null,
    });
    let message = {
      from: leadData.from,
      to: leadData.to,
      subject: leadData.subject,
      html:
        "<h3> message: </h3>" +
        leadData.message + "",
    };
    // mailer.sendMail(message);
    console.log('message',message);

    res.status(200).send({
      status: 200,
      message:'mail send sucessfully',
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
});

// exports.getLeadAutoMatch = async (req, res) => {
//   try {
//   const organ_id = req.user.id
//   const org_id = organ_id.org_id
//   console.log('organ_id', org_id);

//   const id = req.params.id

//   let thisQuery = `select pr.id,
//   pr.plot_area_min as plot_area_min, pr.plot_area_max as plot_area_max, pr.built_up_area_min as built_up_area_min, pr.built_up_area_max as built_up_area_max,
//   pr.furnishing as furnishing,
//   GROUP_CONCAT(distinct CONCAT(fur.option_value),'-',fur.id) as furnishing_name, pa.locality as locality
//   from lz_property_residentials as pr 
//   LEFT JOIN lz_property_addresses as pa on (pa.property_id = pr.property_id)
//   LEFT JOIN lz_masters as fur on FIND_IN_SET(fur.id,pr.furnishing) > 0
//   where pr.created_at IS NOT NULL
//   `

//   let thisQuery1 = ` SELECT lr.plot_area_min as plot_area_min, lr.plot_area_max as plot_area_max, lr.built_up_area_min as built_up_area_min, lr.built_up_area_max as built_up_area_max, lr.furnishing as furnishing, lr.locality as locality
//   FROM lz_lead_requirements as lr 
//   where id = ${id} `
  
//   const data1 = await db2.sequelize.query(thisQuery1);

//   const filters = req.query;

//     // if (filters.furnishing) {
//     //   var a = filters.furnishing;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
//     // }
//     // if (filters.project_stage) {
//     //   var a = filters.project_stage;
//     //   var b = a.replace(/[,]/g, ",");
//     //   thisQuery += ` and CONCAT(',', pr.project_stage, ',') REGEXP ',(${a}),' `
//     // }

//     // if (data1[0][0].locality =="" || data1[0][0].locality) {
//     //   thisQuery += " and pa.locality = " + `'${data1[0][0].locality}' `
//     // }

//     if (data1[0][0].furnishing =="" || data1[0][0].furnishing) {
//       var a = data1[0][0].furnishing;
//       var b = a.replace(/[,]/g, ",");
//       thisQuery += ` and CONCAT(',', pr.furnishing, ',') REGEXP ',(${a}),' `
//     }
   
//     // if (data1[0][0].plot_area_min =="" || data1[0][0].plot_area_min) {
//     //   thisQuery += " and pr.plot_area_min >= " + `'${data1[0][0].plot_area_min}' `
//     // }
//     // if (data1[0][0].plot_area_max =="" || data1[0][0].plot_area_max) {
//     //   thisQuery += " and pr.plot_area_max <= " + `'${data1[0][0].plot_area_max}' `
//     // }

//     if ((data1[0][0].plot_area_min =="" && data1[0][0].plot_area_max =="") || (data1[0][0].plot_area_min &&  data1[0][0].plot_area_max)) {
//       thisQuery += " and pr.plot_area_min < " + `'${data1[0][0].plot_area_min}' ` + " and pr.plot_area_max >= " + `'${data1[0][0].plot_area_max}' `
//     }
//     // if ((data1[0][0].built_up_area_min =="" && data1[0][0].built_up_area_max =="") || (data1[0][0].built_up_area_min && data1[0][0].built_up_area_max)) {
//     //   thisQuery += " and pr.built_up_area_min < " + `'${data1[0][0].built_up_area_min}' ` + " and pr.built_up_area_max >= " + `'${data1[0][0].built_up_area_max}' `
//     // }

//     // if (data1[0][0].built_up_area_min =="" || data1[0][0].built_up_area_min) {
//     //   thisQuery += " and pr.built_up_area_min between " + `'${data1[0][0].built_up_area_min}' `
//     // }
//     // if (data1[0][0].built_up_area_max =="" || data1[0][0].built_up_area_max) {
//     //   thisQuery += " and pr.built_up_area_max >= " + `'${data1[0][0].built_up_area_max}' `
//     // }

//     // if ((data1[0][0].plot_area_min =="" || data1[0][0].plot_area_min) || (data1[0][0].plot_area_min && data1[0][0].plot_area_max)) {
//     //   thisQuery += " and pr.plot_area_min and pr.plot_area_max between " + `${data1[0][0].plot_area_min} ` + `and ${data1[0][0].plot_area_max} `
//     // }
//     // if (data1[0][0].built_up_area_max =="" || data1[0][0].built_up_area_max) {
//     //   thisQuery += " and pr.built_up_area_max = " + `${data1[0][0].built_up_area_max} `
//     // }

//     // if (filters.built_up_area_min && filters.built_up_area_max) {
//     //   thisQuery += " and pr.built_up_area_min between " + `${filters.built_up_area_min}` + ` and ${filters.built_up_area_max} `
//     // }

//     // if (data1[0][0].plot_area_max =="" || data1[0][0].plot_area_max) {
//     //   thisQuery += " and pr.plot_area_max = " + `${data1[0][0].plot_area_max} `
//     // }
//     thisQuery += ' group by pr.id '
//     thisQuery += ' order by pr.id desc '

//     const data = await db2.sequelize.query(thisQuery);

//     console.log("propertyResidentials", data[0]);
//     console.log("leadRequirements", data1[0][0]);


//     if(data[0].length == 0) {
//       res.status(200).send({
//         status:200,
//         message:'Empty',
//         output:[],
//       });
//     } else {
//       res.status(200).send({
//         status:200,
//         message:'Success',
//         output: data[0],
//       });
//     }

//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };