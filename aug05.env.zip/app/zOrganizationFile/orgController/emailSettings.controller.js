const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

exports.createEmailSettings = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    const data = await db2['emailSettings'].create({
      org_id: org_id,
      module_id: req.body.module_id,
      active_status: req.body.active_status,
      created_by: created_by.id
    });
    const dataID = data?.dataValues.id
    console.log('dataID', dataID);

    res.status(200).send({
      status:200,
      message:'Success',
      output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.getEmailSettings = async (req, res) => {
    try {
      
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);
    
    let thisQuery = ` SELECT em.*
    FROM lz_email_settings as em
    WHERE em.status
    GROUP BY em.id
    `
    const data = await db2.sequelize.query(thisQuery);
     
      res.status(200).send({
        status:200,
        message:'Success',
        output:data[0]
      });
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};
exports.editEmailSettings = async (req, res) => {
  try {
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    const id = req.params.id;
    const data = await db2['emailSettings'].findAll({
      where: {
          id: id, status:1
        },
      attributes: {exclude :['createdAt','updatedAt']}
    }
      );
    if (data) {
      res.status(200).send({
        status:200,
        message:'Success',
        output:data
        });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot find with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.updateEmailSettings = async (req, res) => {
  try {
    const id = req.params.id;
    const data = {
        active_status :req.body.active_status
    }
    const num = await db2['emailSettings'].update(data, {
      where: {id:id},
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.deleteEmailSettings = async (req, res) => {
  const RoleData = {
    status: 0,
  }
  try {
    const id = req.params.id;

    console.log("id111", id);
    const num = await db2['emailSettings'].update(RoleData, {
      where: {
        id: {
          [Op.ne]:1
        }, id:id
    },
    });
    if (num == 1) {
      res.status(200).send({
        status:200,
        message: "Deleted successfully!"
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot delete with id : ${id}.`
      });
    }
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};