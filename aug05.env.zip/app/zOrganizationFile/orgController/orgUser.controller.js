const jwt = require("../../helpers/jwt");

const db = require("../../models");
const db2 = require("../orgModel/orgIndex.js");
const Op = db2.Sequelize.Op;

const bcrypt = require("bcrypt");
const saltRounds = 10;

const path = require("path");
const fs = require("fs");

const Moment = require('moment')
const mailer = require("../orgModel/mailer.model.js");


// Get Users
exports.getUsersCheck = async (req, res) => {
  try {
    var condition = {
      where:{
        status:1
      },
      order: [['updatedAt', 'DESC']], // ASC, DESC
      attributes:{exclude:['createdAt','updatedAt']},
      include: [
        {
          model: db2['usersPersonal'],
          // attributes: ['option_type', 'option_value'],
          where: {},
          // as: 'priority_status',
          required: false,
        },
        {
          model: db2['usersProfessional'],
          // attributes: ['option_type', 'option_value'],
          where: {},
          // as: 'priority_status',
          required: false,
        },
        {
          model: db2['usersFinance'],
          // attributes: ['option_type', 'option_value'],
          where: {},
          // as: 'priority_status',
          required: false,
        },
        {
          model: db2['usersGoals'],
          // attributes: ['option_type', 'option_value'],
          where: {},
          // as: 'priority_status',
          required: false,
        },
      ],
       offset :parseInt(req.query.offset) || 0,
      //   limit: parseInt(req.query.limit) || 12
        limit : (req.query.offset ? 12 : null)
    };
    var offset = parseInt(req.query.offset);
    var limit = parseInt(req.query.limit);

    if (offset >= 0 && limit >= 0) {
      condition.offset = offset;
      condition.limit = limit;
    }

    const data = await db2['user'].findAll(condition);
    res.status(200).send({
        status:200,
        message: 'Success',
        output:data
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
exports.editUser = async (req, res) => {
  try {
    const id = req.params.id;

    let thisQuery = `SELECT us.*, upd.*, uprd.*, usd.*, ug.*, us.id as id, r.role_name as designation_name, dep.option_value as department_name, us1.first_name as team_leader_name, us2.first_name as portfolio_head_name, us3.first_name as created_by_name FROM lz_user as us   
    left join lz_users_personal_details as upd on (upd.user_id = us.id)
    left join lz_users_professional_details as uprd on (uprd.user_id = us.id)
    left join lz_users_finance as usd on (usd.user_id = us.id)
    left join lz_users_goals as ug on (ug.user_id = us.id)
    left join lz_roles as r on (r.id = us.designation)
    left join lz_masters as dep on (dep.id = us.department)
    left join lz_user as us1 on (us1.id=us.team_leader)
    left join lz_user as us2 on (us2.id=us.portfolio_head)
    left join lz_user as us3 on (us3.id = us.created_by)
    where us.status = 1 and us.id = ${id}
    group by us.id
    order by us.updated_at DESC
    `
    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
        status:200,
        message: 'Success',
        output:data[0]
    });

  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};
// Save Basic Details
exports.saveUser = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);
   
    const organ_id = req.user.id
    const org_id = organ_id.org_id
    console.log('organ_id', org_id);

    let profile_image = "";
  
    if (req.files.profile_image) {
      const extension = req.files.profile_image[0]["mimetype"].split('/')[1]
      profile_image = req.files.profile_image[0]["filename"] + '.' + extension
    }

    if (!req.body.email || !req.body.password) {
      res.status(200).send({
        status:400,
        message: "Email & Password required.",
      });
      return;
    }

    var condition = {
      where: {
        [Op.and]: [
          {
            email: req.body.email,
          },
        ],
      },
    };

    const user = await db2[req.params.document].findOne(condition);

    if (user) {
      res.status(200).send({
        status:400,
        message: "Email already in use.",
      });
    } else {
      bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
        req.body.password = hash;
        const users = new db2[req.params.document]({
          first_name: req.body.first_name,
          last_name: req.body.last_name,
          employee_id: req.body.employee_id,
          org_id: org_id,
          designation: req.body.designation,
          department: req.body.department,
          p_phone_number: req.body.p_phone_number,
          email: req.body.email,
          o_phone_number: req.body.o_phone_number,
          o_email: req.body.o_email,
          aadhar_number: req.body.aadhar_number,
          pan_number: req.body.pan_number,
          dob: req.body.dob,
          date_of_joining: req.body.date_of_joining,
          password: req.body.password,
          api_token: req.body.api_token,
          profile_image: profile_image,
          team_leader: req.body.team_leader,
          portfolio_head: req.body.portfolio_head,
          language: req.body.language,
          created_by: created_by.id
        });
        const data = await users.save(users);

        const userID = data.dataValues.id;

        const data1 = await db2['usersPersonal'].create({
          user_id: userID,
        })
        const data2 = await db2['usersProfessional'].create({
          user_id: userID,
        })
        const data3 = await db2['usersFinance'].create({
          user_id: userID,
        })
        const data4 = await db2['usersGoals'].create({
          user_id: userID,
        })

        if (req.files.profile_image) {
            const currentPath = path.join(process.cwd(), "uploads", req.files.profile_image[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "uploads/users/profile_image/" + `${userID}`, profile_image);
            const baseUrl = process.cwd() + '/uploads/users/profile_image/' + `${userID}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully Profile image Uploaded!")
              }
            });
          }

        res.status(200).send({
          status:200,
          message: "Success.",
          output: data,
        });
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      status:500,
      message: error.message,
    });
  }
};
// Update Basic Details
exports.updateUser = async (req, res) => {

  const created_id = req.user.id
  const created_by = created_id.id
  console.log('created_by', created_by);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const role = req.user.id
  const role_id = role.designation
  console.log('role_id', role_id);

  try {
    let profile_image = "";
  
    if (req.files.profile_image) {
      const extension = req.files.profile_image[0]["mimetype"].split('/')[1]
      profile_image = req.files.profile_image[0]["filename"] + '.' + extension
    }
    
    const id = req.params.id;
    const user = await db2['user'].findOne({
      where: {id: id},
      // attributes:['id']
    });
    console.log("userrrrr",user);
    const adminId = user?.dataValues ? user?.dataValues.id : 0
    console.log("adminId", adminId);

    let thisQuery123 = ` select us.p_phone_number as mobile, us.email as email, us.first_name as user_name from lz_user as us where us.status = 1 and us.id = ${id} `
    const data123= await db2.sequelize.query(thisQuery123);

    const dataMobile = data123[0][0]?.mobile
    const dataUserName = data123[0][0]?.user_name
    const dataEmail = data123[0][0]?.email

    console.log("data123", data123[0][0]);
    console.log("dataMobile", dataMobile);
    console.log("dataUserName", dataUserName);
    console.log("dataEmail", dataEmail);

    const users = await db2['user'].findOne({
      // where: { email:`${req.body.email}`,id : `${adminId}`},
      where: {
        id: {
          [Op.ne]: adminId
        },
        email:`${req.body.email}`,
      },

      attributes:['id', "email"]
    });
    console.log("userssss", users);

    const executives = users?.dataValues ? users?.dataValues.id : 0
    console.log("executivesssss", executives);

    if (executives !== 0) {
      res.status(200).send({
        status:400,
        message: "Email already in use.",
      });
    } else {
    bcrypt.hash(req.body.password, saltRounds, async function (error, hash) {
      req.body.password = hash;

      const dob =  Moment.utc(req.body.dob).format('YYYY-MM-DD');
      const date_of_joining =  Moment.utc(req.body.date_of_joining).format('YYYY-MM-DD');

      let data = {};
      if(profile_image) { 
        data = {
          first_name: req.body.first_name,
          last_name: req.body.last_name,
          employee_id: req.body.employee_id,
          designation: req.body.designation,
          department: req.body.department,
          p_phone_number: req.body.p_phone_number,
          email: req.body.email,
          o_phone_number: req.body.o_phone_number,
          o_email: req.body.o_email,
          aadhar_number: req.body.aadhar_number,
          pan_number: req.body.pan_number,
          dob: dob,
          date_of_joining:date_of_joining,
          password: req.body.password,
          api_token: req.body.api_token,
          profile_image: profile_image,
          team_leader: req.body.team_leader,
          portfolio_head: req.body.portfolio_head,
          language: req.body.language,
        }
      } else {
        data = {
          first_name: req.body.first_name,
          last_name: req.body.last_name,
          employee_id: req.body.employee_id,
          designation: req.body.designation,
          department: req.body.department,
          p_phone_number: req.body.p_phone_number,
          email: req.body.email,
          o_phone_number: req.body.o_phone_number,
          o_email: req.body.o_email,
          aadhar_number: req.body.aadhar_number,
          pan_number: req.body.pan_number,
          dob: dob,
          date_of_joining:date_of_joining,
          password: req.body.password,
          api_token: req.body.api_token,
          team_leader: req.body.team_leader,
          portfolio_head: req.body.portfolio_head,
          language: req.body.language,
        }
      }

      const num = await db2[req.params.document].update( data, {
        where: { id: id },
      });
    if (num == 1) {

        let userID = req.params.id

        if (req.files.profile_image) {
            const currentPath = path.join(process.cwd(), "uploads", req.files.profile_image[0]["filename"]);
            const destinationPath = path.join(process.cwd(), "uploads/users/profile_image/" + `${userID}`, profile_image);
            const baseUrl = process.cwd() + '/uploads/users/profile_image/' + `${userID}`
            fs.mkdirSync(baseUrl, { recursive: true })
            fs.rename(currentPath, destinationPath, function (err) {
              if (err) {
                throw err
              } else {
                console.log("Successfully Profile image Uploaded!")
              }
            });
          }

      if(dataMobile?.toString() !== req.body.p_phone_number?.toString() || dataEmail !== req.body.email || dataUserName !== req.body.first_name) {
      // Email Trigger
      const email_settings = await db2.sequelize.query(`select status from lz_email_trigger where module_id = 1 and status = 1 `);
      // const emailTri = email_settings[0][0] ? email_settings[0][0]["active_status"] : 0
      const emailTri = email_settings[0][0]["status"]
      console.log("emailTri", emailTri);

      //nodemailer
      if(emailTri == 1) {

      let thisQueryDes = ` select us.team_leader as tl, us.portfolio_head as sub_tl 
      from lz_user as us where id = ${created_by} `
      const desCheck = await db2.sequelize.query(thisQueryDes);
      const desCheckTL = desCheck[0][0].tl
      const desCheckSubTL = desCheck[0][0].sub_tl
      // Team Leader
      const checkTl = await db2.sequelize.query(`select email from lz_user where id = ${desCheckTL} `);
      const checkTl1 = checkTl[0][0].email
      // Sub TL
      const checksubTL = await db2.sequelize.query(`select email from lz_user where id = ${desCheckSubTL} `);
      const checksubTL1 = checksubTL[0][0].email
      // Admin
      const checkAdmin = await db2.sequelize.query(`select email from lz_user where designation = 1 group by id `);
      const checkAdmin1 = checkAdmin[0].map(item => item.email).join(', ');
    
      console.log("checkTl", checkTl1);
      console.log("checksubTL1", checksubTL1);
      console.log("checkAdmin1", checkAdmin1);
    
      const createdEmail = await db2.sequelize.query(`select email from lz_user where id = ${created_by} `);
      const cEmail = createdEmail[0][0].email
      console.log("cEmail", cEmail);

      let message;
      let message2;
      let message3;
      
      if(dataMobile?.toString() !== req.body.p_phone_number?.toString()) {
        message = {
          from: cEmail,
          to: [checkAdmin1,checkTl1,checksubTL1].join(', '),
          subject: "Mobile Number Change",
          html:
            "<h3> Mobile Changed " + 
            dataMobile + ' to ' + req.body.p_phone_number + ''
        };
      } 
      if(dataEmail !== req.body.email) {
        message2 = {
          from: cEmail,
          to: [checkAdmin1,checkTl1,checksubTL1].join(', '),
          subject: "Email Change",
          html:
            "<h3> Email Changed" + 
            dataEmail + ' to ' + req.body.email + ''
        };
      } 
      if(dataUserName !== req.body.first_name) {
        message3 = {
          from: cEmail,
          to: [checkAdmin1,checkTl1,checksubTL1].join(', '),
          subject: "User Name Change",
          html:
            " User Name Changed " + dataUserName + ' to ' + req.body.first_name + ''
        };
      } 

      console.log("message", message);
      console.log("message2", message2);
      console.log("message3", message3);
      mailer.sendMail([message, message2, message3], function(error, info){
        if (error) {
          console.log('Error');
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
    }
      }
      res.status(200).send({
        status:200,
        message: "Updated successfully."
      });
    } else {
      res.status(200).send({
        status:404,
        message: `Cannot update with id : ${id}.`
      });
    }
  })} } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

// Save Personal Details
exports.saveUserPersonalDetails = async (req, res) => {
    try {
        const users = new db2['usersPersonal']({
            user_id: req.body.user_id,
            crm_login_id: req.body.crm_login_id,
            crm_login_password: req.body.crm_login_password,
            gender: req.body.gender,
            blood_group: req.body.blood_group,
            sec_mobile: req.body.sec_mobile,
            permenent_address: req.body.permenent_address,
            correspondence_address: req.body.correspondence_address,
            fathers_name: req.body.fathers_name,
            marital_status: req.body.marital_status,
            anniversary_date: req.body.anniversary_date,
            spouse_name: req.body.spouse_name,
            spouse_dob: req.body.spouse_dob,
            medical_condition: req.body.medical_condition,
            emergency_contact_no: req.body.emergency_contact_no,
            emergency_contact_person_name: req.body.emergency_contact_person_name,
            relation_person: req.body.relation_person,
            no_of_kids: req.body.no_of_kids,
            kid_name_1: req.body.kid_name_1,
            kid_name_2: req.body.kid_name_2,
            kid_name_3: req.body.kid_name_3,
        });
        const data = await users.save(users);

        res.status(200).send({
            status: 200,
            message: "Success.",
            output: data,
        });
    }
    catch (error) {
        console.log(error);
        res.status(500).send({
            status: 500,
            message: error.message,
        });
    }
};
// Update Personal Details
exports.updateUserPersonalDetails = async (req, res) => {
    try {
      const id = req.params.id;
      const user_id = req.params.user_id;
  
        const anniversary_date =  Moment.utc(req.body.anniversary_date).format('YYYY-MM-DD');
        const data = {
            user_id: req.body.user_id,
            crm_login_id: req.body.crm_login_id,
            crm_login_password: req.body.crm_login_password,
            gender: req.body.gender,
            blood_group: req.body.blood_group,
            sec_mobile: req.body.sec_mobile,
            permenent_address: req.body.permenent_address,
            correspondence_address: req.body.correspondence_address,
            fathers_name: req.body.fathers_name,
            marital_status: req.body.marital_status,
            anniversary_date: anniversary_date,
            spouse_name: req.body.spouse_name,
            spouse_dob: req.body.spouse_dob,
            medical_condition: req.body.medical_condition,
            emergency_contact_no: req.body.emergency_contact_no,
            emergency_contact_person_name: req.body.emergency_contact_person_name,
            relation_person: req.body.relation_person,
            no_of_kids: req.body.no_of_kids,
            kid_name_1: req.body.kid_name_1,
            kid_name_2: req.body.kid_name_2,
            kid_name_3: req.body.kid_name_3,
        }
        const num = await db2['usersPersonal'].update( data, {
          where: { user_id: user_id },
        });
      if (num == 1) {
        res.status(200).send({
          status:200,
          message: "Updated successfully."
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot update with id : ${user_id}.`
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};

// Save Professional Details
exports.saveUserProfessionalDetails = async (req, res) => {
    try {
        const users = new db2['usersProfessional']({
            user_id: req.body.user_id,
            duration: req.body.duration,
            years_of_experience : req.body.years_of_experience,
            last_company: req.body.last_company,
            official_mobile_number: req.body.official_mobile_number,
            official_mail: req.body.official_mail,
            local_address: req.body.local_address,
            city: req.body.city,
            target_for_fy_rs: req.body.target_for_fy_rs,
            target_for_fy_units: req.body.target_for_fy_units,
            monthly_ctc: req.body.monthly_ctc,
            monthly_take_home: req.body.monthly_take_home,
            incentive: req.body.incentive,
        });
        const data = await users.save(users);

        res.status(200).send({
            status: 200,
            message: "Success.",
            output: data,
        });
    }
    catch (error) {
        console.log(error);
        res.status(500).send({
            status: 500,
            message: error.message,
        });
    }
};
// Update Professional Details
exports.updateUserProfessionalDetails = async (req, res) => {
    try {
      const id = req.params.id;
      const user_id = req.params.user_id;
  
        const data = {
            user_id: req.body.user_id,
            duration: req.body.duration,
            years_of_experience : req.body.years_of_experience,
            last_company: req.body.last_company,
            official_mobile_number: req.body.official_mobile_number,
            official_mail: req.body.official_mail,
            local_address: req.body.local_address,
            city: req.body.city,
            target_for_fy_rs: req.body.target_for_fy_rs,
            target_for_fy_units: req.body.target_for_fy_units,
            monthly_ctc: req.body.monthly_ctc,
            monthly_take_home: req.body.monthly_take_home,
            incentive: req.body.incentive,
        }
        const num = await db2['usersProfessional'].update( data, {
          where: { user_id: user_id },
        });
      if (num == 1) {
        res.status(200).send({
          status:200,
          message: "Updated successfully."
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot update with id : ${user_id}.`
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};

// Save Finance Details
exports.saveUserFinance = async (req, res) => {
    try {
        const users = new db2['usersFinance']({
            user_id: req.body.user_id,
            base_salary: req.body.base_salary,
            pf : req.body.pf,
            hra: req.body.hra,
            mediclaim: req.body.mediclaim,
            conveyance: req.body.conveyance,
            misc: req.body.misc,
            total_ctc: req.body.total_ctc,
            bank_record_name: req.body.bank_record_name,
            bank_name: req.body.bank_name,
            acc_number: req.body.acc_number,
            ifsc_code: req.body.ifsc_code,
            branch_name: req.body.branch_name,
        });
        const data = await users.save(users);

        res.status(200).send({
            status: 200,
            message: "Success.",
            output: data,
        });
    }
    catch (error) {
        console.log(error);
        res.status(500).send({
            status: 500,
            message: error.message,
        });
    }
};
// Update Finance Details
exports.updateUserFinance = async (req, res) => {
    try {
      const id = req.params.id;
      const user_id = req.params.user_id;
  
        const data = {
            user_id: req.body.user_id,
            base_salary: req.body.base_salary,
            pf : req.body.pf,
            hra: req.body.hra,
            mediclaim: req.body.mediclaim,
            conveyance: req.body.conveyance,
            misc: req.body.misc,
            total_ctc: req.body.total_ctc,
            bank_record_name: req.body.bank_record_name,
            bank_name: req.body.bank_name,
            acc_number: req.body.acc_number,
            ifsc_code: req.body.ifsc_code,
            branch_name: req.body.branch_name,
        }
        const num = await db2['usersFinance'].update( data, {
          where: { user_id: user_id },
        });
      if (num == 1) {
        res.status(200).send({
          status:200,
          message: "Updated successfully."
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot update with id : ${id}.`
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};


// Save Goals
exports.saveUserGoals = async (req, res) => {
    try {
        const users = new db2['usersGoals']({
            user_id: req.body.user_id,
            goal_calls: req.body.goal_calls,
            goal_talktime : req.body.goal_talktime,
            goal_leads_generated: req.body.goal_leads_generated,
            goal_leads_converted: req.body.goal_leads_converted,
            goal_site_visit: req.body.goal_site_visit,
            goal_meetings: req.body.goal_meetings,
            goal_bookings: req.body.goal_bookings,
            goal_revenue: req.body.goal_revenue,
            no_of_units_committed: req.body.no_of_units_committed,
            annual_target: req.body.annual_target,
            no_of_sales: req.body.no_of_sales,
            turnover: req.body.turnover,
            discount: req.body.discount,
            incentives: req.body.incentives,
            status_changed: req.body.status_changed,
        });
        const data = await users.save(users);

        res.status(200).send({
            status: 200,
            message: "Success.",
            output: data,
        });
    }
    catch (error) {
        console.log(error);
        res.status(500).send({
            status: 500,
            message: error.message,
        });
    }
};
// Update Goals
exports.updateUserGoals = async (req, res) => {
    try {
      const id = req.params.id;
      const user_id = req.params.user_id;
  
        const data = {
            user_id: req.body.user_id,
            goal_calls: req.body.goal_calls,
            goal_talktime : req.body.goal_talktime,
            goal_leads_generated: req.body.goal_leads_generated,
            goal_leads_converted: req.body.goal_leads_converted,
            goal_site_visit: req.body.goal_site_visit,
            goal_meetings: req.body.goal_meetings,
            goal_bookings: req.body.goal_bookings,
            goal_revenue: req.body.goal_revenue,
            no_of_units_committed: req.body.no_of_units_committed,
            annual_target: req.body.annual_target,
            no_of_sales: req.body.no_of_sales,
            turnover: req.body.turnover,
            discount: req.body.discount,
            incentives: req.body.incentives,
            status_changed: req.body.status_changed,
        }
        const num = await db2['usersGoals'].update( data, {
          where: { user_id: user_id },
        });
      if (num == 1) {
        res.status(200).send({
          status:200,
          message: "Updated successfully."
        });
      } else {
        res.status(200).send({
          status:404,
          message: `Cannot update with id : ${user_id}.`
        });
      }
    } catch (error) {
      res.status(500).send({
        message: error.message,
      });
    }
};


// Delete User
exports.deleteUser = async (req, res) => {
  const UserData = {
      status: 0,
  }
  try {
      const id = req.params.id;
      const num = await db2[req.params.document].update(UserData, {
          where: { id: id },
      });
      if (num == 1) {
          res.status(200).send({
              status:200,
              message: "Deleted successfully!"
          });
      } else {
          res.status(200).send({
              status:404,
              message: `Cannot delete with id : ${id}.`
          });
      }
  } catch (error) {
      res.status(500).send({
          message: error.message,
      });
  }
};

exports.getUsersDropdown = async (req, res) => {
  try {
    const created_by = req.user.id
    console.log('created_by', created_by.id);

    const role = req.user.id
    const role_id = role.designation
    console.log('created_by', created_by.id);
      let values = ['department', 'branch', 'gender', 'blood_group','marital_status']

      // const dataFromOrg = await Modelv1.getAllFromOrg();
      var condition = {
        where:{status:1},
        attributes:{exclude:['createdAt','updatedAt', 'created_by','status']}
      }
      const dataFromCity = await db['city'].findAll(condition);
      const dataFromState = await db['state'].findAll(condition);
      const dataFromCountry = await db['country'].findAll(condition);
      const dataFromRoles = await db2['roles'].findAll({
        where:{status:1},
        attributes:{exclude:['createdAt','updatedAt','org_id','reporting_to','created_by','status']}
      });
      // const dataFromTL = await db2['user'].findAll({
      //   attributes:['id','first_name','last_name']
      // });
      // const dataFromSubTL = await db2['user'].findAll({
      //   attributes:['id','first_name','last_name']
      // });

      let roleQuery = `select rol.id as id, rol.role_name as role_name from lz_roles as rol
      where rol.status = 1 group by rol.id `

      const roleData = await db2.sequelize.query(roleQuery);
      // const finalRoleData = roleData[0][0].id
      // const finalRoleData = req.body.designation ?? null
      const finalRoleData = req.params.designation ?? null 
      console.log("roleDataaaaaaa", finalRoleData);

      let tldata = `select us.id as id, GROUP_CONCAT( CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as users_name, us.designation as designation from lz_user as us
      left join lz_roles as rol on (rol.id = ${finalRoleData}) 
      where us.status = 1 and rol.status= 1 and FIND_IN_SET(us.designation,rol.reporting_to) group by us.id `
      const dataFromTL = await db2.sequelize.query(tldata);

      let subTldata = `select us.id as id, GROUP_CONCAT( CONCAT(us.first_name,' ', IFNULL(us.last_name, ''))) as users_name, us.designation as designation from lz_user as us
      left join lz_roles as rol on (rol.id = us.id) 
      where us.status = 1 and rol.status= 1 and us.designation < ${finalRoleData} group by us.id `
      const dataFromSubTL = await db2.sequelize.query(subTldata);

      const dataFromMasters = await db2['masters'].findAll(condition);
      let model4Datafetch = Object.values(JSON.parse(JSON.stringify(dataFromMasters)));
      const department = model4Datafetch.filter((obj) => obj.option_type == 'department');
      const branch = model4Datafetch.filter((obj) => obj.option_type == 'branch');
      const gender = model4Datafetch.filter((obj) => obj.option_type == 'gender');
      const blood_group = model4Datafetch.filter((obj) => obj.option_type == 'blood_group');
      const marital_status = model4Datafetch.filter((obj) => obj.option_type == 'marital_status');

      const combinedData = {
          // tl: dataFromTL11[0],
          team_leader: dataFromTL[0],
          sub_tl: dataFromSubTL[0],
          city: dataFromCity,
          state: dataFromState,
          country: dataFromCountry,
          roles: dataFromRoles,
          department: department,
          branch: branch,
          gender: gender,
          blood_group: blood_group,
          marital_status: marital_status,
      };
      res.status(200).send({
          message: "Users dropdown get data",
          status: 200,
          output: combinedData
      })

  }
  catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal Server Error' });
  }
};

exports.getUsers = async (req, res) => {

  const created_id = req.user.id
  const created_by = created_id.id
  console.log('created_by', created_by);

  const organ_id = req.user.id
  const org_id = organ_id.org_id
  console.log('organ_id', org_id);

  const role = req.user.id
  const role_id = role.designation
  console.log('role_id', role_id);

  try {
    let thisQuery = `SELECT us.*, upd.*, uprd.*, usd.*, ug.*, us.id as id, r.role_name as designation_name, dep.option_value as department_name, us1.first_name as team_leader_name, us2.first_name as portfolio_head_name, us3.first_name as created_by_name FROM lz_user as us   
    left join lz_users_personal_details as upd on (upd.user_id = us.id)
    left join lz_users_professional_details as uprd on (uprd.user_id = us.id)
    left join lz_users_finance as usd on (usd.user_id = us.id)
    left join lz_users_goals as ug on (ug.user_id = us.id)
    left join lz_roles as r on (r.id = us.designation)
    left join lz_masters as dep on (dep.id = us.department)
    left join lz_user as us3 on (us3.id = us.created_by)
    left join lz_user as us1 on (us1.id = us.team_leader)
    left join lz_user as us2 on (us2.id = us.portfolio_head)

    left join lz_user as us5 on (us.created_by = us5.id) 
    left join lz_user as us4 on (us5.team_leader = us4.id) 
    left join lz_user as us6 on (us.created_by = us6.id) 
    left join lz_user as us7 on (us6.portfolio_head = us7.id)
    
    where us.status = 1 
    `
    if (role_id == 1) {
      thisQuery += ` `
    }
    if (role_id == 2) {
      thisQuery += ` and us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or us.id = ${created_by} `
      // thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
    }
    if (role_id == 3) {
      thisQuery += ` and us.team_leader = ${created_by} or us.portfolio_head = ${created_by} or us.id = ${created_by} `
      // thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
    }
    if (role_id == 4) {
      thisQuery += ` and us.id = ${created_by} `
      // thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
    }
    if (role_id >= 5) {
      thisQuery += ` and us.id = ${created_by} `
      // thisQuery += ` and c.status= 1 and c.created_by = ${created_by} `
    }

    const filters = req.query;

    thisQuery += ' group by us.id '

    const data1 = await db2.sequelize.query(thisQuery);

    if (filters.order_by =="" || filters.order_by == undefined) {
      thisQuery += '  order by us.id DESC '
    }

    if (filters.limit) {
      thisQuery += ` limit ${filters.limit},12 `
    }
    const data = await db2.sequelize.query(thisQuery);

    const count_filter = (data1[0])

    res.status(200).send({
        status:200,
        message: 'Success',
        count:count_filter.length,
        output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getGoalsPerformances = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    const keyword = req.params.keyword
    // let thisQuery = ` `

    // if (keyword == "goal_talktime") {
    //   thisQuery += ` SELECT ifnull(COUNT(*),0) as lz_contacts, us.goal_talktime FROM lz_contacts as c LEFT JOIN lz_users_goals as us on (us.user_id=${created_by}) where c.status =1 and FIND_IN_SET(${created_by},c.assign_to)>0 or c.created_by = ${created_by}`
    // }
    // if (keyword == "lead_generate") {
    //   thisQuery += ` select COUNT(lg.id) as count from lz_logs as lg 
    //   left join lz_leads as l on (l.id = lg.module_id) 
    //   where (l.status = 1) and (lg.note ='lead created at') and (lg.module_name=2) `
    // }

    
  let thisQuery = `select us.id, us.user_id as user_id,
  (SELECT COUNT(usg.id) FROM lz_users_goals as usg where user.created_by = us.user_id ) as total_talktime_count,
  (SELECT COUNT(lg.id) FROM lz_logs as lg where lg.user_id = us.user_id and lg.note = 'lead created at' ) as lead_generated_count,
  (SELECT COUNT(c.id) FROM lz_contacts as c where c.created_by = us.user_id and c.status = 1 ) as lead_converted_count,
  (SELECT COUNT(fi.id) FROM lz_finance_incentives as fi where fi.created_by = us.user_id) as incentives_count
  from lz_users_goals as us  
  left join lz_user as user on (user.id = us.user_id)
  group by us.id
  order by us.id ASC
  `;

    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
        status:200,
        message: 'Success',
        output:data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};

exports.getAllGoalPerformances = async (req, res) => {
  try {
    const created_id = req.user.id
    const created_by = created_id.id
    console.log('created_by', created_by);

    let thisQuery = ` SELECT usg.*, GROUP_CONCAT(distinct CONCAT(us.first_name,' ', IFNULL(us.last_name,''))) as user_name FROM lz_users_goals as usg
    LEFT JOIN lz_user as us on (us.id = usg.user_id) 
    group by usg.id
    order by usg.id ASC
    `
    const data = await db2.sequelize.query(thisQuery);

    res.status(200).send({
      status: 200,
      message: 'Success',
      output: data[0]
    });
  } catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
};






// exports.getUsers = async (req, res) => {
//   try {
//     let thisQuery = `SELECT us.*, upd.*, uprd.*, usd.*, ug.*, us.id as id, r.role_name as designation_name, dep.option_value as department_name, us1.first_name as team_leader_name, us2.first_name as portfolio_head_name, us3.first_name as created_by_name FROM lz_user as us   
//     left join lz_users_personal_details as upd on (upd.user_id = us.id)
//     left join lz_users_professional_details as uprd on (uprd.user_id = us.id)
//     left join lz_users_finance as usd on (usd.user_id = us.id)
//     left join lz_users_goals as ug on (ug.user_id = us.id)
//     left join lz_roles as r on (r.id = us.designation)
//     left join lz_masters as dep on (dep.id = us.department)
//     left join lz_user as us3 on (us3.id = us.created_by)
//     left join lz_user as us1 on (us1.id=us.team_leader)
//     left join lz_user as us2 on (us2.id=us.portfolio_head)
//     where us.status = 1 
//     group by us.id
//     order by us.updated_at DESC
//     `
//     const filters = req.query;

//     const data1 = await db2.sequelize.query(thisQuery);

//     if (filters.limit) {
//       thisQuery += ` limit ${filters.limit},12 `
//     }
//     const data = await db2.sequelize.query(thisQuery);

//     const count_filter = (data1[0])

//     res.status(200).send({
//         status:200,
//         message: 'Success',
//         count:count_filter.length,
//         output:data[0]
//     });
//   } catch (error) {
//     res.status(500).send({
//       message: error.message,
//     });
//   }
// };