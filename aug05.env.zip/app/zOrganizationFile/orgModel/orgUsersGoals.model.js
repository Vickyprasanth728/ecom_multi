module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_users_goals", {
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_calls: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_talktime: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_leads_generated: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_leads_converted: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_site_visit: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_meetings: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_bookings: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      goal_revenue: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      no_of_units_committed: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      annual_target: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      no_of_sales: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      turnover: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      discount: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      incentives: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      status_changed: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
    },{
      tableName:'lz_users_goals'
    });
  };