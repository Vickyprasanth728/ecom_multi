// module.exports = (sequelize, Sequelize) => {
//     return sequelize.define("lz_users", {
//       email: {
//         type: Sequelize.STRING,
//         allowNull: false,
//         unique: true,
//         // validate : { isEmail: true}
//         // validate:{
//         //  not: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i
//         // }
//       },
//       password: {
//         type: Sequelize.STRING,
//         allowNull: false,
//       },
//       org_id: {
//         type: Sequelize.INTEGER,
//         allowNull: true,
//         validate : {isInt: true} 
//       },
//       created_by: {
//         type: Sequelize.INTEGER,
//         allowNull: true,
//         validate : {isInt: true}
//       },
//       status: {
//         type: Sequelize.INTEGER,
//         allowNull: true,
//         defaultValue:1,
//         validate : {isInt: true}
//       },
//       language: {
//         type: Sequelize.INTEGER,
//         allowNull: true,
//         defaultValue:1,
//         validate : {isInt: true}
//       },
//       createdAt: {
//         type: 'TIMESTAMP',
//         allowNull: true,
//         defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
//         field:'created_at'
//       },
//       updatedAt: {
//         type: 'TIMESTAMP',
//         allowNull: true,
//         defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
//         field:'updated_at'
//       },
//     },{
//       tableName:'lz_users'
//   });
//   };
  