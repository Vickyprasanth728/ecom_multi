module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_users_professional_details", {
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      duration: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      years_of_experience: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      last_company: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      official_mobile_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      official_mail: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      local_address: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      city: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      target_for_fy_rs: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
        // validate : {isDecimal: true}
      },
      target_for_fy_units: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      monthly_ctc: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
        // validate : {isDecimal: true}
      },
      monthly_take_home: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
        // validate : {isDecimal: true}
      },
      incentive: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: true,
        // validate : {isDecimal: true}
      },
    },{
      tableName:'lz_users_professional_details'
    });
  };