module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_lead_requirements", {
      lead_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      requirement_location: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      budget_min: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
      },
      budget_max: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
      },
      money_term_min: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      money_term_max: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      no_of_bedrooms_min: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      no_of_bedrooms_max: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      no_of_bathrooms_min: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      no_of_bathrooms_max: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      built_up_area_min: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      built_up_area_max: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      plot_area_min: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      plot_area_max: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      possession_status: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      age_of_property: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      vasthu_compliant: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      property_facing: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      furnishing: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      car_park_min: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      car_park_max: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      timeline_for_closure_min: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      timeline_for_closure_max: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      amenities: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      country: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      state: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      city: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      zipcode: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      locality: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_lead_requirements'
    });
  };
  