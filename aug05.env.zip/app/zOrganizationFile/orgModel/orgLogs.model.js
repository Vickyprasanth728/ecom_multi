module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_logs", {
      org_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      module_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      module_name: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      note: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_logs'
    });
  };