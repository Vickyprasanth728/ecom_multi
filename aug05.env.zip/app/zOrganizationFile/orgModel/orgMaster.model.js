module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_masters", {
    org_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
    },
      option_type: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      option_value: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_masters'
    });
  };
  