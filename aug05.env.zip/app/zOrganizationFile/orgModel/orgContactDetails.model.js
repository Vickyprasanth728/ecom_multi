module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_contact_details", {
        contact_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true }
        },
        gst_number: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        invoice_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        gender: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        dob: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        marital_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        wedding_anniversary: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        number_of_children: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null }
        },
        pet_owner: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null }
        },
        nationality: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        language: {
            type: Sequelize.STRING,
            allowNull: true,
            // validate: { isInt: true || null }
        },
        designation: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        national_id: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        do_not_disturb: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null }
        },
        documents: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_contact_details'
    });
};