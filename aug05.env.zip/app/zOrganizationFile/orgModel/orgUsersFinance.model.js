module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_users_finance", {
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      base_salary: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        defaultValue:0000,
      },
      pf: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        defaultValue:0000,
      },
      hra: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        defaultValue:0000,
      },
      mediclaim: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        defaultValue:0000,
      },
      conveyance: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        defaultValue:0000,
      },
      misc: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      total_ctc: {
        type: Sequelize.DECIMAL(20,4),
        allowNull: false,
        defaultValue:0000,
      },
      bank_record_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      bank_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      acc_number: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      ifsc_code: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      branch_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
    },{
      tableName:'lz_users_finance'
    });
  };