module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_finance_invoice_collection", {
        transaction_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        fee_confirmation_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        invoice_number: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        invoice_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        total_invoiced_value: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        total_collection_value: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        total_due_value: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        bad_debts: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        notes: {
            type: Sequelize.TEXT,
            allowNull: true,
        },
        collection_status: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER(11),
            allowNull: false,
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 1,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_finance_invoice_collection'
    });
};