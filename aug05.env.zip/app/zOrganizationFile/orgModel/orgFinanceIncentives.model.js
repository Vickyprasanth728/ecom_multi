module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_finance_incentives", {
        transaction_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        invoice_number: {
            type: Sequelize.INTEGER(55),
            allowNull: true,
        },
        select_brokers: {
            type: Sequelize.STRING(1200),
            allowNull: true,
        },
        total_incentive	: {
            type: Sequelize.INTEGER(55),
            allowNull: true,
        },
        incentive_payable: {
            type: Sequelize.STRING(100),
            allowNull: true,
        },
        paid_amount: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        incentive_due: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        description: {
            type: Sequelize.STRING(255),
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: false,
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 1,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_finance_incentives'
    });
};