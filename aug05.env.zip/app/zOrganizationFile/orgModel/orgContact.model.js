module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_contacts", {
    org_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
    },
    salutation: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    first_name: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    last_name: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    company_name: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    developer_name: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    email: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    phone_number_type: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    code: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    mobile: {
        type: Sequelize.STRING,
        allowNull: true,
        // validate:{
        //   // len: [7,15],
        //   len:{
        //     args:[7,15],
        //     msg:"Minimum 7 to Maximum 15 numbers need to be save"
        //   },
        // }
    },
    assign_to: {
        type: Sequelize.STRING,
        allowNull: true,
    },
    property_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      contact_group: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      source: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      contact_type: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      contact_category: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      contact_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      remarks: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      profile_image: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      profile_image_original_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      is_secondary_contact: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      secondary_contact_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      refid: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
        validate : {isInt: true}
      },
      status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        defaultValue:1,
        validate : {isInt: true}
      },
      createdAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'created_at'
      },
      updatedAt: {
        type: 'TIMESTAMP',
        allowNull: true,
        defaultValue:sequelize.literal('CURRENT_TIMESTAMP'),
        field:'updated_at'
      },
    },{
      tableName:'lz_contacts'
    });
  };