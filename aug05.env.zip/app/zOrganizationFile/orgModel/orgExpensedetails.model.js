module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_expense_details", {
        expense_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        client: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        amount: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        city_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        tl_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        builder_id: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        project_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        month: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        campaign_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        campaign_source_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        cost_of_campaign: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        total_value: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        gst_value: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_expense_details'
    });
};