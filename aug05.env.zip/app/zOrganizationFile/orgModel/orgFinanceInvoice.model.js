module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_finance_invoice", {
        transaction_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        fee_confirmation_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        pro_invoice_id: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        contact_name: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        developer_name: {
            type: Sequelize.STRING(255),
            allowNull: true,
        },
        project_name: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        due_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        expense_id: {
            type: Sequelize.STRING(1000),
            allowNull: true,
        },
        tax: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        total_amount: {
            type: Sequelize.DECIMAL(20,4),
            allowNull: true,
        },
        invoice_status: {
            type: Sequelize.INTEGER(11),
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER(11),
            allowNull: false,
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue: 1,
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_finance_invoice'
    });
};