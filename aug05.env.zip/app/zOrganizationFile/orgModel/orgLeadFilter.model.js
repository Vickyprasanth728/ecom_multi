module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_lead_filter", {
        property_id: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true }
        },
        looking_for: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        property_type: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        requirement_location: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        lead_source: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        lead_priority: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        lead_group	: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        fee_oppurtunity: {
            type: Sequelize.INTEGER,
            allowNull: true,
            // validate: { isInt: true || null}
        },
        lead_status: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        assign_to: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_bedrooms_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_bedrooms_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_bathrooms_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        no_of_bathrooms_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        budget_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        budget_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        built_up_area_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        built_up_area_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        plot_area_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        plot_area_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        car_park_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        car_park_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        timeline_for_closure_min: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        timeline_for_closure_max: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        age_of_property: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        vasthu_compliant: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        amenities: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        furnishing: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        possession_status: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        filter_name: {
            type: Sequelize.STRING,
            allowNull: true,
        },
        created_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        updated_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        updated_date: {
            type: Sequelize.DATEONLY,
            allowNull: true,
        },
        created_by: {
            type: Sequelize.INTEGER,
            allowNull: true,
        },
        status: {
            type: Sequelize.INTEGER,
            allowNull: true,
            defaultValue:1,
            validate : {isInt: true}
        },
        createdAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'created_at'
        },
        updatedAt: {
            type: 'TIMESTAMP',
            allowNull: true,
            defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
            field: 'updated_at'
        },
    }, {
        tableName: 'lz_lead_filter'
    });
};