module.exports = (sequelize, Sequelize) => {
    return sequelize.define("lz_users_personal_details", {
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      crm_login_id: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      crm_login_password: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      gender: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      blood_group: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      sec_mobile: {
        type: Sequelize.BIGINT,
        allowNull: true,
        // validate : {isInt: true}
      },
      permenent_address: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      correspondence_address: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      fathers_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      marital_status: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      anniversary_date: {
        type: Sequelize.DATEONLY,
        allowNull: true,
        // validate: {isDate: true}
      },
      spouse_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      spouse_dob: {
        type: Sequelize.DATEONLY,
        allowNull: true,
        // validate: {isDate: true}
      },
      medical_condition: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      emergency_contact_no: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      emergency_contact_person_name: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      relation_person: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      no_of_kids: {
        type: Sequelize.INTEGER,
        allowNull: true,
        // validate : {isInt: true}
      },
      kid_name_1: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      kid_name_2: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      kid_name_3: {
        type: Sequelize.STRING,
        allowNull: true,
      },
    },{
      tableName:'lz_users_personal_details'
    });
  };