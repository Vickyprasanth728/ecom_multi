const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgExpenses = require("../../zOrganizationFile/orgController/orgExpenses.controller.js");
  
    var router = require("express").Router();
  
    // save expenses
    router.post("/save/:document",authentication, upload.fields([
        { name: "receipt_name", maxCount: 1 },
    ]), function (req, res, next) {
        orgExpenses.saveExpenses(req, res, next)
    });
  
    router.get("/get/:document", authentication, orgExpenses.getExpenses);
  
    router.get("/edit/:document/:id", authentication, orgExpenses.editExpense);
  
    router.put("/update/:document/:id", authentication, upload.fields([
        { name: "receipt_name", maxCount: 1 },
    ]), function (req, res, next) {
        orgExpenses.updateExpense(req, res, next)
    });
    router.put("/update_expense_details/:document/:expense_id", authentication, orgExpenses.updateExpenseDetails);
  
    router.put("/delete/:document/:id", authentication, orgExpenses.deleteExpense);
  
    app.use('/orgExpenses/',auth, router);
  };