const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgEmail = require("../../zOrganizationFile/orgController/emailSettings.controller.js");
  
    var router = require("express").Router();
  
    // Roles
    router.post("/save",authentication, orgEmail.createEmailSettings);
  
    router.get("/get",authentication, orgEmail.getEmailSettings);
  
    router.get("/edit/:id",authentication, orgEmail.editEmailSettings);
  
    router.put("/update/:id",authentication, orgEmail.updateEmailSettings);
  
    router.put("/delete/:id",authentication, orgEmail.deleteEmailSettings);
  
    app.use('/orgEmail/',auth, router);
  };
  