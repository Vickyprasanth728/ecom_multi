const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgDashboard = require("../../zOrganizationFile/orgController/orgDashboard.controller.js");
  
    var router = require("express").Router();
  
    // Dashboard OverAll Count
    router.get("/get_dashboard_count", authentication, orgDashboard.getDashboardCount);
    // Dashboard Bar Chart Count
    router.get("/get_dashboard_bar_count/:moduleId/:id/:created_by/:team_leader", authentication, orgDashboard.getDashboardBarCount);
    // Dashboard Pie Chart Count
    router.get("/get_dashboard_masters_count/:option_type/:moduleId/:created_by/:team_leader", authentication, orgDashboard.getDashboardMastersCount);
    // Dashboard Tasks Count
    router.get("/get_dashboard_task_count/:moduleId/:created_by/:team_leader", authentication, orgDashboard.getDashboardTaskCount);
    // Dashboard Users & Teams List
    router.get("/get_dashboard_users", authentication, orgDashboard.getDashboardUsers);
    // Dashboard Goals
    router.get("/get_dashboard_goals/:moduleId/:created_by/:team_leader", authentication, orgDashboard.getDashboardGoals);
    // Dashboard HR
    router.get("/get_dashboard_hr", authentication, orgDashboard.getDashboardHR);
  
    app.use('/orgDashboard/',auth, router);
  };