const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgAttendance = require("../../zOrganizationFile/orgController/orgAttendance.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document", authentication, orgAttendance.saveAttendance);
    // Check-IN
    router.post("/checkIn/:document", authentication, orgAttendance.checkInAttendance);
  
    // Attendance
    router.get("/get/:document/:user_id/:team_leader", authentication, orgAttendance.getAttendance);
    // Timesheeet
    router.get("/get_timesheet/:document", authentication, orgAttendance.getAttendanceTimeSheet);
    // Attendance Count
    router.get("/get_attendance_count/:document/:user_id", authentication, orgAttendance.getAttendanceCount);

    router.get("/get_log_sheet", authentication, orgAttendance.getLogSheet);
    
    router.get("/get_attendance_check/:document/:user_id/:team_leader", authentication, orgAttendance.getAttendanceCheck);
  
    router.get("/edit/:document/:id", authentication, orgAttendance.findOne);
  
    router.put("/update/:document/:id", authentication, orgAttendance.updateAttendance);
  
    router.put("/delete/:document/:id", authentication, orgAttendance.deleteAttendance);
  
    app.use('/orgAttendance/',auth, router);
  };