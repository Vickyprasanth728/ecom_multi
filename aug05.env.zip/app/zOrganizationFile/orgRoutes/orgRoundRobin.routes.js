const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})


const apikey = (req, res, next) => {
  if (req.header('apikey') == `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9`) {
    return next()
  }
  else {
    res.status(500).send({
      message: 'Invalid Api-Key',
    });
  }
};
const apikey1 = (req, res, next) => {
  if (req.header('apikey') == `c7665cacf996f46f6e3b47axxxxxxxx`) {
    return next()
  }
  else {
    res.status(500).send({
      message: 'Invalid Api-Key',
    });
  }
};
module.exports = app => {
    const orgCon = require("../../zOrganizationFile/orgController/orgRoundRobin.controller.js");
  
    var router = require("express").Router();

    // GOOGLE-PPC
    router.post("/save_googleppc", apikey1, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveGooglePpc(req, res, next)
    });

    // FACEBOOK
    router.post("/save_facebook", upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveFaceBook(req, res, next)
    });

    // HOUSING.COM
    router.post("/save_housing", upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveHousing(req, res, next)
    });
    // ROOF & FLOOR
    router.post("/save_roof_floor", apikey, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveRoofFloor(req, res, next)
    });
    // save Housing Api
    router.post("/save_housing_api", upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveHousingApi(req, res, next)
    });
    // Save Magic Bricks Api
    router.post("/save_magicbricks", apikey1, upload.fields([
      { name: "profile_image", maxCount: 1 },
    ]), function (req, res, next) {
      orgCon.saveMagicBricks(req, res, next)
    });

    // Save Responder
    router.post("/save_responders", orgCon.saveResponder);

    app.use('/', router);
  };