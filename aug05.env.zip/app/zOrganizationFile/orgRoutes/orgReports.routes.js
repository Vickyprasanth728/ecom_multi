const authentication = require("../../middlewares/auth.js");

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgTransaction = require("../../zOrganizationFile/orgController/orgReports.controller.js");
  
    var router = require("express").Router();
  
    // Leads
    router.get("/get_leads_reports/:id/:created_by/:team_leader",authentication, orgTransaction.getLeadsReports);
    router.get("/get_leads_report/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getLeadsReportMasters);
    // Contacts
    router.get("/get_contact_report/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getContactsReportMasters);
    // Property
    router.get("/get_property_report/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getPropertyReportMasters);
    // Tasks
    router.get("/get_task_report/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getTaskReportMasters);
    // Transactions
    router.get("/get_transaction_report/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getTransactionReportMasters);
    // Finance
    router.get("/get_finance_report/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getFinanceReportMasters);
    // HR
    router.get("/get_hr_report/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getHRReportMasters);
    // OverAll Count
    router.get("/get_report_count/:moduleId/:created_by/:team_leader",authentication, orgTransaction.getReportCount);

    app.use('/orgReports/',auth, router);
  };