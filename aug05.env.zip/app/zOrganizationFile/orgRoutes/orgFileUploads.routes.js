const authentication = require("../../middlewares/auth.js");
const multer = require('multer')
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

module.exports = app => {
    const auth = require("../../middlewares/auth");
    const orgFiles = require("../../zOrganizationFile/orgController/orgFileUploads.controller.js");
  
    var router = require("express").Router();
  
    router.post("/save/:document/:id", authentication, upload.array('uploadfiles'), orgFiles.saveFileUploads);
  
    router.get("/get/:document/:module_id/:module_name", authentication, orgFiles.getFileUploads);
  
    router.put("/delete/:document/:id", authentication, orgFiles.deleteFileUpload);
  
    app.use('/orgFiles/',auth, router);
  };