
const jwt = require('../helpers/jwt/index');
const db = require("../models");

const verifyToken = (req, res, next) => {
    const token = req.headers.authorization;

    if (!token) {
        return res.status(403).send({
            message : "A token is required for authentication"
        });
    }

    jwt.accessTokenDecode(function (e) {
        if (e.status) {
            req.user = e.data;
            // const org = req.user.id.org_id
            // console.log("req.user", req.user);

            // let DBData;
            // const pop = async() => {
            //   let thisQuery = `select sub_domain_database_name from lz_organization where status = 1 and id = ${org} `
            //   const data = await db.sequelize.query(thisQuery);
          
            //   DBData = data[0][0].sub_domain_database_name
            //   console.log("DBData", DBData);
              
            //   return DBData;
            // }
            // pop();
            // setTimeout(() => {
            //   console.log('popppppppppppppppppppppppppppppppp', DBData);
            // }, 1000)

            return next();
        } else {
            return res.status(e.code).send({
                message : e.message
            });
        }
    }, token);

};


// let hdfhd = 567;
// const verifyToken = (req, res, next) => {
//     const token = req.headers.authorization;

//     // hdfhd = { "req": req, "res":res, "token":12};

//     if (!token) {
//         return res.status(403).send({
//             message : "A token is required for authentication"
//         });
//     }

//     jwt.accessTokenDecode(function (e) {
//         if (e.status) {
//             req.user = e.data;
//             return next();
//         } else {
//             return res.status(e.code).send({
//                 message : e.message
//             });
//         }
//     }, token);
// };

// const verifyToken1 = (req, res, next) => {
//     const token = req.headers.authorization;

//     if (!token) {
//         return res.status(403).send({
//             message : "A token is required for authentication"
//         });
//     }
//     try {

//       const decoded = jwt.accessTokenDecode(function (e) {
//       req.user = decoded;

//         if (e.status) {
//             req.user = e.data;
//             return next();
//         } else {
//             return res.status(e.code).send({
//                 message : e.message
//             });
//         }
//       });
//     } catch (err) {
//       return res.status(401).send({
//         status:401,
//         message: "Invalid Token"
//       });
//     }
//     return next();
//   };

module.exports = verifyToken;