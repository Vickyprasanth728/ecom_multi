require('dotenv').config();
const dbConfig = require("../config/db.config.js");

const Sequelize = require("sequelize");
  const sequelize = new Sequelize(
    dbConfig.DB_DATABASE,
    dbConfig.DB_USER,
    dbConfig.DB_PASS, {
    host: dbConfig.DB_HOST,
    dialect: "mysql",
    operatorsAliases: 0,
  
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  },
  );
  

// const sequelize = new Sequelize(
//   dbConfig.databases["Database3"].DB_DATABASE3,
//   dbConfig.databases.Database1.DB_USER1,
//   dbConfig.databases.Database1.DB_PASS1, {
//   host: dbConfig.databases.Database1.DB_HOST1,
//   // host: dbConfig.DB_HOST,
//   dialect: dbConfig.databases.Database1.DB_DIALECT,
//   // dialect: "mysql",
//   operatorsAliases: 0,

//   pool: {
//     max: 5,
//     min: 0,
//     acquire: 30000,
//     idle: 10000
//   }
// });

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// This model is required. Please don't delete.
db.tokens = require("./tokens.model.js")(sequelize, Sequelize);
//---------
db.users = require("./users.model.js")(sequelize, Sequelize);
db.posts = require("./posts.model.js")(sequelize, Sequelize);
db.comments = require("./comments.model.js")(sequelize, Sequelize);


db.organization = require("./organization.model.js")(sequelize, Sequelize);
db.country = require("./country.model.js")(sequelize, Sequelize);
db.state = require("./state.model.js")(sequelize, Sequelize);
db.city = require("./city.model.js")(sequelize, Sequelize);
db.currency = require("./currency.model.js")(sequelize, Sequelize);
db.language = require("./language.model.js")(sequelize, Sequelize);
db.translations = require("./translation.model.js")(sequelize, Sequelize);
db.masters = require("./masters.model.js")(sequelize, Sequelize);
db.subscription = require("./subscription.model.js")(sequelize, Sequelize);
db.client_subscription = require("./clientSubscription.model.js")(sequelize, Sequelize);
db.modules = require("./modules.model.js")(sequelize, Sequelize);
db.roles = require("./roles.model.js")(sequelize, Sequelize);
db.support_ticket = require("./supportTicket.model.js")(sequelize, Sequelize);
db.settings = require("./settings.model.js")(sequelize, Sequelize);
db.business_settings = require("./businessSettings.model.js")(sequelize, Sequelize);
db.user_timeline = require("./userTimeline.model.js")(sequelize, Sequelize);
db.templates = require("./template.model.js")(sequelize, Sequelize);
db.source = require("./source.model.js")(sequelize, Sequelize);
db.theme = require("./themeSettings.model.js")(sequelize, Sequelize);

db.state.belongsTo(db.country, {foreignKey: 'country_id'});
db.country.hasMany(db.state, {foreignKey: 'country_id'});


db.city.belongsTo(db.country, {foreignKey: 'country_id'});
db.city.belongsTo(db.state, {foreignKey: 'state_id'});  

db.country.hasMany(db.city, {foreignKey: 'country_id'});
db.state.hasMany(db.city, {foreignKey: 'state_id'});
db.city.belongsTo(db.country, {foreignKey: 'id'});
db.city.belongsTo(db.state, {foreignKey: 'id'});

// db.support_ticket.belongsTo(db.masters, {foreignKey: 'priority'});
// db.support_ticket.belongsTo(db.masters, {foreignKey: 'ticket_status'});

db.support_ticket.belongsTo(db.masters,  {foreignKey: 'priority', as: 'priority_status'});
db.support_ticket.belongsTo(db.masters,  {foreignKey: 'ticket_status', as: 'ticket',});
db.support_ticket.belongsTo(db.organization,  {foreignKey: 'org_id', as: 'org_name',});


db.organization.hasMany(db.users,  {foreignKey: 'org_id', as: 'user',});
db.organization.hasMany(db.client_subscription,  {foreignKey: 'org_id', as: 'client_subscription',});
db.organization.belongsTo(db.city,  {foreignKey: 'city',  as: 'city_name',});
db.organization.belongsTo(db.state,  {foreignKey: 'state',  as: 'state_name',});
db.organization.belongsTo(db.country,  {foreignKey: 'country',  as: 'country_name',});
db.organization.belongsTo(db.currency,  {foreignKey: 'currency',  as: 'currency_name',});
// db.city.belongsTo(db.country, {foreignKey: 'country_id'});
// db.city.belongsTo(db.state, {foreignKey: 'state_id'});
db.client_subscription.belongsTo(db.subscription, {foreignKey: 'subscription_id'});
db.client_subscription.belongsTo(db.organization, {foreignKey: 'org_id'});

/**
Create relationship
 - Posts have many comments
 - Comment have only one post
*/
db.posts.hasMany(db.comments, { as: "comments" });
db.comments.belongsTo(db.posts, {
  foreignKey: "postId",
  as: "posts",
});
// ----------------------------

module.exports = db;