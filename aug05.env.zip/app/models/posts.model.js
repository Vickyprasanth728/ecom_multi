module.exports = (sequelize, Sequelize) => {
  return sequelize.define("posts", {
    title: {
      type: Sequelize.STRING,
      allowNull: false,
      validate: {
        notNull: { args: true, msg: "You must enter a title" },
      }
    },
    description: {
      type: Sequelize.STRING
    },
  });
};