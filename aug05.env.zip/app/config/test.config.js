// Enable testing mode mean actual Gateway will not work
const test_ = {
    phone_otp_verification: true, // true or false
    email_reset_password: false // true or false
};

module.exports = test_;