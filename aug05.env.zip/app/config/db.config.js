module.exports = {
    DB_HOST: "localhost",
    DB_USER: "root",
    DB_PASS: "",
    DB_DATABASE: "listez_db",
};

// exports.databaseAuth = (req, res) => {
//     console.log("Config DB");
  
//     const org_id = 1
//     // return (
//     //   module.exports = {
//     //     DB_HOST: "localhost",
//     //     DB_USER: "root",
//     //     DB_PASS: "",
//     //     DB_DATABASE: `listez_db${org_id}`,
//     //   }
//     // )
  
//     if(org_id == 1) {
//       return(
//         module.exports = {
//           DB_HOST: "localhost",
//           DB_USER: "root",
//           DB_PASS: "",
//           DB_DATABASE: `listez_db`,
//         }
//       )
//     }
//     else if(org_id == 2) {
//       return(
//         module.exports = {
//           DB_HOST: "localhost",
//           DB_USER: "root",
//           DB_PASS: "",
//           DB_DATABASE: `listez_db2`,
//         }
//       )
//     }
//     else if(org_id == 3) {
//       return(
//         module.exports = {
//           DB_HOST: "localhost",
//           DB_USER: "root",
//           DB_PASS: "",
//           DB_DATABASE: `listez_db3`,
//         }
//       )
//     }
//   }