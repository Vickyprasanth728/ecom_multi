import React, { Fragment, useState, useRef, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import data from "../../assets/data/listUser";
// import Datatable from "../common/datatable";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { 
	Card, 
	CardBody, 
	CardHeader, 
	Container, 	
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader, 
	Form,
	Label,
	FormGroup,
	Input,
	Button
} from "reactstrap";
import {getUsers, sendNewsletterMail } from '../newsletter/core/_requests';
import logo from "../../assets/icons/no_image.jpg";

const initialValues = {
    "id" : "",
	"email":"",
}

const NewsletterPage = () => {
	const NewsletteSchema = Yup.object().shape({
    })

    const [allUsers, setAllUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [dataBinded, setDataBinded] = useState(false);

	const UsersList = async () => {
        const UsersResponse = await getUsers()
        console.log('All Users List');
        console.log(UsersResponse.Data);
        setAllUsers(UsersResponse.Data);
    }

	const formik = useFormik({
        initialValues,
        validationSchema: NewsletteSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {
            
            var formData = new FormData();

			const body = {
                "id" : values.id,
                "email" : values.email,
            }

            formData.append("id" , values.id);
            
            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }
                
            console.log('lead form body');
            console.log(formData);
            if(!dataBinded){
    
				const sendMailData = await sendNewsletterMail(body);
            
                if(sendMailData != null){
                    setLoading(false);
                    document.getElementById('kt_team_close')?.click();
                }
            } else {

            }
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)
        }
        }
    })

	useEffect(() => {
        UsersList();
    }, []);

	return (
		<Fragment>
			<Breadcrumb title="Newsletter" parent="Users" />
			<Container fluid={true}>
				<Card>
					<CardHeader>
						<h5>Newsletter</h5>
					</CardHeader>
					<CardBody>
						<Form className="needs-validation user-add"noValidate onSubmit={formik.handleSubmit}>
							{/* <FormGroup className="row">
								<Label className="col-xl-3 col-md-4">
									<span>*</span> Name
								</Label>
								<div className="col-xl-8 col-md-7">
									<Input
										className="form-control"
										id="validationCustom0"
										type="text"
										required=""
										placeholder="Name"
										{...formik.getFieldProps('name')}
									/>
									{formik.touched.name && formik.errors.name && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.name}</span>
											</div>
										</div>
									)}
								</div>
							</FormGroup> */}
							<FormGroup className="row">
								<Label className="col-xl-3 col-md-4">
									<span>*</span> Email
								</Label>
								<div className="col-xl-8 col-md-7">
								<select className="form-control mt-2 form-select" {...formik.getFieldProps('email')} name="email" id="email"
									data-selected="" data-live-search="true" required>
									<option>-- Email List -- </option>
									{allUsers.map((usersValues, i) => {
										return (
											<option selected={i == 0 ? true : false} value={usersValues.email} key={i}>{usersValues.email}</option>
										)
									})}
								</select>
									{formik.touched.email && formik.errors.email && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.email}</span>
											</div>
										</div>
									)}
								</div>
							</FormGroup>
							<FormGroup className="row">
								<Label className="col-xl-3 col-md-4">
									<span>*</span> Newsletter Content
								</Label>
								<div className="col-xl-8 col-md-7">
									<textarea
										className="form-control"
										id="validationCustom2"
										type="text"
										required=""
										placeholder="Newsletter Content"
										{...formik.getFieldProps('content')}
									></textarea>
									{formik.touched.email && formik.errors.email && (
										<div className='fv-plugins-message-container'>
											<div className='fv-help-block'>
												<span role='alert' className='text-danger'>{formik.errors.email}</span>
											</div>
										</div>
									)}
								</div>
							</FormGroup>
							<div className="pull-right">
								<Button type="submit" color="primary">
									Save
								</Button>
							</div>
						</Form>	
					</CardBody>
				</Card>
			</Container>
		</Fragment>
	);
};

export default NewsletterPage;
