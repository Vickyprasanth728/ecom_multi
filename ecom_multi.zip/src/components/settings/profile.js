import React, { Fragment, useState, useEffect } from "react";
import designer from "../../assets/images/dashboard/designer.jpg";
import TabsetProfile from "./tabset-profile";
import Breadcrumb from "../common/breadcrumb";
// import { Card, CardBody, Col, Container, Media, Row, Button } from "reactstrap";
import {getProfile, saveProfile, getProfileEdit, updateProfile, deleteProfile } from './core/_requests';
import { useFormik } from 'formik';
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
	Table,
	Media,
} from "reactstrap";
import 'react-toastify/dist/ReactToastify.css';
import logo from "../../assets/icons/no_image.jpg";
import * as Yup from 'yup';

const initialValues = {
    "id" : "",
    "referred_by" : "",
    "provider_id" : "",
    "user_type" : "",
    "name" : "",
    "email" : "",
    "email_verified_at" : "",
    "verification_code" : "",
    "new_email_verificiation_code" : "",
    "password" : "" ,
    "remember_token" : "" ,
    "device_token" : "",
    "avatar" : ""  ,
    "avatar_original" : "",
    "address" : "",
    "country" : "",
    "state" : "",
    "city" : "",
    "postal_code" : "" ,
    "phone" : "",
    "balance" : "" ,
    "banned" : "" ,
    "referral_code" : "",
    "customer_package_id" : "" ,
    "remaining_uploads" : "",
    "role_id":""
}


const Profile = () => {

	const ProfileSchema = Yup.object().shape({
        // name: Yup.string().required('* Name is required'),
        // email: Yup.string()
        //     .email('Wrong email format')
        //     .min(3, 'Minimum 3 characters')
        //     .max(50, 'Maximum 50 characters')
        //     .required('Email is required'),
        // password: Yup.string().required('* Password is required'),
        // phone: Yup.string()
        // .min(10, '* Minimum 10 symbols')
        // .max(10, '* Maximum 10 symbols'),
    })

	const [allProfile, setAllProfile] = useState([]);
	const [allEditProfile, setEditProfile] = useState([]);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);

    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);

	
	const ProfileList = async () => {
        const ProfileResponse = await getProfile()
        console.log('Profile List');
        console.log(ProfileResponse.Data);
        setAllProfile(ProfileResponse.Data);
    }

	var userId = localStorage.getItem('userId')
	console.log("oo",userId)

	const formik = useFormik({
        initialValues,
        validationSchema: ProfileSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {


            var formData = new FormData();

            formData.append("id" , values.id);
            formData.append("referred_by" , values.referred_by);
            formData.append("provider_id" , values.provider_id);
            formData.append("user_type" , values.user_type);
            formData.append('name', values.name);
            formData.append('email', values.email);
            formData.append('email_verified_at', values.email_verified_at);
            formData.append('verification_code', values.verification_code);
            formData.append('new_email_verificiation_code', values.new_email_verificiation_code);
            formData.append('password', values.password);
            formData.append('remember_token', values.remember_token);
            formData.append('device_token', values.device_token);
            formData.append('avatar', values.avatar);
            formData.append('avatar_original', values.avatar_original);
            formData.append('address', values.address);
            formData.append('country', values.country);
            formData.append('state', values.state);
            formData.append('city', values.city);
            formData.append('postal_code', values.postal_code);
            formData.append('phone', values.phone);
            formData.append('balance', values.balance || "0");
            formData.append('banned', values.banned || "0");
            formData.append('referral_code', values.referral_code);
            formData.append('customer_package_id', values.customer_package_id);
            formData.append('remaining_uploads', values.remaining_uploads || "0");
            
            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }
                
            console.log('lead form body');
            console.log(formData);
            if(!dataBinded){
                const saveCustomerData = await saveProfile(formData, headers);
            
                if(saveCustomerData != null){
                    setLoading(false);
                    document.getElementById('kt_team_close')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    ProfileList();
                }

            } else {
                const updateCustomerData = await updateProfile(selectedId, formData);

                if (updateCustomerData != null) {
                    setLoading(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    setDataBinded(false);
                    ProfileList();
                    resetForm();
                }
            }
            ProfileList();
            // onCloseModal();
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)

            // toast.error('Email Already Exits', {
            //     position: "bottom-right",
            //     autoClose: 5000,
            //     hideProgressBar: false,
            //     closeOnClick: true,
            //     pauseOnHover: true,
            //     draggable: true,
            //     progress: undefined,
            //     theme: "light",
            // });
        }
          ProfileList();
          resetForm();
        //   setEditOpen(false);
        }
    })

	const EditProfile = async (id) => {
        setSelectedId(id);
        const allProfileEdit = await getProfileEdit(userId)
        setEditProfile(allProfileEdit.Data);
		console.log("profile id" ,allProfileEdit.Data);
		formik.setFieldValue('name', allProfileEdit.Data.name);
        formik.setFieldValue('email', allProfileEdit.Data.email);
        formik.setFieldValue('password', allProfileEdit.Data.password);
        formik.setFieldValue('address', allProfileEdit.Data.address);
        formik.setFieldValue('phone', allProfileEdit.Data.phone);
        formik.setFieldValue('city', allProfileEdit.Data.city);
        setDataBinded(true);
		console.log("profile id" ,allProfileEdit.Data);
		// onEditModal();
    }

	useEffect(() => {
		ProfileList();
		EditProfile();
		}, []);

	return (
		<Fragment>
			<button type="button" className="d-none" id="sampleTest3" onClick={()=>EditProfile()}></button>
			<Breadcrumb title="Profile" parent="Settings" />
			<Container fluid={true}>
				<Row>
					<Col xl="4">
						<Card>
							<CardBody>
								<div className="profile-details text-center">
									{/* <img
										src={designer}
										alt=""
										className="img-fluid img-90 rounded-circle blur-up lazyloaded"
									/> */}
									
									{/* <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + allEditProfile.id + '/' + allEditProfile.avatar} className="img-fluid rounded-circle blur-up" height={100} width={150} alt='' /> */}
									{allEditProfile.avatar !== null ? 
										<div className="file-preview box sm">
											<img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + allEditProfile.id + '/' + allEditProfile.avatar} className="img-100 rounded-circle blur-up shadow" height={100} width={150} alt='' />
										</div> :
										<img
										src={logo}
										height={100} width={150}
										alt=""
										className="img-100 rounded-circle blur-up lazyloaded"
									/>
									}
									<h5 className="f-w-600 f-16 mb-0">{allEditProfile.name}</h5>
									<span>{allEditProfile.email}</span>
									<div className="social">
										<div className="form-group btn-showcase">
											<Button color="btn social-btn btn-fb d-inline-block">
												{" "}
												<i className="fa fa-facebook"></i>
											</Button>
											<Button color="btn social-btn btn-twitter d-inline-block">
												<i className="fa fa-google"></i>
											</Button>
											<Button color="btn social-btn btn-google d-inline-block me-0">
												<i className="fa fa-twitter"></i>
											</Button>
										</div>
									</div>
								</div>
								<hr />
								<div className="project-status">
									<h5 className="f-w-600 f-16">Employee Status</h5>
									<Media>
										<Media body>
											<h6>
												Performance <span className="pull-right">80%</span>
											</h6>
											<div className="progress lg-progress-bar">
												<div
													className="progress-bar bg-primary"
													role="progressbar"
													style={{ width: "90%" }}
													aria-valuenow="25"
													aria-valuemin="0"
													aria-valuemax="100"
												></div>
											</div>
										</Media>
									</Media>
									<Media>
										<Media body>
											<h6>
												Overtime <span className="pull-right">60%</span>
											</h6>
											<div className="progress lg-progress-bar">
												<div
													className="progress-bar bg-secondary"
													role="progressbar"
													style={{ width: "60%" }}
													aria-valuenow="25"
													aria-valuemin="0"
													aria-valuemax="100"
												></div>
											</div>
										</Media>
									</Media>
									<Media>
										<Media body>
											<h6>
												Leaves taken <span className="pull-right">50%</span>
											</h6>
											<div className="progress lg-progress-bar">
												<div
													className="progress-bar bg-danger"
													role="progressbar"
													style={{ width: "50%" }}
													aria-valuenow="25"
													aria-valuemin="0"
													aria-valuemax="100"
												></div>
											</div>
										</Media>
									</Media>
								</div>
							</CardBody>
						</Card>
					</Col>
					<Col xl="8">
						<Card className="profile-card">
							<CardBody>
								<TabsetProfile />
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
		</Fragment>
	);
};

export default Profile;
