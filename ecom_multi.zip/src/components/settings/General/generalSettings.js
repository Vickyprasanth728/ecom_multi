import React, { Fragment, useState,useRef, useEffect } from "react";
import Breadcrumb from "../../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
// import Datatable from "../../common/datatable";
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import {getBSList, saveBS, deleteBS,getBSEdit, updateBS } from '../General/core/_requests';
import one from "../../../assets/images/pro3/1.jpg";
import logo from "../../../assets/icons/no_image.jpg";

import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "header_logo": "",
    "site_name": "",
    "id": "",
    "type": "",
    "value": "",
    "lang": "",
  }

const GeneralSettingPage = () => {

    const BSSchema = Yup.object().shape({
        // header_logo: Yup.string().required('* Header logo is required'),
    })

    var userId = localStorage.getItem('userId')
	console.log("User ID",userId)

    const [allBSList, setBSList] = useState([]);
    const [allBSEdit, setBSEdit] = useState([]);
    const [selectedId, setSelectedId] = useState([]);
    const [dataBinded, setDataBinded] = useState(false);
    const viewLogo = useRef(null);
    const [loading, setLoading] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const [uploadImagePreview, setuploadImagePreview] = useState(null);
    const viewUpload = useRef(null);
    const [UploadImage, setUploadImage] = useState(null);

    const [faviconImagePreview, setFaviconImagePreview] = useState(null);
    const viewFavicon = useRef(null);
    const [FaviconImage, setFaviconImage] = useState(null);

    const BSList = async () => {
        const BSResponse = await getBSList()
        setBSList(BSResponse.Data);
        document.getElementById('bsId')?.click()
    }

    console.log("hg",UploadImage)
    const formik = useFormik({
        initialValues,
        validationSchema: BSSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {                 

                var formData = new FormData();
                formData.append('lang', values.lang);

                const headerType = UploadImage
                const faviconType = FaviconImage
                const siteNameType = values.site_name

                if (headerType) {
                    var formData = new FormData();

                    // formData.append('id',  id.toString());
                    // formData.append('type', allBSEdit.type);
                    // formData.append('value', UploadImage);
                   
                    // formData.append('type', values.type);
                    // formData.append('value', UploadImage);
    
                    // formData.append('type', values.type);
                    // formData.append('value', values.site_name);
    
                    formData.append('value', UploadImage);
                    formData.append('lang', values.lang);
            
                    const updateUserData = await updateBS('header_logo', formData)
            
                    console.log('updateUserData');
                    console.log(updateUserData);
                    if(updateUserData!= null){
                        setLoading(false)
                        document.getElementById('kt_useredit_close')?.click();
                        var toastEl = document.getElementById('myToastUpdate');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                        console.log("check");
                    } 
                }  else if (siteNameType) {
                    var formData = new FormData();

                    formData.append('value', values.site_name);
                    formData.append('lang', values.lang);

                    const updateUserData1 = await updateBS('site_name', formData)

                    console.log('updateUserData1', updateUserData1);
                    if(updateUserData1!= null){
                        setLoading(false)
                        document.getElementById('kt_useredit_close')?.click();
                        console.log("site_name");
                    } 
                }
                else if (faviconType) {
                    var formData = new FormData();

                    formData.append('value', FaviconImage);
                    formData.append('lang', values.lang);

                    const updateUserData2 = await updateBS('site_icon', formData)

                    console.log('updateUserData2', updateUserData2);
                    if(updateUserData2!= null){
                        setLoading(false)
                        document.getElementById('kt_useredit_close')?.click();
                        console.log("site_icon");
                    } 
                }

            } catch (error) {
                console.error(error)
                setStatus('The color details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
            document.getElementById('bsId')?.click()
            document.getElementById('headerID')?.click()
            document.getElementById('favicon1')?.click()
            removeUpload();
        }
    })

    // const handleUploadPreview = (e) => {
    //     let image_as_base64 = URL.createObjectURL(e.target.files[0])
    //     let image_as_files = e.target.files[0];
    
    //     let fields = viewUpload.current?.value.split(".");
    //     console.log('fie',viewUpload)
        
    //     const s =  image_as_files.name.split(".");
    //     console.log("sssssssss",  s);

    //     const d = s[1];
    //     console.log("ddddddd", d);
    
    //     // let fileType = s[s.length - 1];
    //     console.log('ty',d[d.length - 1])
    //     console.log('ss',s[s.length - 1])
    
    //     if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf' || fileType == 'png') {
    //         setuploadImagePreview(image_as_base64);
    //         setUploadImage(image_as_files.name);
    //         console.log("jj",image_as_files.name)
    //     } else {
    //         setuploadImagePreview(null);
    //         setUploadImage(null);
    //         console.log("jj1")

    //         if (viewUpload.current != null) {
    //             viewUpload.current.value = "";
    //         }
    //     }
    //     console.log(viewUpload.current?.value);
    //     console.log(image_as_files);
    //     console.log(fileType);
    // }

    const handleUploadPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewUpload.current?.value.split(".");

        let fileType = fields [fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
            setuploadImagePreview(image_as_base64);
            setUploadImage(image_as_files);
        } else {
            setuploadImagePreview(null);
            setUploadImage(null);
            if (viewUpload.current != null) {
                viewUpload.current.value = "";
            }
        }
        console.log(viewUpload.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }

    const handleFaviconPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewFavicon.current?.value.split(".");

        let fileType = fields [fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
            setFaviconImagePreview(image_as_base64);
            setFaviconImage(image_as_files);
        } else {
            setFaviconImagePreview(null);
            setFaviconImage(null);
            if (viewFavicon.current != null) {
                viewFavicon.current.value = "";
            }
        }
        console.log(viewFavicon.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }
  
    const removeUpload = () => {
        console.log(viewUpload.current?.value);
        if (viewUpload.current != null) {
            setuploadImagePreview(null);
            setUploadImage(null);
            viewUpload.current.value = "";
        }
    }
    const removeFavicon = () => {
        console.log(viewFavicon.current?.value);
        if (viewFavicon.current != null) {
            setFaviconImagePreview(null);
            setFaviconImage(null);
            viewFavicon.current.value = "";
        }
    }

    const EditBS = async (type) => {
        setSelectedId(type);

        const BSEditResponse = await getBSEdit(type);
        setBSEdit(BSEditResponse.Data);
        
        console.log("Type ID", BSEditResponse.Data.type);
        setDataBinded(true);
        formik.setFieldValue('id', BSEditResponse.Data.id);
        formik.setFieldValue('type', BSEditResponse.Data.type);
        formik.setFieldValue('value', BSEditResponse.Data.value);
    }

    const clearForm = () => {
        formik.resetForm();
        setDataBinded(false);
    }

    const onDelete = async (id) => {
        console.log(id);
        await deleteBS(id);
        BSList();
        clearForm()
      }

    function getFaviconEl() {
        return document.getElementById("favicon");
    }

    const handleGoogle = () => {
        const favicon = getFaviconEl(); // Accessing favicon element
        favicon.href = "https://www.google.com/favicon.ico";
        console.log("f1", favicon);
    };

    const handleYoutube = () => {
        const favicon = getFaviconEl();
        favicon.href = "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico";
        console.log("f2", favicon);
    };

    const faviconLogo = () => {
        <div>
            <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/setting/values/' + allBSEdit.type + '/' + allBSEdit.value} className="mx-auto d-block blur-up lazyloaded" height={60} width={150} alt='' />
        </div>
    }

    useEffect(() => {
        BSList();
        // handleYoutube();
    }, []);
    
	return (
		<Fragment>
			<Breadcrumb title="General Settings" parent="Brands" />
            <button onClick={(e) => EditBS("header_logo")} id="headerID" className='d-none'></button>
            {/* <button onClick={(e) => EditBS("site_name")} id="bsId" className='d-none'></button> */}
            {/* <link rel="shortcut icon" id="favicon" href="%PUBLIC_URL%/favicon.ico"/> */}
            <div className="App">
                <button className="btn d-none" onClick={handleGoogle}></button>
                <button className="btn d-none" onClick={handleYoutube}></button>
            </div>
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card className="container container-fluid">
							<CardHeader>
                                <section className="container container-fluid mx-2">
                                    <h5>Settings</h5>
                                </section>
							</CardHeader>
							<CardBody>
								  <section className="container container-fluid">
                                        {/* <div className='card p-6 mb-4'>
                                            <div className='row align-items-center'>
                                                <div className='col-auto'>
                                                    <h3 className="text-gray-800"> Website Header</h3>
                                                </div>
                                            </div>
                                        </div> */}

                                        <div className='card p-6'>
                                        <Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className='row p-2'>
                                                <label className='col-lg-4 col-form-label fw-bold mb-2'> Header Logo</label>
                                                <div className="col-lg-8">
                                                    <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
                                                        <input type="file" className='form-control' name="header_logo" ref={viewUpload} onChange={handleUploadPreview} />
                                                        {/* <input type="file" className='form-control' {...formik.getFieldProps('header_logo')}  /> */}
                                                    </div>
                                                    <div className="file-preview box sm d-flex justify-content-start align-items-center mt-4 mx-4">
                                                        {uploadImagePreview != null && (
                                                            <div className='profile_preview position-relative image-input image-input-outline'>
                                                                <img src={uploadImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                                <div onClick={removeUpload} className="p-1 mx-1 fa fa-remove text-danger" style={{ fontSize: "30px", cursor: "pointer" }}>
                                                                </div>
                                                            </div>
                                                        )}
                                                        {formik.touched.header_logo && formik.errors.header_logo && (
                                                            <div className='fv-plugins-message-container'>
                                                                <div className='fv-help-block'>
                                                                    <span role='alert' className='text-danger'>{formik.errors.header_logo}</span>
                                                                </div>
                                                            </div>
                                                        )}

                                                        {/* {uploadImagePreview != null ? <div className="file-preview box sm">
                                                                {uploadImagePreview != null && (
                                                                    <div className='profile_preview position-relative image-input image-input-outline'>
                                                                        <img src={uploadImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                                        <div onClick={removeUpload} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
                                                                        
                                                                        </div>
                                                                    </div>
                                                                )}
                                                            </div> : allBSEdit.value == null ? <img src={logo} className="" height={100} width={150} alt='' />  :
                                                                <div className='profile_preview position-relative image-input image-input-outline'>
                                                                    <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/setting/values/' + allBSEdit.type + '/' + allBSEdit.value} className="image-input-wrapper w-100px h-100px shadow" height={100} width={150} alt='' />
                                                                </div> 
                                                            } */}
                                                    </div>
                                                </div>
                                            </div>
                                       
                                            {/* <div className='row p-2'>
                                            <label className='col-lg-4 col-form-label fw-bold mb-2'> Favi-icon Logo</label>
                                                <div className="col-lg-8">
                                                    <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
                                                        <input type="file" className='form-control' name="header_logo" ref={viewFavicon} onChange={handleFaviconPreview}/>
                                                    </div>
                                                    <div className="file-preview box sm d-flex justify-content-start align-items-center mt-4 mx-4">
                                                        {faviconImagePreview != null && (
                                                            <div className='profile_preview position-relative image-input image-input-outline'>
                                                                <img src={faviconImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                                <div onClick={removeFavicon} className="p-1 mx-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
                                                                </div>
                                                            </div>
                                                        )}
                                                    {formik.touched.header_logo && formik.errors.header_logo && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.header_logo}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                    </div>
                                                </div>
                                            </div> */}

                                            <div className='row p-2'>
                                            <label className='col-lg-4 col-form-label fw-bold'> Site Name</label>
                                            <div className="col-lg-8">

												<div className="input-group ">
													<input type="text" className="form-control" placeholder="site_name" {...formik.getFieldProps('site_name')} />
												</div>
												{formik.touched.site_name && formik.errors.site_name && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.site_name}</span>
														</div>
													</div>
												)}
                                                </div>
											</div>

                                       
                                            <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                                <button
                                                    type='submit'
                                                    id='submit_button'
                                                    className='btn btn-primary btn-sm'
                                                    disabled={formik.isSubmitting}
                                                    style={{backgroundColor:'#ffbe57'}}
                                                // onClick={() => alert()}
                                                >
                                                    {!loading && <span className='indicator-label'> Submit
                                                       
                                                    </span>}
                                                    {loading && (
                                                        <span className='indicator-progress '  data-bs-dismiss="modal" style={{ display: 'block' }}>
                                                            Please wait...{''}
                                                            <span className='spinner-border spinner-border-sm align-middle ms-2'  data-bs-dismiss="modal"></span>
                                                        </span>
                                                    )}
                                                </button>
                                            </div>
                                        </Form>
                                       

                                        </div>
                                    </section>
								<div className="clearfix"></div>
								{/* <div id="basicScenario" className="product-physical">
									<Datatable
										myData={allBrands}
										columns={columns}
										// multiSelectOption={false}
										// pageSize={10}
										// pagination={true}
										// class="-striped -highlight"
									/>
			                    <Fragment>
									<DataTable 
										// myData={allBrands}
										// data={allBrands}
										// columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div> */}
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
		</Fragment>
	);
};

export default GeneralSettingPage;
