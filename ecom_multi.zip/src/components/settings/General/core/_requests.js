import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// user api's
export const GET_BUSINESS_SETTINGS_LIST = `${API_URL}/get_business_settings `
export const SAVE_BUSINESS_SETTING = `${API_URL}/save_business_setting `
export const GET_BUSINESS_SETTING_EDIT = `${API_URL}/get_business_setting_id`
export const UPDATE_BUSINESS_SETTING = `${API_URL}/put_business_setting`
export const UPDATE_BUSINESS_SETTING1 = `${API_URL}/put_business_setting`
export const DELETE_BUSINESS_SETTING = `${API_URL}/delete_business_setting`

export function getBSList() {
    return axios.get(GET_BUSINESS_SETTINGS_LIST)
    .then((response => response.data))
}

export function saveBS(postData, headers) {
    return axios.post(SAVE_BUSINESS_SETTING, postData,headers )
    .then((response => response.data))
}

export function getBSEdit(type) {
    return axios.get(GET_BUSINESS_SETTING_EDIT+'/'+type)
    .then((response => response.data))
}

export function updateBS(type ,body) {
    return axios.put(UPDATE_BUSINESS_SETTING+'/'+type, body)
    .then((response => response.data))
}
export function updateBS1(type ,body) {
    return axios.put(UPDATE_BUSINESS_SETTING1+'/'+type, body)
    .then((response => response.data))
}

export function deleteBS(id) {
    return axios.delete(DELETE_BUSINESS_SETTING+'/'+id)
    .then((response => response.data))
  }