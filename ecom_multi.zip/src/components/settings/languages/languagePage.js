import React, { Fragment, useState, useEffect } from "react";
import Breadcrumb from "../../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
// import Datatable from "../../common/datatable";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import { json, Link, useNavigate } from 'react-router-dom';
import { getLanguages, saveLanguage, getLanguageEdit, updateLanguage, deleteLanguage, updateLanguageStatus} from "./core/_request";
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "id": "",
    "name": "",
    "code": "",
    "app_lang_code": "",
    "rtl": "",
    "status": "",
}

const LanguagePage = () => {

    const LanguageSchema = Yup.object().shape({
        name: Yup.string()
			.min(3, 'Minimum 3 characters')
            .max(50, 'Maximum 50 characters')
			.required('* Name is required'),
        code: Yup.string().required('* Code is required'),
        app_lang_code: Yup.string().required('* App Lang Code is required'),
    })

	const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);
	const [toggle, setToggle] = useState(false);
    const [allLanguages, setAllLanguages] = useState([{}]);
    const [LanguageEdit, setLanguageEdit] = useState([]);
    const [loading, setLoading] = useState(false);
    const [dataBinded, setDataBinded] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedId, setSelectedId] = useState('');


	// const LanguageList = async () => {
	//   const LanguageResponse = await getLanguages()
	//   console.log('All Languages');
	//   console.log(LanguageResponse.Data);
	//   setAllLanguages(LanguageResponse.Data);
	// }

	const LanguageList = async () => {
	  const LanguageResponse = await getLanguages()
	  console.log('All Languages', LanguageResponse.Data);

		let new_array = [];
		for(let i=0; i<LanguageResponse.Data.length;i++) {
			let cur_obj = {
				...LanguageResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllLanguages(new_array);
		console.log('New Array', new_array);
		console.log('Language Response', LanguageResponse.Data);
	}

	const notify = () => toast("Wow so easy!")

	const EditStatus = async (selectedId) => {
        // setSelectedId(selectedId);
        // const body = {
        //     "status": toggle ? 0 : 1,
        // }

		const body = {
            "status": toggle ? '0' : '1' ,
        }

        const updateUserData = await updateLanguageStatus(selectedId, body);
        console.log(updateUserData);
        setDataBinded(true);
		LanguageList();

		const allLanguageEdit = await getLanguageEdit(selectedId)
        setLanguageEdit(allLanguageEdit.data);

		if (allLanguageEdit.data.status == 1) {
            toast.success('Status "ON" Successfully', {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        } else if (allLanguageEdit.data.status == 0){

            toast.success('Status "OFF" Successfully', {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
            });
        }
    }

	const columns = [
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Name",
			selector: row => row.name,
			sortable: true,
		},
		{
			name: "Code",
			selector: row => row.code,
			sortable: true,
		},
		{
			name: "App Lang Code",
			selector: row => row.app_lang_code,
			sortable: true,
		},
		{
			// name: "Status",
			// selector: row => row.status,
			// sortable: true,
			name:"Status",
			cell: (row, index) => (
				<div>
					{/* <span>
					<div class="form-switch">
					<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" onChange={() => {
						EditStatus(row.id);
						setToggle(!toggle);
					}}/>
					</div>
					</span> */}
					<span>
						{ (row.status == 0) ? 
							<div class="form-switch">
								<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" style={{cursor:"pointer"}} onChange={() => {
									EditStatus(row.id);
									setToggle(!toggle);
								}}/> 
							</div>
								: 
								<div class="form-switch">
								<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" checked style={{cursor:"pointer"}} onChange={() => {
									EditStatus(row.id);
									setToggle(!toggle);
								}}/>
							</div>
						}
					</span>
				</div>
			)
		},
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					<span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => EditLanguage(row.id)}
						>
						</button>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
						onClick={() => DeleteLanguage(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

	const onDeleteModal = () => {
		setDeleteOpen(true);
	};

	const DeleteLanguage = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }

	const onOpenModal = () => {
		setOpen(true);
        formik.resetForm();
		allClear();
	};

	// const onCloseModal = () => {
	// 	setOpen(false);
	// };

    const formik = useFormik({
        initialValues,
        validationSchema: LanguageSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                const body = {
                    "name": values.name,
                    "code": values.code,
                    "app_lang_code": values.app_lang_code,
                    "rtl": values.rtl || "0",
                    "status": values.status || "0",
                }

                console.log('lead form body');
                if (!dataBinded) {
                    const LanguageData = await saveLanguage(body);

                    if (LanguageData != null) {
                        setLoading(false);
                        document.getElementById('kt_team_close')?.click();
                        var toastEl = document.getElementById('myToastAdd');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                        resetForm();
                        LanguageList();
                        clearForm();
                    }
                } else {
                    const updateLanguageData = await updateLanguage(selectedId, body);

                    if (updateLanguageData != null) {
                        setLoading(false);
                        var toastEl = document.getElementById('myToastUpdate');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                        resetForm();
                        setDataBinded(false);
                        LanguageList();
                        clearForm();
						setEditOpen(false);
                    }
                }
                LanguageList();
            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
			setOpen(false);
			setEditOpen(false);
			LanguageList();
        }
    })

	const EditLanguage = async (id) => {
        setSelectedId(id);
        const allLanguageEdit = await getLanguageEdit(id)
        setLanguageEdit(allLanguageEdit.data);
        setDataBinded(true);
        formik.setFieldValue('name', allLanguageEdit.data.name);
        formik.setFieldValue('code', allLanguageEdit.data.code);
        formik.setFieldValue('app_lang_code', allLanguageEdit.data.app_lang_code);
        formik.setFieldValue('rtl', allLanguageEdit.data.rtl);
        formik.setFieldValue('status', allLanguageEdit.data.status);
		onEditModal();
    }

	const onEditModal = () => {
		setEditOpen(true);
	};

	const onCloseModal = () => {
		setEditOpen(false);
		setOpen(false);
	};

	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
		LanguageList();
	};

    const clearForm = () => {
        formik.resetForm();
        setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
    }

	const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
    }
    
    const onDelete = async (id) => {
        console.log(id);
        await deleteLanguage(id);
        LanguageList();
    }

	useEffect(() => {
        LanguageList();
      }, []);

	return (
		<Fragment>
            <ToastContainer/>

			<Breadcrumb title="Languages" parent="Physical" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							<CardHeader>
								<h5>Languages</h5>
							</CardHeader>
							<CardBody>
								<div className="btn-popup pull-right">
									<Button
										type="button"
										color="primary"
										onClick={onOpenModal}
										data-toggle="modal"
										data-original-title="test"
										data-target="#exampleModal"
									>
										Add Language
									</Button>
									{/* Save Modal */}
									<Modal isOpen={open} toggle={onCloseModal}>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Add Language
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>

											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
												</div>
												{formik.touched.name && formik.errors.name && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.name}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Code</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Code" {...formik.getFieldProps('code')} />
												</div>
												{formik.touched.code && formik.errors.code && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.code}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">App Language Code</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="App Language Code" {...formik.getFieldProps('app_lang_code')} />
												</div>
												{formik.touched.app_lang_code && formik.errors.app_lang_code && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.app_lang_code}</span>
														</div>
													</div>
												)}
											</div>
											{/* <div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Rtl</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Rtl" {...formik.getFieldProps('rtl')} />
												</div>
												{formik.touched.rtl && formik.errors.rtl && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.rtl}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-4">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Status</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Status" {...formik.getFieldProps('status')} />
												</div>
												{formik.touched.status && formik.errors.status && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.status}</span>
														</div>
													</div>
												)}
											</div> */}
											
															{/* <FormGroup>
													<Label
														htmlFor="recipient-name"
														className="col-form-label"
													>
														Languages Name :
													</Label>
													<Input type="text" className="form-control" />
												</FormGroup> */}

												{/* <FormGroup>
													<Label
														htmlFor="message-text"
														className="col-form-label"
													>
														Category Image :
													</Label>
													<Input
														className="form-control"
														id="validationCustom02"
														type="file"
													/>
												</FormGroup> */}

                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Submit
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
												</div>

											</Form>
										</ModalBody>
										<ModalFooter>
											{/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
										</ModalFooter>
									</Modal>
									{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseModal}>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Language
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>

											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
												</div>
												{formik.touched.name && formik.errors.name && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.name}</span>
														</div>
													</div>
												)}
											</div>
											<div className="form-group mb-0">
												<label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">App Lang Code</label>
												<div className="input-group">
													<input type="text" className="form-control" placeholder="App Lang Code" {...formik.getFieldProps('app_lang_code')} />
												</div>
												{formik.touched.app_lang_code && formik.errors.app_lang_code && (
													<div className='fv-plugins-message-container'>
														<div className='fv-help-block'>
															<span role='alert' className='text-danger'>{formik.errors.app_lang_code}</span>
														</div>
													</div>
												)}
											</div>
                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
													<button
														type='submit'
														id='submit_button'
														className='btn btn-primary text-white mx-2'
														disabled={formik.isSubmitting}
														style={{backgroundColor:'#ffbe57'}}
														// onClick={()=>{toComponentB()}}
														// onClick={() => alert()}
													>
														{!loading && <span className='indicator-label'>Update
														</span>}
														{loading && (
															<span className='indicator-progress' style={{ display: 'block' }}>
																Please wait...{' '}
																<span className='spinner-border spinner-border-sm align-middle ms-2'></span>
															</span>
														)}
													</button>

													<div className='btn btn-danger text-white' onClick={clearForm}> Cancel</div>
												</div>
											</Form>
										</ModalBody>
									</Modal>

									{/* <div>
										<button onClick={notify}>Notify!</button>
										<ToastContainer />
									</div> */}

									{/* Delete Modal */}
									<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
										<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
															<h4>Are you sure want to Delete ? </h4>
															<p className='text-danger'></p>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="clearfix"></div>
								<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={allLanguages}
										multiSelectOption={false}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
									/> */}
								<Fragment>
									<DataTable 
										// myData={allBrands}
										data={allLanguages}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
		</Fragment>
	);
};

export default LanguagePage;
