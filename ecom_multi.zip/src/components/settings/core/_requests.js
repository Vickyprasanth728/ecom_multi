import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Users 
export const GET_PROFILE = `${API_URL}/get_users `
export const SAVE_PROFILE = `${API_URL}/save_user `
export const GET_PROFILE_EDIT = `${API_URL}/get_user_id`
export const UPDATE_PROFILE = `${API_URL}/put_user`
export const DELETE_PROFILE = `${API_URL}/delete_user`

export function getProfile() {
    return axios.get(GET_PROFILE)
    .then((response => response.data))
}

export function saveProfile(postData, headers) {
    return axios.post(SAVE_PROFILE, postData, headers)
    .then((response => response.data))
}

export function getProfileEdit(id) {
    return axios.get(GET_PROFILE_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateProfile(id ,body) {
    return axios.put(UPDATE_PROFILE+'/'+id, body)
    .then((response => response.data))
}

export function deleteProfile(id) {
    return axios.delete(DELETE_PROFILE+'/'+id)
    .then((response => response.data))
}