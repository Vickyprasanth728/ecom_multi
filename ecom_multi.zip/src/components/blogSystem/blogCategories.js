import React, { Fragment, useState, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
// import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
// import Datatable from "../../common/datatable";
import DataTable from "react-data-table-component";
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import {getCategoryBlogs, saveBlogCategory, updateBlogCategory, getBCEdit , deleteBC, updateBrand} from "../blogSystem/core/_requests"
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "category_name": "",
    "slug": "", 
}

const BlogCategoriesList = () => {

    const BlogsSchema = Yup.object().shape({
        category_name: Yup.string().required('* Category Name is required'),
    })

    // var userId = localStorage.getItem('userId')
	// console.log("User ID",userId)

    const [allBlogs, setAllBlogs] = useState([]);
    const [allCategoryBlogs, setAllCategoryBlogs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedId, setSelectedId] = useState('');
    const [blogEdit, setBlogEdit] = useState([]);
    const [dataBinded, setDataBinded] = useState(false);

    const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);

    var userId = localStorage.getItem('userId')
	console.log("User ID",userId)

    // const blogCategoryList = async () => {
    //     const blogCategoryResponse = await getCategoryBlogs()
    //     console.log('All Blogs');
    //     console.log(blogCategoryResponse.Data);
    //     setAllCategoryBlogs(blogCategoryResponse.Data);
    // }

    const blogCategoryList = async () => {
        const blogCategoryResponse = await getCategoryBlogs()
        console.log('All Blogs', blogCategoryResponse.Data);


        let new_array = [];
		for(let i=0; i<blogCategoryResponse.Data.length;i++) {
			let cur_obj = {
				...blogCategoryResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllCategoryBlogs(new_array);
		console.log('New Array', new_array);
		console.log('Blogs Category Response', blogCategoryResponse.Data);
    }
    
    const formik = useFormik({
        initialValues,
        validationSchema: BlogsSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {
              
            const body = {
                "category_name": values.category_name,
                "slug": values.slug,
            }
                
            console.log('lead form body');
            console.log(body);
            if(!dataBinded){
                const saveBlogCategoryData = await saveBlogCategory(body);
            
                if(saveBlogCategoryData != null){
                    setLoading(false);
                    resetForm();
                    blogCategoryList();
            		setOpen(false);
                    document.getElementById('kt_team_close')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                }

            } else {
                const updateBlogCategoryData = await updateBlogCategory(selectedId, body);
            
                if(updateBlogCategoryData != null){
                    setLoading(false);
                    resetForm();
                    blogCategoryList();
                    setDataBinded(false);
		            setEditOpen(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                }
            }
            setEditOpen(false);
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)
          }
          blogCategoryList();
          setEditOpen(false);
          resetForm();
    }})

    const EditBlogCategory = async (id) => {
        setSelectedId(id);
        const blogEdit = await getBCEdit(id)
        setBlogEdit(blogEdit.Data);

        setDataBinded(true);
        formik.setFieldValue('category_name', blogEdit.Data.category_name);
        formik.setFieldValue('slug', blogEdit.Data.slug);
        onEditModal();
    }

	const columns = [
		{
			name: "id",
			selector: row => row.sl_no,
			sortable: true,
		},
		{
			name: "Category Name",
			selector: row => row.category_name,
			sortable: true,
		},
		{
			name:"Actions",
			cell: (row, index) => (
                <div>
                <span>
                    <button
                    className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
                    data-toggle="modal"
                    onClick={() => EditBlogCategory(row.id)}
                    >
                    </button>
                </span>
                <span >
                    <button
                    className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
                    onClick={() => DeleteBlogCategory(row.id)}
                    data-bs-toggle='modal' 
                    data-bs-target={'#delete_confirm_popup452222' + selectedId}
                    >
                    </button>
                </span>
            </div>
			),
		}
	]

	const onDeleteModal = () => {
		setDeleteOpen(true);
	};
	const DeleteBlogCategory = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }
	const onOpenModal = () => {
		setOpen(true);
        allClear();
        formik.resetForm();
	};

	const onEditModal = () => {
		setEditOpen(true);
	};

	const onCloseModal = () => {
		setEditOpen(false);
		setOpen(false);
        formik.resetForm();
	};

	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
		BlogCategoriesList();
	};

    const clearForm = () => {
        formik.resetForm();
        setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
    }
    const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
    }

    const onDelete = async (id) => {
        console.log(id);
        await deleteBC(id);
        blogCategoryList();
        var toastEl = document.getElementById('myToastDelete');
        const bsToast = new Toast(toastEl);
        bsToast.show();
    }

    useEffect(() => {
        blogCategoryList();
    }, []);

	return (
		<Fragment>
			<Breadcrumb title="Blogs" parent="Physical" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card className="container container-fluid shadow">
							<CardHeader>
								<h5>Blog Category List</h5>
							</CardHeader>
							<CardBody>
								<div className="btn-popup pull-right">
									<Button
										type="button"
										color="primary"
										onClick={onOpenModal}
										data-toggle="modal"
										data-original-title="test"
										data-target="#exampleModal"
									>
										Add Blog Category
									</Button>
									{/* Save Modal */}
									<Modal isOpen={open} toggle={onCloseModal}> 
										<ModalHeader toggle={onCloseModal}> 
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Add Blog Category
											</h5>
										</ModalHeader>
										<ModalBody>
											<Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className="row container container-fluid">
                                                <div className="form-group mb-4 col-lg-12 p-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Category Name</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('category_name')} />
                                                    </div>
                                                    {formik.touched.category_name && formik.errors.category_name && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.category_name}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                                <button
                                                    type='submit'
                                                    id='submit_button'
                                                    className='btn btn-primary text-white mx-2'
                                                    disabled={formik.isSubmitting}
                                                    style={{backgroundColor:'#ffbe57'}}
                                                    // onClick={()=>{toComponentB()}}
                                                    // onClick={() => alert()}
                                                >
                                                    {!loading && <span className='indicator-label'>Submit
                                                    </span>}
                                                    {loading && (
                                                        <span className='indicator-progress' style={{ display: 'block' }}>
                                                            Please wait...{' '}
                                                            <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                                        </span>
                                                    )}
                                                </button>

                                                <div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
                                            </div>

											</Form>
										</ModalBody>
										<ModalFooter>
											{/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
										</ModalFooter>
									</Modal>
									{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseModal}>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Blog Category
											</h5>
										</ModalHeader>
										<ModalBody>
                                        <Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className="row container container-fluid">
                                                <div className="form-group mb-4 col-lg-12">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Category Name</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Category Name" {...formik.getFieldProps('category_name')} />
                                                    </div>
                                                    {formik.touched.category_name && formik.errors.category_name && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.category_name}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                                <button
                                                    type='submit'
                                                    id='submit_button'
                                                    className='btn btn-primary text-white mx-2'
                                                    disabled={formik.isSubmitting}
                                                    style={{backgroundColor:'#ffbe57'}}
                                                    // onClick={()=>{toComponentB()}}
                                                    // onClick={() => alert()}
                                                >
                                                    {!loading && <span className='indicator-label'>Update
                                                    </span>}
                                                    {loading && (
                                                        <span className='indicator-progress' style={{ display: 'block' }}>
                                                            Please wait...{' '}
                                                            <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                                        </span>
                                                    )}
                                                </button>

                                                <div className='btn btn-danger text-white' onClick={clearForm} style={{backgroundColor:'#0fb2f7'}}> Cancel</div>
                                            </div>
											</Form>
										</ModalBody>
									</Modal>

									{/* Delete Modal */}
									<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
										<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
															<h4>Are you sure want to Delete ? </h4>
															<p className='text-danger'></p>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal'>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="clearfix"></div>
								<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={allLanguages}
										multiSelectOption={false}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
									/> */}
								<Fragment>
									<DataTable 
										// myData={allBrands}
										data={allCategoryBlogs}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
            <ToastContainer/>
            <div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{backgroundColor: "#027a02"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Blog Categories Saved Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{backgroundColor: "#f7572a"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Blog Categories Updated Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastDelete" style={{backgroundColor: "#d1061b"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Blog Categories Deleted Successfully!
				</div>
			</div>
		</Fragment>
	);
};

export default BlogCategoriesList;
