import React, { Fragment, useState,useRef, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
// import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
// import Datatable from "../../common/datatable";
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { getBlogs, BlogEdit, saveBlog, updateBlogID, deleteBlog, getCategoryBlogs, getUploads, editUpload } from '../blogSystem/core/_requests';
// import one from "../../../assets/images/pro3/1.jpg";
// import logo from "../../../assets/icons/vts-sidebar-logo.png";
// import logo from "../../../assets/icons/no_image.jpg";
import logo from "../../assets/icons/no_image.jpg";

import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
} from "reactstrap";

const initialValues = {
    "id": "",
    "category_id": "",
    "title": "",
    "slug": "",
    "short_description": "",
    "description": "",
    "banner": "",
    "meta_title": "",
    "meta_img": "",
    "meta_description": "",
    "meta_keywords": "",
    "status": "",
    "file_name": "",
    "external_link": "",
}

const BlogList = () => {

    var userId = localStorage.getItem('userId')
	console.log("oo",userId);

    const BlogsSchema = Yup.object().shape({
        title: Yup.string()
        .min(3, 'Minimum 3 characters')
        .max(50, 'Maximum 50 characters')
        .required('* Title is required'),
        category_id: Yup.string()
        .required('* Category is required'),
    })

    const [allBlogs, setAllBlogs] = useState([]);
    const [allCategoryBlogs, setAllCategoryBlogs] = useState([]);
    const [allUploads, setAllUploads] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedId, setSelectedId] = useState('');
    const [blogEdit, setBlogEdit] = useState([]);
    const [dataBinded, setDataBinded] = useState(false);

    const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);
    const [brandEdit, setBrandEdit] = useState([]);

    const [logoImagePreview, setlogoImagePreview] = useState(null);
    const viewLogo = useRef(null);
    const [logoImage, setLogoImage] = useState(null);

    // const blogsList = async () => {
    //     const blogsResponse = await getBlogs()
    //     console.log('All Blogs');
    //     console.log(blogsResponse.Data);
    //     setAllBlogs(blogsResponse.Data);
    // }
    
    const blogsList = async () => {
        const blogsResponse = await getBlogs()
        console.log('All Blogs',blogsResponse.Data);

        let new_array = [];
		for(let i=0; i<blogsResponse.Data.length;i++) {
			let cur_obj = {
				...blogsResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllBlogs(new_array);
		console.log('New Array', new_array);
		console.log('Blogs Response', blogsResponse.Data);
    }

	const UploadList = async () => {
        const uploadResponse = await getUploads()
        console.log('Upload List');
        console.log(uploadResponse.Data);
        setAllUploads(uploadResponse.Data);
    }

    const blogCategoryList = async () => {
        const blogCategoryResponse = await getCategoryBlogs()
        console.log('All Blogs');
        console.log(blogCategoryResponse.Data);
        setAllCategoryBlogs(blogCategoryResponse.Data);
    }

    // const formik = useFormik({
    //     initialValues,
    //     validationSchema: BlogsSchema,
    //     onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
    //         setLoading(true)
    //         try {

    //             const body = {
    //                 "category_id": values.category_id,
    //                 "title": values.title,
    //                 "slug": values.slug,
    //                 "short_description": values.short_description,
    //                 "description": values.description,
    //                 "banner": values.banner,
    //                 "meta_title": values.meta_title,
    //                 "meta_img": values.meta_img,
    //                 "meta_description": values.meta_description,
    //                 "meta_keywords": values.meta_keywords,
    //                 "status": values.status,
    //             }

    //             console.log('lead form body');
    //             console.log(body);
    //             if (!dataBinded) {
    //                 const saveBlogData = await saveBlog(body);

    //                 if (saveBlogData != null) {
    //                     setLoading(false);
    //                     document.getElementById('kt_team_close')?.click();
    //                     // var toastEl = document.getElementById('myToastAdd');
    //                     // const bsToast = new Toast(toastEl);
    //                     // bsToast.show();
    //                     resetForm();
    //                     blogsList();
    //             		setOpen(false);
    //                 }

    //             } else {
    //                 const updateBlogData = await updateBlog(selectedId, body);

    //                 if (updateBlogData != null) {
    //                     setLoading(false);
    //                     // var toastEl = document.getElementById('myToastUpdate');
    //                     // const bsToast = new Toast(toastEl);
    //                     // bsToast.show();
    //                     resetForm();
    //                     blogsList();
    //                     setDataBinded(false);
    //             		setEditOpen(false);
    //                 }
    //             }

    //         } catch (error) {
    //             console.error(error)
    //             setStatus('The registration details is incorrect')
    //             setSubmitting(false)
    //             setLoading(false)
    //         }
    //         blogsList();
    //         resetForm();
    //     }
    // })

    const formik = useFormik({
        initialValues,
        validationSchema: BlogsSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                var formData = new FormData();

                // const body = {
                //     "category_id": values.category_id,
                //     "title": values.title,
                //     "slug": values.slug,
                //     "short_description": values.short_description,
                //     "description": values.description,
                //     "banner": values.banner,
                //     "meta_title": values.meta_title,
                //     "meta_img": values.meta_img,
                //     "meta_description": values.meta_description,
                //     "meta_keywords": values.meta_keywords,
                //     "status": values.status,
                // }

                formData.append('category_id', values.category_id);
                formData.append('title', values.title);
                formData.append('slug', values.slug);
                formData.append('short_description', values.short_description);
                formData.append('description', values.description);
                formData.append('banner', values.banner);
                formData.append('meta_title', values.meta_title);
                formData.append('meta_img', values.meta_img);
                formData.append('meta_description', values.meta_description);
                formData.append('meta_keywords', values.meta_keywords);
                formData.append('status', values.status || "0");
                formData.append('file_name', logoImage);
                formData.append('user_id', userId);

                const headers = {
                    headers: {
                        "Content-type": "multipart/form-data",
                    },
                }

                console.log('lead form body');
                console.log(formData);
                if (!dataBinded) {
                    const BlogData = await saveBlog(formData, headers);

                    if (BlogData != null) {
                        setLoading(false);
                        resetForm();
                        clearForm();
                        blogsList();
                		setOpen(false);
                        document.getElementById('kt_team_close')?.click();
                        var toastEl = document.getElementById('myToastAdd');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                    }
            		setOpen(false);
                } else {
                    const updateBlogData = await updateBlogID(selectedId, formData);
                    console.log("updateBlogData", updateBlogData);
                    if(updateBlogData != null){
                        setLoading(false);
                        resetForm();
                        blogsList();
                        setDataBinded(false);
                        setEditOpen(false);
                        // var toastEl = document.getElementById('myToastUpdate');
                        // const bsToast = new Toast(toastEl);
                        // bsToast.show();
                    }
                }
				blogsList();
            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
			setOpen(false);
     		setEditOpen(false);
			blogsList();
			clearForm();
        }
    })

    const handleLogoPreview = (e) => {
        let image_as_base64 = URL.createObjectURL(e.target.files[0])
        let image_as_files = e.target.files[0];

        let fields = viewLogo.current?.value.split(".");

        let fileType = fields [fields.length - 1];

        if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
            setlogoImagePreview(image_as_base64);
            setLogoImage(image_as_files);
        } else {
            setlogoImagePreview(null);
            setLogoImage(null);
            if (viewLogo.current != null) {
                viewLogo.current.value = "";
            }
        }
        console.log(viewLogo.current?.value);
        console.log(image_as_files);
        console.log(fileType);
    }

    const removeLogo = () => {
        console.log(viewLogo.current?.value);
        if (viewLogo.current != null) {
            setlogoImagePreview(null);
            setLogoImage(null);
            viewLogo.current.value = "";
        }
    }

    const EditBlog = async (id) => {
        setSelectedId(id);
        const blogEdit = await BlogEdit(id)
        setBlogEdit(blogEdit.Data);

        setDataBinded(true);
        formik.setFieldValue('category_id', blogEdit.Data.category_id);
        formik.setFieldValue('title', blogEdit.Data.title);
        // formik.setFieldValue('slug', blogEdit.Data.slug);
        formik.setFieldValue('description', blogEdit.Data.description || null);
        formik.setFieldValue('short_description', blogEdit.Data.short_description || null);
        formik.setFieldValue('banner', blogEdit.Data.banner || null);
        // formik.setFieldValue('meta_title', blogEdit.Data.meta_title || null);
        // formik.setFieldValue('meta_img', blogEdit.Data.meta_img || null);
        // formik.setFieldValue('meta_description', blogEdit.Data.meta_description || null);
        formik.setFieldValue('meta_keywords', blogEdit.Data.meta_keywords || null);
        // formik.setFieldValue('status', blogEdit.Data.status || null);
        onEditModal();
    }

    const onDelete = async (id) => {
        console.log(id);
        await deleteBlog(id);
        blogsList();
        var toastEl = document.getElementById('myToastDelete');
        const bsToast = new Toast(toastEl);
        bsToast.show();
    }

	const onOpenModal = () => {
		setOpen(true);
        allClear();
		removeLogo();
	};
	const onCloseModal = () => {
		setOpen(false);
	};
	const onEditModal = () => {
		setEditOpen(true);
	};
	const onCloseEdit = () => {
		setEditOpen(false);
	};
	const onDeleteModal = () => {
		setDeleteOpen(true);
	};
	const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};

    const BrandDelete = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }
    const clearForm = () => {
        formik.resetForm();
        // setDataBinded(false);
		setOpen(false);
		setEditOpen(false);
		removeLogo();
    }
    const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
		removeLogo();
    }

	const columns = [
		{
			name: "id",
			selector: row => row.sl_no,
			sortable: true,
		},
		{
			name: "Title",
			selector: row => row.title,
			sortable: true,
		},
        {
			name: "Banner",
			selector: row => 
            <div>
                {row.banner_name !== null ? 
                    <div className="file-preview box sm">
                        <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/all_uploads/file_name/' + row.banner + '/' + row.banner_name} className="" height={50} width={70} alt='' />
                    </div>
                     :
                    <img src={logo} className="img-fluid img-60" height={50} width={80} alt='' />
                }
			</div>
		},
		{
			name: "Category",
			selector: row => row.category_name,
			sortable: true,
		},
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					<span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => EditBlog(row.id)}
						>
						</button>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
						onClick={() => BrandDelete(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

    // const data1 = allBrands;

    useEffect(() => {
        blogsList();
        blogCategoryList();
        UploadList();
    }, []);


	return (
		<Fragment>
			<Breadcrumb title="Blogs" parent="Blogs" />
			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card className="shadow">
							<CardHeader>
								<h5>Blog List</h5>
							</CardHeader>
							<CardBody>
								<div className="btn-popup pull-right">
									<Button
										type="button"
										color="primary"
										onClick={onOpenModal}
										data-toggle="modal"
										data-original-title="test"
										data-target="#exampleModal"
									>
										Add Blog
									</Button>
									{/* Save Modal */}
									<Modal isOpen={open} toggle={onCloseModal} className='modal-lg'>
										<ModalHeader toggle={onCloseModal}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Add Blog
											</h5>
										</ModalHeader>
										<ModalBody>
                                        <Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Title</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Title" {...formik.getFieldProps('title')} />
                                                    </div>
                                                    {formik.touched.title && formik.errors.title && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.title}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Category</label>
                                                    <select className="form-control mt-2 form-select" {...formik.getFieldProps('category_id')} name="category_id" id="category_id"
                                                        data-selected="" data-live-search="true" required>
                                                        <option>-- Blog Category Select -- </option>
                                                        {allCategoryBlogs.map((categoriesValues, i) => {
                                                            return (
                                                                <option selected={i == 0 ? true : false} value={categoriesValues.id} key={i}>{categoriesValues.category_name}</option>
                                                            )
                                                        })}
                                                    </select>
                                                    {formik.touched.category_id && formik.errors.category_id && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger mx-2'>{formik.errors.category_id}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            {/* <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Banner</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Banner" {...formik.getFieldProps('banner')} />
                                                    </div>
                                                    {formik.touched.banner && formik.errors.banner && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.banner}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Meta Img</label>
                                                    <div className="input-group">
                                                        <input type="number" className="form-control" placeholder="Meta Img" {...formik.getFieldProps('meta_img')} />
                                                    </div>
                                                    {formik.touched.meta_img && formik.errors.meta_img && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.meta_img}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div> */}
                                            <div className="row">
                                                <div className="form-group mb-0 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Image Upload</label>
                                                    <div className="">
                                                        <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

                                                            {/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
                                                            <input type="file" className='form-control' name="profile_image" ref={viewLogo} onChange={handleLogoPreview} />
                                                        </div>
                                                        <div className="file-preview box sm">
                                                        </div>
                                                    </div>
                                                    <div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
                                                    {logoImagePreview != null && (
                                                        <div className='profile_preview position-relative image-input image-input-outline'>
                                                            <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                            <div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
											                </div>
                                                        </div>
                                                    )}
                                                    </div>
                                                    </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Meta Keywords</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Meta Keywords" {...formik.getFieldProps('meta_keywords')} />
                                                    </div>
                                                    {formik.touched.meta_keywords && formik.errors.meta_keywords && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.meta_keywords}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Description</label>
                                                    <div className="input-group">
                                                        <textarea type="text" className="form-control" placeholder="Description" {...formik.getFieldProps('description')} />
                                                    </div>
                                                    {formik.touched.description && formik.errors.description && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.description}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Short Description</label>
                                                    <div className="input-group">
                                                        <textarea type="text" className="form-control" placeholder="Short Description" {...formik.getFieldProps('short_description')} />
                                                    </div>
                                                    {formik.touched.short_description && formik.errors.short_description && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.short_description}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Meta Title</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Meta Title" {...formik.getFieldProps('meta_title')} />
                                                    </div>
                                                    {formik.touched.meta_title && formik.errors.meta_title && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.meta_title}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Meta description</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Meta description" {...formik.getFieldProps('meta_description')} />
                                                    </div>
                                                    {formik.touched.meta_description && formik.errors.meta_description && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.meta_description}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                                    <button
                                                        type='submit'
                                                        id='submit_button'
                                                        className='btn btn-primary text-white mx-2'
                                                        disabled={formik.isSubmitting}
                                                        style={{backgroundColor:'#ffbe57'}}
                                                        // onClick={()=>{toComponentB()}}
                                                        // onClick={() => alert()}
                                                    >
                                                        {!loading && <span className='indicator-label'> Submit
                                                        </span>}
                                                        {loading && (
                                                            <span className='indicator-progress' style={{ display: 'block' }}>
                                                                Please wait...{' '}
                                                                <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                                            </span>
                                                        )}
                                                    </button>

                                                    <div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
                                                </div>
                                        </Form>
										</ModalBody>
										<ModalFooter>
											{/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
										</ModalFooter>
									</Modal>

									{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseEdit} className='modal-lg'>
										<ModalHeader toggle={onCloseEdit}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Blog
											</h5>
										</ModalHeader>
										<ModalBody>
                                        <Form noValidate onSubmit={formik.handleSubmit}>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Title</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Title" {...formik.getFieldProps('title')} />
                                                    </div>
                                                    {formik.touched.title && formik.errors.title && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.title}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Category</label>
                                                    <select className="form-control mt-2 form-select" {...formik.getFieldProps('category_id')} name="category_id" id="category_id"
                                                        data-selected="" data-live-search="true" required>
                                                        <option>-- Blog Category Select -- </option>
                                                        {allCategoryBlogs.map((categoriesValues, i) => {
                                                            return (
                                                                <option selected={i == 0 ? true : false} value={categoriesValues.id} key={i}>{categoriesValues.category_name}</option>
                                                            )
                                                        })}
                                                    </select>
                                                    {formik.touched.category_id && formik.errors.category_id && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger mx-2'>{formik.errors.category_id}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="form-group mb-0 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Image Upload</label>
                                                    <div className="">
                                                        <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">

                                                            {/* <input type="file" className="form-control file-amount mt-2" name="profile_image" /> */}
                                                            <input type="file" className='form-control' name="profile_image" ref={viewLogo} onChange={handleLogoPreview} />
                                                        </div>
                                                        <div className="file-preview box sm">
                                                        </div>
                                                    </div>
                                                    <div className="file-preview box sm d-flex justify-content-center align-items-center mt-4 mx-4">
                                                        {logoImagePreview != null && (
                                                            <div className='profile_preview position-relative image-input image-input-outline'>
                                                                <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
                                                                <div onClick={removeLogo} className="p-1 fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
											                    </div>
                                                            </div>
                                                        )}
                                                        </div>
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Meta Keywords</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Meta Keywords" {...formik.getFieldProps('meta_keywords')} />
                                                    </div>
                                                    {formik.touched.meta_keywords && formik.errors.meta_keywords && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.meta_keywords}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Description</label>
                                                    <div className="input-group">
                                                        <textarea type="text" className="form-control" placeholder="Description" {...formik.getFieldProps('description')} />
                                                    </div>
                                                    {formik.touched.description && formik.errors.description && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.description}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                          
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Short Description</label>
                                                    <div className="input-group">
                                                        <textarea type="text" className="form-control" placeholder="Short Description" {...formik.getFieldProps('short_description')} />
                                                    </div>
                                                    {formik.touched.short_description && formik.errors.short_description && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.short_description}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            {/* <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Meta Title</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Meta Title" {...formik.getFieldProps('meta_title')} />
                                                    </div>
                                                    {formik.touched.meta_title && formik.errors.meta_title && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.meta_title}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Meta description</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Meta description" {...formik.getFieldProps('meta_description')} />
                                                    </div>
                                                    {formik.touched.meta_description && formik.errors.meta_description && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.meta_description}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div> */}
                                            {/* <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Unit Price</label>
                                                    <div className="input-group">
                                                        <input type="number" className="form-control" placeholder="Unit Price" {...formik.getFieldProps('unit_price')} />
                                                    </div>
                                                    {formik.touched.unit_price && formik.errors.unit_price && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.unit_price}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-3 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Gallery Img</label>
                                                    <div className="col-xl-12 col-sm-7">
                                                        <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
                                                            <input type="file" className='form-control' ref={viewLogo} onChange={handleLogoPreview} />
                                                        </div>
                                                        <div className="file-preview box sm">
                                                            {logoImagePreview != null && (
                                                                <div className='profile_preview position-relative image-input image-input-outline'>
                                                                    <img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={100} />
                                                                    <div onClick={removeLogo} className="p-1 cursor-pointer">
                                                                        
                                                                    </div>
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                    <div className="valid-feedback">Looks good!</div>
                                                </div>
                                            </div> */}
                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                                    <button
                                                        type='submit'
                                                        id='submit_button'
                                                        className='btn btn-primary text-white mx-2'
                                                        disabled={formik.isSubmitting}
                                                        style={{backgroundColor:'#ffbe57'}}
                                                        // onClick={()=>{toComponentB()}}
                                                        // onClick={() => alert()}
                                                    >
                                                        {!loading && <span className='indicator-label'> Update
                                                        </span>}
                                                        {loading && (
                                                            <span className='indicator-progress' style={{ display: 'block' }}>
                                                                Please wait...{' '}
                                                                <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                                            </span>
                                                        )}
                                                    </button>

                                                    <div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
                                                </div>
                                        </Form>
										</ModalBody>
									</Modal>
									
									{/* Delete Modal */}
									<div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
										<div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
											<div className='modal-dialog modal-dialog-centered'>
												<div className='modal-content'>
													<div className='modal-header'>
														<h3 className="text-dark">Confirmation</h3>
														<div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
														</div>
													</div>
													<div className='modal-body'>
														<div className='text-center'>
															<h4>Are you sure want to Delete ? </h4>
															<p className='text-danger'>{brandEdit.name}</p>
														</div>
														<div className='d-flex align-items-center justify-content-center'>
															<button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
																Yes
															</button>
															<button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal' onClick={clearForm}>
																No
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div className="clearfix"></div>
								<div id="basicScenario" className="product-physical">
									{/* <Datatable
										myData={allBrands}
										columns={columns}
										// multiSelectOption={false}
										// pageSize={10}
										// pagination={true}
										// class="-striped -highlight"
									/> */}
			                    <Fragment>
									<DataTable 
										// myData={allBrands}
										data={allBlogs}
										columns={columns}
										multiSelectOption={true}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
								</div>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
            <div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{backgroundColor: "#027a02"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Blog Saved Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{backgroundColor: "#f7572a"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Blog Updated Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastDelete" style={{backgroundColor: "#d1061b"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Blog Deleted Successfully!
				</div>
			</div>
		</Fragment>
	);
};

export default BlogList;
