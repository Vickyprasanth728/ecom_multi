// import React, { Fragment } from "react";
import { Link } from "react-router-dom";
//images import
import React, { Fragment, useState, useEffect } from "react";
// import designer from "../../assets/images/dashboard/designer.jpg";
import TabsetProfile from "../../settings/tabset-profile";
import Breadcrumb from "../../common/breadcrumb";
// import { Card, CardBody, Col, Container, Media, Row, Button } from "reactstrap";
import {getProfile, saveProfile, getProfileEdit, updateProfile, deleteProfile } from '../../../components/settings/core/_requests';
import { useFormik } from 'formik';
import { Offcanvas, Toast } from 'bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Modal,
	ModalBody,
	ModalFooter,
	ModalHeader,
	Row,
	Table,
	Media,
} from "reactstrap";
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from 'yup';
import man from "../../../assets/images/dashboard/man.png";
import logo from "../../../assets/icons/no_image.jpg";

const initialValues = {
    "id" : "",
    "referred_by" : "",
    "provider_id" : "",
    "user_type" : "",
    "name" : "",
    "email" : "",
    "email_verified_at" : "",
    "verification_code" : "",
    "new_email_verificiation_code" : "",
    "password" : "" ,
    "remember_token" : "" ,
    "device_token" : "",
    "avatar" : ""  ,
    "avatar_original" : "",
    "address" : "",
    "country" : "",
    "state" : "",
    "city" : "",
    "postal_code" : "" ,
    "phone" : "",
    "balance" : "" ,
    "banned" : "" ,
    "referral_code" : "",
    "customer_package_id" : "" ,
    "remaining_uploads" : "",
    "role_id":""
}

const UserMenu = () => {
	
	const ProfileSchema = Yup.object().shape({
        // name: Yup.string().required('* Name is required'),
        // email: Yup.string()
        //     .email('Wrong email format')
        //     .min(3, 'Minimum 3 characters')
        //     .max(50, 'Maximum 50 characters')
        //     .required('Email is required'),
        // password: Yup.string().required('* Password is required'),
        // phone: Yup.string()
        // .min(10, '* Minimum 10 symbols')
        // .max(10, '* Maximum 10 symbols'),
    })

	const [allProfile, setAllProfile] = useState([]);
	const [allEditProfile, setEditProfile] = useState([]);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);

    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);

	
	const ProfileList = async () => {
        const ProfileResponse = await getProfile()
        console.log('Profile List');
        console.log(ProfileResponse.Data);
        setAllProfile(ProfileResponse.Data);
    }

	var userId = localStorage.getItem('userId')
	console.log("oo",userId)

	const formik = useFormik({
        initialValues,
        validationSchema: ProfileSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {


            var formData = new FormData();

            formData.append("id" , values.id);
            formData.append("referred_by" , values.referred_by);
            formData.append("provider_id" , values.provider_id);
            formData.append("user_type" , values.user_type);
            formData.append('name', values.name);
            formData.append('email', values.email);
            formData.append('email_verified_at', values.email_verified_at);
            formData.append('verification_code', values.verification_code);
            formData.append('new_email_verificiation_code', values.new_email_verificiation_code);
            formData.append('password', values.password);
            formData.append('remember_token', values.remember_token);
            formData.append('device_token', values.device_token);
            formData.append('avatar', values.avatar);
            formData.append('avatar_original', values.avatar_original);
            formData.append('address', values.address);
            formData.append('country', values.country);
            formData.append('state', values.state);
            formData.append('city', values.city);
            formData.append('postal_code', values.postal_code);
            formData.append('phone', values.phone);
            formData.append('balance', values.balance || "0");
            formData.append('banned', values.banned || "0");
            formData.append('referral_code', values.referral_code);
            formData.append('customer_package_id', values.customer_package_id);
            formData.append('remaining_uploads', values.remaining_uploads || "0");
            
            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }
                
            console.log('lead form body');
            console.log(formData);
            if(!dataBinded){
                const saveCustomerData = await saveProfile(formData, headers);
            
                if(saveCustomerData != null){
                    setLoading(false);
                    document.getElementById('kt_team_close')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    ProfileList();
                }

            } else {
                const updateCustomerData = await updateProfile(selectedId, formData);

                if (updateCustomerData != null) {
                    setLoading(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    setDataBinded(false);
                    ProfileList();
                    resetForm();
                }
            }
            ProfileList();
            // onCloseModal();
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)

            // toast.error('Email Already Exits', {
            //     position: "bottom-right",
            //     autoClose: 5000,
            //     hideProgressBar: false,
            //     closeOnClick: true,
            //     pauseOnHover: true,
            //     draggable: true,
            //     progress: undefined,
            //     theme: "light",
            // });
        }
          ProfileList();
          resetForm();
        //   setEditOpen(false);
        }
    })
	
	const EditProfile = async (id) => {
		// var userId = initialValues.id
        setSelectedId(id);
        const allProfileEdit = await getProfileEdit(userId)
        setEditProfile(allProfileEdit.Data);
		console.log("profile id" ,allProfileEdit.Data);
		formik.setFieldValue('name', allProfileEdit.Data.name);
        formik.setFieldValue('email', allProfileEdit.Data.email);
        formik.setFieldValue('password', allProfileEdit.Data.password);
        formik.setFieldValue('address', allProfileEdit.Data.address);
        formik.setFieldValue('phone', allProfileEdit.Data.phone);
        formik.setFieldValue('city', allProfileEdit.Data.city);
        setDataBinded(true);
		console.log("profile id" ,allProfileEdit.Data);
		// onEditModal();
    } 

    const Cleardata = () => {
        localStorage.clear();
        sessionStorage.clear();
    }

	useEffect(() => {
		ProfileList();
		EditProfile();
		}, []);

	return (
		<Fragment>
            <button type="button" className="d-none" id="sampleTest2" onClick={()=>EditProfile()}></button>
			<li className="onhover-dropdown">
				<div className="media align-items-center">
					{/* <img
						className="align-self-center pull-right img-50 rounded-circle blur-up lazyloaded"
						src={man}
						alt="header-user"
					/> */}
					{/* <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + allEditProfile.id + '/' + allEditProfile.avatar} className="img-fluid img-80 blur-up rounded-circle" alt='' /> */}
                    {allEditProfile.avatar !== null ? 
                        <div className="file-preview box sm">
                            <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/users/avatar/' + allEditProfile.id + '/' + allEditProfile.avatar} className=" rounded-circle blur-up shadow" height={70} width={70} alt='' />
                        </div> :
                        <img
                        src={logo}
                        height={70} width={70} 
                        alt=""
                        className="rounded-circle blur-up lazyloaded"
                    />
                    }

					<div className="dotted-animation">
						<span className="animate-circle"></span>
						<span className="main-circle"></span>
					</div>
				</div>
				<ul className="profile-dropdown onhover-show-div p-20 profile-dropdown-hover">
					<li>
						<Link to={`${process.env.PUBLIC_URL}/settings/profile`}>
							<i data-feather="user"></i>Edit Profile
						</Link>
					</li>
					{/* <li>
						<a href="#javaScript">
							<i data-feather="mail"></i>Inbox
						</a>
					</li>
					<li>
						<a href="#javaScript">
							<i data-feather="lock"></i>Lock Screen
						</a>
					</li>
					<li>
						<a href="#javaScript">
							<i data-feather="settings"></i>Settings
						</a>
					</li> */}
					<li>
						<Link to={`${process.env.PUBLIC_URL}/`} onClick={() => Cleardata()} >
							<i data-feather="log-out"></i>Logout
						</Link>
					</li>
				</ul>
			</li>
		</Fragment>
	);
};

export default UserMenu;
