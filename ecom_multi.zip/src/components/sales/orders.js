import React, { Fragment, useState, useRef, useEffect } from "react";
import Breadcrumb from "../common/breadcrumb";
import data from "../../assets/data/orders";
import Datatable from "../common/datatable";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { Card, CardBody, CardHeader, Col, Container, Row, Modal, ModalHeader, ModalBody, Form, } from "reactstrap";
import { getOrders, editOrder, updateOrder, deleteOrder, getPaymentStatus, getDeliveryStatus, getShippingType} from '../sales/core/_requests';
import logo from "../../assets/icons/no_image.jpg";

const initialValues = {
    "id": '',
    "combined_order_id": "",
    "user_id": "",
    "guest_id": "",
    "seller_id": "",
    "shipping_address": "",
    "additional_info": "",
    "shipping_type": "",
    "pickup_point_id": "",
    "carrier_id": "",
    "delivery_status": "",
    "payment_type": "",
    "payment_status": "",
    "payment_details": "",
    "grand_total": "",
    "coupon_discount": "",
    "code": "",
    "tracking_code": "",
    "date": "",
    "viewed": "",
    "delivery_viewed": "",
    "payment_status_viewed": "",
    "commission_calculated": "",
}

const Orders = () => {

	const OrderSchema = Yup.object().shape({
        // code: Yup.string()
        // .min(10, '* Minimum 10 characters')
		// .max(16, '* Maximum 16 characters')
        // .required(' Order code is required'),
        payment_status: Yup.string().required('* Payment Status is required'),
        delivery_status: Yup.string().required('* Delivery Status is required'),
        shipping_type: Yup.string().required('* Shipping Type is required'),
        grand_total: Yup.string().required('* Grand Total is required'),
    });

    var userId = localStorage.getItem('userId')
	console.log("User ID",userId);

    const [Designation, setDesignation] = useState([]);
    const [allOrders, setAllOrders] = useState([]);
    const [allPaymentStatus, setPaymentStatus] = useState([]);
    const [allDeliveryStatus, setDeliveryStatus] = useState([]);
    const [allShippingType, setShippingType] = useState([]);
    const [allOrderEdit, setAllOrderEdit] = useState([]);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);

    const [loading, setLoading] = useState(false);
    const [editId, setEditId] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    const [open, setOpen] = useState(false);
	const [editOpen, setEditOpen] = useState(false);
	const [deleteOpen, setDeleteOpen] = useState(false);

	// const orderList = async () => {
    //     const ordersResponse = await getOrders()
    //     console.log('All Orders');
    //     console.log(ordersResponse.Data);
    //     setAllOrders(ordersResponse.Data);
    // }

	const orderList = async () => {
        const ordersResponse = await getOrders()
        console.log('All Orders', ordersResponse.Data);

        let new_array = [];
		for(let i=0; i<ordersResponse.Data.length;i++) {
			let cur_obj = {
				...ordersResponse.Data[i],
				'sl_no': i + 1 
			}
			new_array.push(cur_obj)
		}
        setAllOrders(new_array);
		console.log('New Array', new_array);
		console.log('Orders Response', ordersResponse.Data);
    }

	const PaymentStatusList = async () => {
        const PaymentStatusResponse = await getPaymentStatus()
        console.log('Paymemt status', PaymentStatusResponse.Data);
        setPaymentStatus(PaymentStatusResponse.Data);
    }
	const DeliveryStatusList = async () => {
        const DeliveryStatusResponse = await getDeliveryStatus()
        console.log('Paymemt status', DeliveryStatusResponse.Data);
        setDeliveryStatus(DeliveryStatusResponse.Data);
    }
	const ShippingTypeList = async () => {
        const ShippingTypeResponse = await getShippingType()
        console.log('Paymemt status', ShippingTypeResponse.Data);
        setShippingType(ShippingTypeResponse.Data);
    }

    const formik = useFormik({
        initialValues,
        validationSchema: OrderSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true);
            console.log(values);

            try {
                // let formData = new FormData();    //formdata object
                var formData = new FormData();

                const body = {
                    "id" :values.id, 
                    "combined_order_id" :values.combined_order_id, 
                    "user_id" : userId, 
                    "guest_id" :values.guest_id, 
                    "seller_id" :values.seller_id , 
                    "shipping_address" :values.shipping_address, 
                    "additional_info" :values.additional_info, 
                    "shipping_type" :values.shipping_type , 
                    "pickup_point_id" :values.pickup_point_id || "0", 
                    "carrier_id" :values.carrier_id, 
                    "delivery_status" :values.delivery_status, 
                    "payment_type" :values.payment_type, 
                    "payment_status" :values.payment_status, 
                    "payment_details" :values.payment_details, 
                    "grand_total" :values.grand_total, 
                    "coupon_discount" :values.coupon_discount || "0", 
                    "code" :values.code, 
                    "tracking_code" :values.tracking_code, 
                    "date" :values.date, 
                    "viewed" :values.viewed || "0", 
                    "delivery_viewed" :values.delivery_viewed || "0", 
                    "payment_status_viewed" :values.payment_status_viewed || "0", 
                    "commission_calculated" :values.commission_calculated || "0", 
                    "status_payment" :values.status_payment, 
                    "status_delivery" :values.status_delivery, 
                    "type_shipping" :values.type_shipping, 
                }

                // formData.append('id', values.id);
                // formData.append('combined_order_id', values.combined_order_id);
                // formData.append('user_id', values.user_id); 
                // formData.append('guest_id', values.guest_id); 
                // formData.append('seller_id', values.seller_id); 
                // formData.append('shipping_address', values.shipping_address); 
                // formData.append('additional_info', values.additional_info); 
                // formData.append('shipping_type', values.shipping_type); 
                // formData.append('pickup_point_id', values.pickup_point_id); 
                // formData.append('carrier_id', values.carrier_id); 
                // formData.append('delivery_status', values.delivery_status); 
                // formData.append('payment_type', values.payment_type); 
                // formData.append('payment_status', values.payment_status); 
                // formData.append('payment_type', values.payment_type); 
                // formData.append('payment_details', values.payment_details); 
                // formData.append('grand_total', values.grand_total); 
                // formData.append('coupon_discount', values.coupon_discount); 
                // formData.append('code', values.code); 
                // formData.append('date', values.date); 
                // formData.append('viewed', values.viewed); 
                // formData.append('delivery_viewed', values.delivery_viewed); 
                // formData.append('payment_status_viewed', values.payment_status_viewed); 
                // formData.append('commission_calculated', values.commission_calculated); 
             
                // console.log(formData);
                console.log(body);

                const updateProductData = await updateOrder(selectedId, body);
                console.log(updateProductData);

                if (updateProductData != null) {
                    setLoading(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    setDataBinded(false);
                    orderList();
                    clearForm();
                }
                orderList();
        		setEditOpen(false);
            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
            orderList();
		    setEditOpen(false);
        }
    })

    const EditOrderID = async (id) => {
        setSelectedId(id);
        const EditOrderResponse = await editOrder(id)
        setAllOrderEdit(EditOrderResponse.Data);

        setDataBinded(true);
        // formik.setFieldValue('code', EditOrderResponse.Data.code);
        formik.setFieldValue('payment_status', EditOrderResponse.Data.payment_status);
        formik.setFieldValue('delivery_status', EditOrderResponse.Data.delivery_status);
        formik.setFieldValue('shipping_type', EditOrderResponse.Data.shipping_type);
        formik.setFieldValue('grand_total', EditOrderResponse.Data.grand_total);
        onEditModal();
    }

	const columns = [
		{
			name: "id",
			selector:  row => row.sl_no,
			sortable: true,
		},
		{
			name: "Order Code",
			selector: row => row.code,
			sortable: true,
		},
		{
			name: "Customer Name",
			selector: row => row.customer_name,
			sortable: true,
		},
        {
			name: "Seller",
			selector: row => row.shop_name,
			sortable: true,
		},
		{
			name: "Payment Status",
			selector: row => row.status_payment,
			sortable: true,
		},
		{
			name: "Delivery Status",
			selector: row => row.status_delivery,
			sortable: true,
		},
		{
			name: "Shipping Type",
			selector: row => row.type_shipping,
			sortable: true,
		},
		{
			name: "Grand Total",
			selector: row => row.grand_total,
			sortable: true,
		},
 
		{
			name:"Actions",
			cell: (row, index) => (
				<div>
					<span>
						<button
						className="btn btn-danger btn-sm fa fa-pencil mx-2 m-2 button_size"
						data-toggle="modal"
						onClick={() => EditOrderID(row.id)}
						>
						</button>
					</span>
					<span >
						<button
						className="btn btn-primary btn-sm fa fa-trash mx-2 button_size"
						onClick={() => orderDelete(row.id)}
						data-bs-toggle='modal' 
						data-bs-target={'#delete_confirm_popup452222' + selectedId}
						>
						</button>
					</span>
				</div>
			),
		}
	]

	const onEditModal = () => {
		setEditOpen(true);
	};
	const onCloseEdit = () => {
		setEditOpen(false);
	};

    const allClear = () => {
        formik.resetForm();
        setDataBinded(false);
    }

    const onDeleteModal = () => {
		setDeleteOpen(true);
	};

    const orderDelete = async (id) => {
        setSelectedId(id);
		onDeleteModal(id);
    }

    const oncloseDeleteModal = () => {
		setDeleteOpen(false);
	};

    const clearForm = () => {
        formik.resetForm();
        setDataBinded(false);
		setEditOpen(false);
    }
    const onDelete = async (id) => {
        setIsLoading(false);
        console.log(id);
        await deleteOrder(id);
        orderList();
    }

    useEffect(() => {
        orderList();
        PaymentStatusList();
        DeliveryStatusList();
        ShippingTypeList();
    }, []);

	return (
		<Fragment>
			<Breadcrumb title="Orders" parent="Sales" />

			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							<CardHeader>
								<h5>Manage Order</h5>
							</CardHeader>
							<CardBody className="order-datatable">
                                	{/* Edit Modal */}
									<Modal isOpen={editOpen} toggle={onCloseEdit} className='modal-lg'>
										<ModalHeader toggle={onCloseEdit}>
											<h5
												className="modal-title f-w-600"
												id="exampleModalLabel2"
											>
												Edit Order
											</h5>
										</ModalHeader>
										<ModalBody>
                                        <Form noValidate onSubmit={formik.handleSubmit}>
                                            {/* <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Order Code</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Order Code" {...formik.getFieldProps('code')} />
                                                    </div>
                                                    {formik.touched.code && formik.errors.code && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.code}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Title</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Title" {...formik.getFieldProps('title')} />
                                                    </div>
                                                    {formik.touched.title && formik.errors.title && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.title}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div> */}
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Payment Status</label>
                                                    <select className="form-control mt-2 form-select" {...formik.getFieldProps('payment_status')} name="payment_status" id="payment_status"
                                                        data-selected="" data-live-search="true" required>
                                                        <option>-- Payment Status -- </option>
                                                        {allPaymentStatus.map((PaymentstatusValues, i) => {
                                                            return (
                                                                <option selected={i == 0 ? true : false} value={PaymentstatusValues.id} key={i}>{PaymentstatusValues.name}</option>
                                                            )
                                                        })}
                                                    </select>
                                                    {formik.touched.payment_status && formik.errors.payment_status && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.payment_status}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Delivery Status</label>
                                                    <select className="form-control mt-2 form-select" {...formik.getFieldProps('delivery_status')} name="delivery_status" id="delivery_status"
                                                        data-selected="" data-live-search="true" required>
                                                        <option>-- Delivery Status -- </option>
                                                        {allDeliveryStatus.map((DeliveryStatusValues, i) => {
                                                            return (
                                                                <option selected={i == 0 ? true : false} value={DeliveryStatusValues.id} key={i}>{DeliveryStatusValues.name}</option>
                                                            )
                                                        })}
                                                    </select>
                                                    {formik.touched.delivery_status && formik.errors.delivery_status && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.delivery_status}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold">Shipping Type</label>
                                                    <select className="form-control mt-2 form-select" {...formik.getFieldProps('shipping_type')} name="shipping_type" id="shipping_type"
                                                        data-selected="" data-live-search="true" required>
                                                        <option>-- Shipping Type -- </option>
                                                        {allShippingType.map((shippingTypeValues, i) => {
                                                            return (
                                                                <option selected={i == 0 ? true : false} value={shippingTypeValues.id} key={i}>{shippingTypeValues.name}</option>
                                                            )
                                                        })}
                                                    </select>
                                                    {formik.touched.shipping_type && formik.errors.shipping_type && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.shipping_type}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mb-4 col-lg-6">
                                                    <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Grand Total</label>
                                                    <div className="input-group">
                                                        <input type="text" className="form-control" placeholder="Grand Total" {...formik.getFieldProps('grand_total')} />
                                                    </div>
                                                    {formik.touched.grand_total && formik.errors.grand_total && (
                                                        <div className='fv-plugins-message-container'>
                                                            <div className='fv-help-block'>
                                                                <span role='alert' className='text-danger'>{formik.errors.grand_total}</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                                <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                                    <button
                                                        type='submit'
                                                        id='submit_button'
                                                        className='btn btn-primary text-white mx-2'
                                                        disabled={formik.isSubmitting}
                                                        style={{backgroundColor:'#ffbe57'}}
                                                        // onClick={()=>{toComponentB()}}
                                                        // onClick={() => alert()}
                                                    >
                                                        {!loading && <span className='indicator-label'> Update
                                                        </span>}
                                                        {loading && (
                                                            <span className='indicator-progress' style={{ display: 'block' }}>
                                                                Please wait...{' '}
                                                                <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                                            </span>
                                                        )}
                                                    </button>

                                                    <div className='btn btn-danger text-white' onClick={clearForm} > Cancel</div>
                                                </div>
                                        </Form>
										</ModalBody>
									</Modal>
								{/* <Datatable
									multiSelectOption={true}
									myData={data}
									pageSize={10}
									pagination={true}
									class="-striped -highlight"
								/> */}
								 <Fragment>
									<DataTable 
										// myData={data}
										data={allOrders}
										columns={columns}
										multiSelectOption={false}
										pageSize={10}
										pagination={true}
										class="-striped -highlight"
										className="text-center"
									/>
								</Fragment>
							</CardBody>
						</Card>
					</Col>
				</Row>
                {/* Delete Modal */}
                <div isOpen={deleteOpen} toggle={oncloseDeleteModal}>
                    <div className='modal fade p-6' id={'delete_confirm_popup452222' + selectedId} aria-hidden='true'>
                        <div className='modal-dialog modal-dialog-centered'>
                            <div className='modal-content'>
                                <div className='modal-header'>
                                    <h3 className="text-dark">Confirmation</h3>
                                    <div className='btn btn-sm btn-icon btn-active-color-primary' data-bs-dismiss='modal'>
                                    </div>
                                </div>
                                <div className='modal-body'>
                                    <div className='text-center'>
                                        <h4>Are you sure want to Delete ? </h4>
                                    </div>
                                    <div className='d-flex align-items-center justify-content-center'>
                                        <button className='btn btn-sm btn-outline-danger mx-4 mt-3' data-bs-dismiss='modal' onClick={(e) => onDelete(selectedId)}>
                                            Yes
                                        </button>
                                        <button className='btn btn-sm btn-outline-secondary mt-3 me-3' data-bs-dismiss='modal' onClick={clearForm}>
                                            No
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</Container>
		</Fragment>
	);
};

export default Orders;
