import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// user api's
export const GET_PRODUCTS = `${API_URL}/get_products `
export const SAVE_PRODUCTS = `${API_URL}/save_product `
export const GET_PRODUCT_EDIT = `${API_URL}/get_product_id`
export const UPDATE_PRODUCT = `${API_URL}/put_product`
export const DELETE_PRODUCT = `${API_URL}/delete_product`
export const GET_CATEGORIES = `${API_URL}/get_categories `
export const GET_BRAND = `${API_URL}/get_brand `
export const GET_ATTRIBUTES = `${API_URL}/get_attributes `

export function getProducts() {
    return axios.get(GET_PRODUCTS)
    .then((response => response.data))
}

export function saveProduct(body) {
    return axios.post(SAVE_PRODUCTS, body)
    .then((response => response.data))
}

export function getProductEdit(id) {
    return axios.get(GET_PRODUCT_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateProduct(id ,body) {
    return axios.put(UPDATE_PRODUCT+'/'+id, body)
    .then((response => response.data))
}

export function deleteProduct(id) {
    return axios.delete(DELETE_PRODUCT+'/'+id)
    .then((response => response.data))
  }

export function getCategories() {
    return axios.get(GET_CATEGORIES)
    .then((response => response.data))
}

export function getBrands() {
    return axios.get(GET_BRAND)
    .then((response => response.data))
}

export function getAttributes() {
    return axios.get(GET_ATTRIBUTES)
    .then((response => response.data))
}