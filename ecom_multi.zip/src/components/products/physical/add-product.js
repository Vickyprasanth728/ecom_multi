import React, { Fragment, useState,useRef, useEffect } from "react";
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Link, useNavigate } from 'react-router-dom';
import {useLocation} from 'react-router-dom';
import { Offcanvas, Toast } from 'bootstrap';
import Breadcrumb from "../../common/breadcrumb";
import { getProducts, saveProduct, updateProduct, getProductEdit, getCategories, getBrands, getAttributes } from '../core/_requests';
import {
	Card,
	CardBody,
	CardHeader,
	Col,
	Container,
	Form,
	FormGroup,
	Input,
	Label,
	Row,
	Button,
} from "reactstrap";
import one from "../../../assets/images/pro3/1.jpg";
import user from "../../../assets/images/user.png";
import MDEditor from "@uiw/react-md-editor";
import logo from "../../../assets/icons/no_image.jpg";

const initialValues = {
	"id": '',
	"name": "",
	"added_by": "admin",
	"user_id": "",
	"category_id": "",
	"brand_id": "",
	"photos": "",
	"thumbnail_img": "",
	"video_provider": "",
	"video_link": "",
	"tags": "",
	"description": "",
	"unit_price": "",
	"purchase_price": "",
	"variant_product": "",
	"attributes": "",
	"choice_options": "",
	"colors": "",
	"variations": "",
	"todays_deal": "",
	"published": "",
	"approved": "",
	"stock_visibility_state": "",
	"cash_on_delivery": "",
	"featured": "",
	"seller_featured": "",
	"current_stock": "",
	"unit": "",
	"weight": "",
	"min_qty": "",
	"low_stock_quantity": "",
	"discount": "",
	"discount_type": "",
	"discount_start_date": "",
	"discount_end_date": "",
	"tax": "",
	"tax_type": "",
	"shipping_type": "",
	"shipping_cost": "",
	"is_quantity_multiplied": "",
	"est_shipping_days": "",
	"num_of_sale": "",
	"meta_title": "",
	"meta_description": "",
	"meta_img": "",
	"pdf": "",
	"slug": "",
	"rating": "",
	"barcode": "",
	"digital": "0",
	"auction_product": "",
	"file_name": "",
	"file_path": "",
	"external_link": "",
	"external_link_btn": "",
	"wholesale_product": "",
}

const Add_product = () => {
	const [value, setValue] = useState('')
	const [quantity, setQuantity] = useState(1);
	const [file, setFile] = useState();
	const [dummyimgs, setDummyimgs] = useState([
		{ img: user },
		{ img: user },
		{ img: user },
		{ img: user },
		{ img: user },
		{ img: user },
	]);

	const onChange = (e) => {
		setValue(e)
	}

	const IncrementItem = () => {
		if (quantity < 9) {
			setQuantity(quantity + 1);
		} else {
			return null;
		}
	};
	const DecreaseItem = () => {
		if (quantity > 0) {
			setQuantity(quantity - 1);
		} else {
			return null;
		}
	};
	const handleChange = (event) => {
		setQuantity(event.target.value);
	};

	const productSchema = Yup.object().shape({
        name: Yup.string().required('* Product Name is required'),
        category_id: Yup.string().required('* Category Name is required'),
        brand_id: Yup.string().required('* Brand Name is required'),
        unit: Yup.string().required('* Unit is required'),
        min_qty: Yup.string().required('* Minimun Quantity is required'),
        unit_price: Yup.string().required('* Unit Price is required'),
    })

    const location = useLocation();

    const [allProducts, setAllProducts] = useState([]);
    const [allCategories, setAllCategories] = useState([]);  
    const [allBrands, setAllBrands] = useState([]);
    const [attributes, setAttributes] = useState([]);
    const [editProduct, setEditProduct] = useState([]);
    const [loading, setLoading] = useState(false);
    const [dataBinded, setDataBinded] = useState(false);
    const [selectedId, setSelectedId] = useState('');

    const [logoImagePreview, setlogoImagePreview] = useState(null);
    const [thumbImagePreview, setThumbImagePreview] = useState(null);
    const viewLogo = useRef(null);
    const viewThumbImage = useRef(null);
    const [photoImage, setPhotoImage] = useState(null);
    const [thumbImage, setThumbImage] = useState(null);

    const productList = async () => {
        const ProductResponse = await getProducts()
        console.log('all products');
        console.log(ProductResponse.Data);
        setAllProducts(ProductResponse.Data);
    }

    const categoriesList = async () => {
        const categoryResponse = await getCategories()
        console.log('categories list');
        console.log(categoryResponse.Data);
        setAllCategories(categoryResponse.Data);
    }

    const brandList = async () => {
        const brandResponse = await getBrands()
        console.log('brand list');
        console.log(brandResponse.Data);
        setAllBrands(brandResponse.Data);
    }

    const attributesList = async () => {
        const brandResponse = await getAttributes()
        console.log('brand list');
        console.log(brandResponse.Data);
        setAttributes(brandResponse.Data);
    }

    const navigate = useNavigate();
    
    const formik = useFormik({
        initialValues,
        validationSchema: productSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {
                // let formData = new FormData();    //formdata object

                // const body = {
                //     "id" :values.id || null, 
                //     "name" :values.name|| null,
                //     "added_by" :values.added_by|| null,
                //     "user_id" : userId || null,
                //     "category_id" :values.category_id|| null,
                //     "brand_id" :values.brand_id|| null,
                //     "photos" : values.photos || null,
                //     "thumbnail_img" : values.thumbnail_img || null,
                //     "video_provider" :values.video_provider|| null,
                //     "video_link" :values.video_link|| null,
                //     "tags" :values.tags|| null,
                //     "description" :values.description|| null,
                //     "unit_price" :values.unit_price|| null,
                //     "purchase_price" :values.purchase_price|| null,
                //     "variant_product" :values.variant_product|| null,
                //     "attributes" :values.attributes|| null,
                //     "choice_options" :values.choice_options|| null,
                //     "colors" :values.colors|| null,
                //     "variations" :values.variations|| null,
                //     "todays_deal" :values.todays_deal|| null,
                //     "published" :values.published|| null,
                //     "approved" :values.approved|| null,
                //     "stock_visibility_state" :values.stock_visibility_state|| null,
                //     "cash_on_delivery" :values.cash_on_delivery|| null,
                //     "featured" :values.featured|| null,
                //     "seller_featured" :values.seller_featured|| null,
                //     "current_stock" :values.current_stock|| null,
                //     "unit" :values.unit|| null,
                //     "weight" :values.weight|| null,
                //     "min_qty" :values.min_qty|| null,
                //     "low_stock_quantity" :values.low_stock_quantity|| null,
                //     "discount" :values.discount	|| null,
                //     "discount_type" :values.discount_type|| null,
                //     "discount_start_date" : values.discount_start_date|| null,
                //     "discount_end_date" : values.discount_end_date|| null,
                //     "tax" :values.tax|| null,
                //     "tax_type" :values.tax_type|| null,
                //     "shipping_type" :values.shipping_type|| null,
                //     "shipping_cost" :values.shipping_cost|| null,
                //     "is_quantity_multiplied" :values.is_quantity_multiplied|| null,
                //     "est_shipping_days" :values.est_shipping_days|| null,
                //     "num_of_sale" :values.num_of_sale|| null,
                //     "meta_title" :values.meta_title|| null,
                //     "meta_description" :values.meta_description|| null,
                //     "meta_img" : values.meta_img|| null,
                //     "pdf" : values.pdf|| null,
                //     "slug" :values.slug|| null,
                //     "rating" :values.rating|| null,
                //     "barcode" :values.barcode|| null,
                //     "digital" : "0" || null,
                //     "auction_product" :values.auction_product|| null,
                //     "file_name" :values.file_name|| null,
                //     "file_path" :values.file_path|| null,
                //     "external_link" :values.external_link|| null,
                //     "external_link_btn" :values.external_link_btn|| null,
                //     "wholesale_product" :values.wholesale_product|| null,

                // }

                var formData = new FormData();

                formData.append('id', values.id);
                formData.append('name', values.name);
                formData.append('added_by', values.added_by);
                formData.append('user_id', values.user_id || "3");
                formData.append('category_id', values.category_id);
                formData.append('brand_id', values.brand_id);
                formData.append('photos', photoImage);
                formData.append('thumbnail_img', thumbImage);
                formData.append('video_provider', values.video_provider);
                formData.append('video_link', values.video_link);
                formData.append('tags ', values.tags);
                formData.append('description', values.description);
                formData.append('unit_price', values.unit_price);
                formData.append('purchase_price', values.purchase_price);
                formData.append('variant_product', values.variant_product);
                formData.append('attributes', values.attributes);
                formData.append('choice_options', values.choice_options);
                formData.append('colors', values.colors);
                formData.append('variations', values.variations);
                formData.append('todays_deal', values.todays_deal || "0");
                formData.append('published', values.published || "0");
                formData.append('approved', values.approved || "0");
                formData.append('stock_visibility_state', values.stock_visibility_state || "0");
                formData.append('cash_on_delivery', values.cash_on_delivery || "0");
                formData.append('featured', values.featured || "0");
                formData.append('seller_featured', values.seller_featured || "0");
                formData.append('current_stock', values.current_stock || "0");
                formData.append('unit', values.unit);
                formData.append('weight', values.weight);
                formData.append('min_qty', values.min_qty);
                formData.append('low_stock_quantity', values.low_stock_quantity);
                formData.append('discount', values.discount);
                formData.append('discount_type', values.discount_type);
                formData.append('discount_start_date', values.discount_start_date);
                formData.append('discount_end_date', values.discount_end_date);
                formData.append('tax', values.tax);
                formData.append('tax_type', values.tax_type);
                formData.append('shipping_type', values.shipping_type || "flat_rate");
                formData.append('shipping_cost', values.shipping_cost || "0");
                formData.append('is_quantity_multiplied', values.is_quantity_multiplied || "0");
                formData.append('est_shipping_days', values.est_shipping_days);
                formData.append('num_of_sale', values.num_of_sale || "0");
                formData.append('meta_title', values.meta_title);
                formData.append('meta_description', values.meta_description);
                formData.append('meta_img', values.meta_img || "0");
                formData.append('pdf', values.pdf || "0");
                formData.append('slug', values.slug || "0");
                formData.append('rating', values.rating || "0");
                formData.append('barcode', values.barcode);
                formData.append('digital', values.digital || "0");
                formData.append('auction_product', values.auction_product || "0");
                formData.append('file_name', values.file_name);
                formData.append('file_path', values.file_path);
                formData.append('external_link', values.external_link);
                formData.append('external_link_btn', values.external_link_btn || "buy_now");
                formData.append('wholesale_product', values.wholesale_product || "0");

                const headers = {
                    headers: {
                        "Content-type": "multipart/form-data",
                    },
                }
                console.log(formData);
                // console.log(body);

                const saveProductData = await saveProduct(formData);
                if (saveProductData != null) {
                    setLoading(false);
                    resetForm();
                    clearForm();
					document.getElementById('submit_button')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    NavPageList();
                }
                console.log("click");
				NavPageList();

            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
			NavPageList();
        }
    })

    const NavPageList=()=>{
        setTimeout(
            () => navigate('/products/physical/product-list'),
            2000
          );
        }
            

		const handleLogoPreview = (e) => {
			let image_as_base64 = URL.createObjectURL(e.target.files[0])
			let image_as_files = e.target.files[0];
	
			let fields = viewLogo.current?.value.split(".");
	
			let fileType = fields [fields.length - 1];
	
			if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf' || fileType == 'png') {
				setlogoImagePreview(image_as_base64);
				setPhotoImage(image_as_files);
			} else {
				setlogoImagePreview(null);
				setPhotoImage(null);
				if (viewLogo.current != null) {
					viewLogo.current.value = "";
				}
			}
			console.log(viewLogo.current?.value);
			console.log(image_as_files);
			console.log(fileType);
		}
	
		const handleLogoPreview2 = (e) => {
			let image_as_base64 = URL.createObjectURL(e.target.files[0])
			let image_as_files = e.target.files[0];
	
			let fields = viewThumbImage.current?.value.split(".");
	
			let fileType = fields [fields .length - 1];
	
			if (fileType == 'jpg' || fileType == 'jpeg' || fileType == 'pdf'  || fileType == 'png') {
				setThumbImagePreview(image_as_base64);
				setThumbImage(image_as_files);
			} else {
				setThumbImagePreview(null);
				setThumbImage(null);
				if (viewThumbImage.current != null) {
					viewThumbImage.current.value = "";
				}
			}
			console.log(viewThumbImage.current?.value);
			console.log(image_as_files);
			console.log(fileType);
		}
    const removeLogo = () => {
        console.log(viewLogo.current?.value);
        if (viewLogo.current != null) {
            setlogoImagePreview(null);
            setPhotoImage(null);
            viewLogo.current.value = "";
        }
    }

    const removeThumbImage = () => {
        console.log(viewThumbImage.current?.value);
        if (viewThumbImage.current != null) {
            setThumbImagePreview(null);
            setThumbImage(null);
            viewThumbImage.current.value = "";
        }
    }

    const clearForm = () => {
        formik.resetForm();
        removeLogo();
        removeThumbImage();
        setDataBinded(false);
    }

    useEffect(() => {
        productList();
        categoriesList();
        brandList();
        attributesList();
    }, []);

	//	image upload

	const _handleImgChange = (e, i) => {
		e.preventDefault();
		let reader = new FileReader();
		const image = e.target.files[0];
		reader.onload = () => {
			dummyimgs[i].img = reader.result;
			setFile({ file: file });
			setDummyimgs(dummyimgs);
		};
		reader.readAsDataURL(image);
	};

	const handleValidSubmit = () => { };
	return (
		<Fragment>
			<Breadcrumb title="Add Product" parent="Physical" />

			<Container fluid={true}>
				<Row>
					<Col sm="12">
						<Card>
							<CardHeader>
								<div className='row align-items-center'>
									<div className='col-auto'>
										<h5> Add Product</h5>
									</div>
									<div className='d-flex justify-content-end col' data-kt-user-table-toolbar='base'>
										<Link to='/products/physical/product-list' className="btn btn-primary">
											Product List
										</Link>
									</div>
                        		</div>
							</CardHeader>
							<CardBody>
								<Row className="product-adding">
									<Col xl="4">
										<div className="add-product">
											<Row>
												<Col xl="12 xl-50" sm="12 col-9" md="6">
													{/* <img
														src={one}
														alt=""
														className="img-fluid image_zoom_1 blur-up lazyloaded"
													/> */}
														{/* <div className="file-preview box sm">
															{thumbImagePreview != null && (
																<div className='profile_preview position-relative image-input image-input-outline'>
																	<img src={thumbImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={500} width={300} />
																	<div onClick={removeThumbImage} className="p-1 cursor-pointer">
																	</div>
																</div>
															)}
														</div> */}
													<h4 className="text-muted text-center"> Thumbnail Image </h4>
													{thumbImagePreview != null ? <div className="file-preview box sm">
														{thumbImagePreview != null && (
															<div className='profile_preview position-relative image-input image-input-outline'>
																<img src={thumbImagePreview} alt="image preview" className='img-fluid image-input-wrapper w-100px h-100px'/>
																<div onClick={removeThumbImage} className="p-1 cursor-pointer">
																</div>
															</div>
														)}
													</div> :
														<img
															src={logo}
															alt=""
															className="img-fluid image-input-wrapper w-100px h-100px"
															// height={500} width={300}
														/>
													}
												</Col>
												{/* <Col xl="3 xl-50" sm="6 col-3">
													<ul className="file-upload-product">
														{dummyimgs.map((res, i) => {
															return (
																<li key={i}>
																	<div className="box-input-file">
																		<Input
																			className="upload"
																			type="file"
																			onChange={(e) => _handleImgChange(e, i)}
																		/>
																		<img
																			alt=""
																			src={res.img}
																			style={{ width: 50, height: 50 }}
																		/>
																	</div>
																</li>
															);
														})}
													</ul>
												</Col> */}
											</Row>
										</div>
									</Col>
									<Col xl="8">

										<Form className="needs-validation add-product-form" noValidate onSubmit={formik.handleSubmit} >
											<div className="form form-label-center">
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0 ">
														Product Name :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<Input
															 type="text" className="form-control mt-2"
															 placeholder="Product Name" {...formik.getFieldProps('name')}
															 required
														/>
														{formik.touched.name && formik.errors.name && (
															<div className='fv-plugins-message-container'>
																<div className='fv-help-block'>
																	<span role='alert' className='text-danger mx-2'>{formik.errors.name}</span>
																</div>
															</div>
														)}
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Category :
													</Label>
													<div className="col-xl-8 col-sm-7">
													<select className="form-control mt-2" {...formik.getFieldProps('category_id')} name="category_id" id="category_id"
														data-selected="" data-live-search="true" required>
														<option>-- Category Select -- </option>
														{allCategories.map((categoriesValues, i) => {
															return (
																<option selected={i == 0 ? true : false} value={categoriesValues.id} key={i}>{categoriesValues.name}</option>
															)
														})}
													</select>
													{formik.touched.category_id && formik.errors.category_id && (
														<div className='fv-plugins-message-container'>
															<div className='fv-help-block'>
																<span role='alert' className='text-danger mx-2'>{formik.errors.category_id}</span>
															</div>
														</div>
													)}
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Brands :
													</Label>
													<div className="col-xl-8 col-sm-7">
													<select className="form-control mt-2" {...formik.getFieldProps('brand_id')} name="brand_id" id="brand_id"
														data-selected="" data-live-search="true" required>
														<option>-- Brands Select -- </option>
														{allBrands.map((brandValues, i) => {
															return (
																<option selected={i == 0 ? true : false} value={brandValues.id} key={i}>{brandValues.name}</option>
															)
														})}
													</select>
													{formik.touched.brand_id && formik.errors.brand_id && (
														<div className='fv-plugins-message-container'>
															<div className='fv-help-block'>
																<span role='alert' className='text-danger mx-2'>{formik.errors.brand_id}</span>
															</div>
														</div>
													)}
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
											</div>
											<div className="form">
											<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Unit :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<Input
															 type="number" className="form-control mt-2"
															 placeholder="Unit" {...formik.getFieldProps('unit')}
															 min="1" 
															 required
														/>
														{formik.touched.unit && formik.errors.unit && (
															<div className='fv-plugins-message-container'>
																<div className='fv-help-block'>
																	<span role='alert' className='text-danger mx-2'>{formik.errors.unit}</span>
																</div>
															</div>
														)}
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
													Minimum Purchase Qty :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<Input
															 type="number" className="form-control mt-2"
															 placeholder="Minimum Purchase Qty" {...formik.getFieldProps('min_qty')}
															 min="1" 
															 required
														/>
														{formik.touched.min_qty && formik.errors.min_qty && (
															<div className='fv-plugins-message-container'>
																<div className='fv-help-block'>
																	<span role='alert' className='text-danger mx-2'>{formik.errors.min_qty}</span>
																</div>
															</div>
														)}
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
													Unit Price :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<Input
															 type="number" className="form-control mt-2"
															 placeholder="Unit Price" {...formik.getFieldProps('unit_price')}
															 min="1" 
															 required
														/>
														{formik.touched.unit_price && formik.errors.unit_price && (
															<div className='fv-plugins-message-container'>
																<div className='fv-help-block'>
																	<span role='alert' className='text-danger mx-2'>{formik.errors.unit_price}</span>
																</div>
															</div>
														)}
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
													Approved :
													</Label>
													<div className="col-xl-3 col-sm-7">
														{/* <Input
															 type="number" className="form-control mt-2"
															 placeholder="Approved" {...formik.getFieldProps('approved')}
															 min="1" 
															 required
														/> */}
														<select className="form-control mt-2" {...formik.getFieldProps('approved')} name="approved" id="approved"
															data-selected="" data-live-search="true" required style={{cursor:'pointer'}}>
															<option className="text-center">-- Approved -- </option>
															<option value={1}>Yes</option>
															<option value={0}>No</option>
														</select>
														{formik.touched.approved && formik.errors.approved && (
															<div className='fv-plugins-message-container'>
																<div className='fv-help-block'>
																	<span role='alert' className='text-danger mx-2'>{formik.errors.approved}</span>
																</div>
															</div>
														)}
													</div>
													<Label className="col-xl-2 col-sm-4 mb-0">
													Published :
													</Label>
													<div className="col-xl-3 col-sm-7">
														{/* <Input
															 type="number" className="form-control mt-2"
															 placeholder="Published" {...formik.getFieldProps('published')}
															 min="1" 
															 required
														/> */}
														<select className="form-control mt-2" {...formik.getFieldProps('published')} name="published" id="published"
															data-selected="" data-live-search="true" required style={{cursor:'pointer'}}>
															<option  className="text-center">-- Published -- </option>
															<option value={1}>Yes</option>
															<option value={0}>No</option>
														</select>
														{formik.touched.published && formik.errors.published && (
															<div className='fv-plugins-message-container'>
																<div className='fv-help-block'>
																	<span role='alert' className='text-danger mx-2'>{formik.errors.published}</span>
																</div>
															</div>
														)}
													</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Attributes :
													</Label>
													<div className="col-xl-8 col-sm-7">
													<select className="form-control mt-2" {...formik.getFieldProps('attributes')} name="attributes" id="attributes"
														data-selected="" data-live-search="true" required>
														<option>-- Attributes Select -- </option>
														{attributes.map((attributesValues, i) => {
															return (
																<option selected={i == 0 ? true : false} value={attributesValues.id} key={i}>{attributesValues.name}</option>
															)
														})}
													</select>
													{formik.touched.attributes && formik.errors.attributes && (
														<div className='fv-plugins-message-container'>
															<div className='fv-help-block'>
																<span role='alert' className='text-danger mx-2'>{formik.errors.attributes}</span>
															</div>
														</div>
													)}
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												{/* <FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4">
													  Meta Description :
													</Label>
													<div className="col-xl-8 col-sm-7 description-sm">
														<MDEditor
														value={value}
														onChange={onChange}/>
													</div>
												</FormGroup> */}
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
													    Gallery Img :
													</Label>
													<div className="col-xl-8 col-sm-7">
														{/* <Input
	                                                        type="file" className='form-control' name="photos" ref={viewLogo} onChange={handleLogoPreview}
															required
														/> */}
														<div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
															<input type="file" className='form-control' name="photos" ref={viewLogo} onChange={handleLogoPreview} />
														</div>
														
													</div>
													<div className="valid-feedback">Looks good!</div>
													<div className="file-preview box sm d-flex justify-content-center align-items-center mt-3 mx-4">
															{logoImagePreview != null && (
																<div className='profile_preview position-relative image-input image-input-outline'>
																	<img src={logoImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={150} />
																	<div onClick={removeLogo} className="fa fa-remove text-danger" style={{fontSize:"30px" , cursor:"pointer"}}>
																	
																	</div>
																</div>
															)}
														</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
													    Thumbnail Img :
													</Label>
													<div className="col-xl-8 col-sm-7">
														{/* <Input
	                                                        type="file" className='form-control' name="photos" ref={viewThumbImage} onChange={handleLogoPreview2} 
															required
														/> */}
														 <div className="input-group" data-toggle="aizuploader" data-type="image" data-multiple="true">
															<input type="file" className='form-control' name="photos" ref={viewThumbImage} onChange={handleLogoPreview2} />
														</div>
														<div className="file-preview box sm">
															{/* {thumbImagePreview != null && (
																<div className='profile_preview position-relative image-input image-input-outline'>
																	<img src={thumbImagePreview} alt="image preview" className='image-input-wrapper w-100px h-100px' height={100} width={100} />
																	<div onClick={removeThumbImage} className="p-1 cursor-pointer">
																	</div>
																</div>
															)} */}
														</div>
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
											</div>
											<div className="offset-xl-3 offset-sm-4">
												<Button type="submit" color="primary" >
													Submit
												</Button>
												<Button type="button" color="" onClick={clearForm} className='btn btn-danger mx-2'>
													Cancel
												</Button>
											</div>
										
										</Form>

										{/* <Form
											className="needs-validation add-product-form"
											onSubmit={handleValidSubmit}
										>
											<div className="form form-label-center">
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Product Name :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<Input
															className="form-control"
															name="product_name"
															id="validationCustom01"
															type="text"
															required
														/>
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Price :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<Input
															className="form-control mb-0"
															name="price"
															id="validationCustom02"
															type="number"
															required
														/>
													</div>
													<div className="valid-feedback">Looks good!</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Product Code :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<Input
															className="form-control "
															name="product_code"
															id="validationCustomUsername"
															type="number"
															required
														/>
													</div>
													<div className="invalid-feedback offset-sm-4 offset-xl-3">
														Please choose Valid Code.
													</div>
												</FormGroup>
											</div>
											<div className="form">
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Select Size :
													</Label>
													<div className="col-xl-8 col-sm-7">
														<select
															className="form-control digits"
															id="exampleFormControlSelect1"
														>
															<option>Small</option>
															<option>Medium</option>
															<option>Large</option>
															<option>Extra Large</option>
														</select>
													</div>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4 mb-0">
														Total Products :
													</Label>
													<fieldset className="qty-box ms-0">
														<div className="input-group bootstrap-touchspin">
															<div className="input-group-prepend">
																<Button
																	className="btn btn-primary btn-square bootstrap-touchspin-down"
																	type="button"
																	onClick={DecreaseItem}
																>
																	<i className="fa fa-minus"></i>
																</Button>
															</div>
															<div className="input-group-prepend">
																<span className="input-group-text bootstrap-touchspin-prefix"></span>
															</div>
															<Input
																className="touchspin form-control"
																type="text"
																value={quantity}
																onChange={handleChange}
															/>
															<div className="input-group-append">
																<span className="input-group-text bootstrap-touchspin-postfix"></span>
															</div>
															<div className="input-group-append ms-0">
																<Button
																	className="btn btn-primary btn-square bootstrap-touchspin-up"
																	type="button"
																	onClick={IncrementItem}
																>
																	<i className="fa fa-plus"></i>
																</Button>
															</div>
														</div>
													</fieldset>
												</FormGroup>
												<FormGroup className="form-group mb-3 row">
													<Label className="col-xl-3 col-sm-4">
														Add Description :
													</Label>
													<div className="col-xl-8 col-sm-7 description-sm">
														<MDEditor
														value={value}
														onChange={onChange}/>
													</div>
												</FormGroup>
											</div>
											<div className="offset-xl-3 offset-sm-4">
												<Button type="submit" color="primary">
													Add
												</Button>
												<Button type="button" color="light">
													Discard
												</Button>
											</div>
										</Form> */}
									</Col>
								</Row>
							</CardBody>
						</Card>
					</Col>
				</Row>
			</Container>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{backgroundColor: "#027a02"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Product Saved Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastUpdate" style={{backgroundColor: "#f7572a"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Product Updated Successfully!
				</div>
			</div>
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastDelete" style={{backgroundColor: "#d1061b"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Product Deleted Successfully!
				</div>
			</div>
		</Fragment>
	);
};

export default Add_product;
