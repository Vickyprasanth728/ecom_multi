import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

export const GET_BRANDS = `${API_URL}/get_brand `
export const SAVE_BRAND = `${API_URL}/save_brand `
export const GET_BRAND_EDIT = `${API_URL}/get_brand_id`
export const UPDATE_BRAND = `${API_URL}/put_brand`
export const DELETE_BRAND = `${API_URL}/delete_brand`


export function getBrands() {
    return axios.get(GET_BRANDS)
    .then((response => response.data))
}

export function saveBrand(postData, headers) {
    return axios.post(SAVE_BRAND, postData, headers)
    .then((response => response.data))
}

export function getBrandEdit(id) {
    return axios.get(GET_BRAND_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateBrand(id ,body) {
    return axios.put(UPDATE_BRAND+'/'+id, body)
    .then((response => response.data))
}

export function deleteBrand(id) {
    return axios.delete(DELETE_BRAND+'/'+id)
    .then((response => response.data))
}
