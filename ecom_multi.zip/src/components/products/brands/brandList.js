import React, { Fragment, useState, useRef, useEffect } from "react";
import Breadcrumb from "../../common/breadcrumb";
import "react-toastify/dist/ReactToastify.css";
import { data } from "../../../assets/data/category";
import { useFormik } from 'formik';
import Datatable from "../../common/datatable";
import { Offcanvas, Toast } from 'bootstrap';
import { Edit, Trash2 } from "react-feather";
import { getBrands, saveBrand, getBrandEdit, updateBrand, deleteBrand } from '../brands/core/_requests';
import * as Yup from 'yup';
import {
    Button,
    Card,
    CardBody,
    CardHeader,
    Col,
    Container,
    Form,
    FormGroup,
    Input,
    Label,
    Modal,
    ModalBody,
    ModalFooter,
    ModalHeader,
    Row,
} from "reactstrap";

const initialValues = {
    "name": "",
    "logo": "",
    "top": "",
    "slug": "",
    "meta_title": "",
    "meta_description": "",
}

const BrandList = () => {

    const brandSchema = Yup.object().shape({
        name: Yup.string().required('* Name is required'),
        // meta_title: Yup.string().required('* Meta Title is required'),
        // meta_description: Yup.string().required('* Meta Description is required'),
        // module_id: Yup.string().required('Module is required'),       
        // body: Yup.string().required('Body is required'),       
    })

    const [open, setOpen] = useState(false);
    const [allBrands, setAllBrands] = useState([]);
    const [brandEdit, setBrandEdit] = useState([]);
    const [logoImagePreview, setlogoImagePreview] = useState(null);
    const [selectedId, setSelectedId] = useState('');
    const [dataBinded, setDataBinded] = useState(false);
    const viewLogo = useRef < HTMLInputElement > (null);
    const [logoImage, setLogoImage] = useState(null);
    const [loading, setLoading] = useState(false);
    const [editClicked, setEditClicked] = useState(false);
    const [editId, setEditId] = useState('');
    const [isLoading, setIsLoading] = useState(false);


    const brandList = async () => {
        const BrandResponse = await getBrands()
        setAllBrands(BrandResponse);
    }

    const formik = useFormik({
        initialValues,
        validationSchema: brandSchema,
        onSubmit: async (values, { setStatus, setSubmitting, resetForm }) => {
            setLoading(true)
            try {

                var formData = new FormData();

                // const body = {
                //     "name": values.name,
                //     "logo": values.logo,
                //     "top": values.top,
                //     "slug": values.slug,
                //     "meta_title": values.meta_title,
                //     "meta_description": values.meta_description,
                // }

                formData.append('name', values.name);
                formData.append('logo', values.logo);
                formData.append('top', values.top);
                formData.append('slug', values.slug);
                formData.append('meta_title', values.meta_title);
                formData.append('meta_description', values.meta_description);

                const headers = {
                    headers: {
                        "Content-type": "multipart/form-data",
                    },
                }

                console.log('lead form body');
                console.log(formData);
                if (!dataBinded) {
                    const BrandData = await saveBrand(formData, headers);

                    if (BrandData != null) {
                        setLoading(false);
                        document.getElementById('kt_team_close')?.click();
                        var toastEl = document.getElementById('myToastAdd');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                        resetForm();
                        brandList();
                        clearForm();
                    }
                } else {
                    const updateBrandData = await updateBrand(selectedId, formData);

                    if (updateBrandData != null) {
                        setLoading(false);
                        var toastEl = document.getElementById('myToastUpdate');
                        const bsToast = new Toast(toastEl);
                        bsToast.show();
                        resetForm();
                        setDataBinded(false);
                        brandList();
                        clearForm();
                    }
                }
                brandList();
            } catch (error) {
                console.error(error)
                setStatus('The registration details is incorrect')
                setSubmitting(false)
                setLoading(false)
            }
        }
    })
    const onOpenModal = () => {
        setOpen(true);
    };

    const onCloseModal = () => {
        setOpen(false);
    };

    const editBrand = async (id) => {
        setSelectedId(id);
        const allUserEdit = await getBrandEdit(id)
        setBrandEdit(allUserEdit);
        setDataBinded(true);
        formik.setFieldValue('name', allUserEdit.name);
        formik.setFieldValue('logo', allUserEdit.logo);
        formik.setFieldValue('meta_title', allUserEdit.meta_title);
        formik.setFieldValue('meta_description', allUserEdit.meta_description);
    }
    const clearForm = () => {
        formik.resetForm();
        setDataBinded(false);
        setOpen(false);
    }

    const onDelete = async (id) => {
        setIsLoading(false);
        console.log(id);
        await deleteBrand(id);
        setIsLoading(false);
        var toastEl = document.getElementById('myToastDeleteStatus');
        const bsToast = new Toast(toastEl);
        bsToast.show();
        brandList();
    }

    useEffect(() => {
        brandList();
    }, []);

    return (
        <Fragment>
            <Breadcrumb title="Brands List" parent="Physical" />
            <Container fluid={true}>
                <Card>
                    <CardHeader>
                        <h5>Brands</h5>
                    </CardHeader>
                    <div>
                        <div className="btn-popup pull-right mx-4">
                            <Button
                                type="button"
                                color="primary"
                                onClick={onOpenModal}
                                data-toggle="modal"
                                data-original-title="test"
                                data-target="#exampleModal"
                            >
                                Add Brand
                            </Button>
                            <Modal isOpen={open} toggle={onCloseModal}>
                                <ModalHeader toggle={onCloseModal}>
                                    <h5
                                        className="modal-title f-w-600"
                                        id="exampleModalLabel2"
                                    >
                                        Add Brand
                                    </h5>
                                </ModalHeader>
                                <ModalBody>
                                    <Form noValidate onSubmit={formik.handleSubmit}>

                                        <div className="form-group mb-4">
                                            <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Name</label>
                                            <div className="input-group">
                                                <input type="text" className="form-control" placeholder="Name" {...formik.getFieldProps('name')} />
                                            </div>
                                            {formik.touched.name && formik.errors.name && (
                                                <div className='fv-plugins-message-container'>
                                                    <div className='fv-help-block'>
                                                        <span role='alert' className='text-danger'>{formik.errors.name}</span>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                        <div className="form-group mb-4">
                                            <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Logo</label>
                                            <div className="input-group">
                                                <input type="text" className="form-control" placeholder="Logo" {...formik.getFieldProps('logo')} />
                                            </div>
                                            {formik.touched.logo && formik.errors.logo && (
                                                <div className='fv-plugins-message-container'>
                                                    <div className='fv-help-block'>
                                                        <span role='alert' className='text-danger'>{formik.errors.logo}</span>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                        <div className="form-group mb-4">
                                            <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Meta Title</label>
                                            <div className="input-group">
                                                <input type="text" className="form-control" placeholder="Meta Title" {...formik.getFieldProps('meta_title')} />
                                            </div>
                                            {formik.touched.meta_title && formik.errors.meta_title && (
                                                <div className='fv-plugins-message-container'>
                                                    <div className='fv-help-block'>
                                                        <span role='alert' className='text-danger'>{formik.errors.meta_title}</span>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                        <div className="form-group mb-4">
                                            <label htmlFor="basic-url" className="form-label required text-gray-700 fw-bold m-2">Meta Description</label>
                                            <div className="input-group">
                                                <input type="text" className="form-control" placeholder="Meta Description" {...formik.getFieldProps('meta_description')} />
                                            </div>
                                            {formik.touched.meta_description && formik.errors.meta_description && (
                                                <div className='fv-plugins-message-container'>
                                                    <div className='fv-help-block'>
                                                        <span role='alert' className='text-danger'>{formik.errors.meta_description}</span>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                        <div className='card-footer py-5 text-center' id='kt_task_footer'>
                                            <button
                                                type='submit'
                                                id='submit_button'
                                                className='btn btn-primary text-dark mx-2'
                                                disabled={formik.isSubmitting}
                                                style={{ backgroundColor: '#ffbe57' }}
                                            // onClick={()=>{toComponentB()}}
                                            // onClick={() => alert()}
                                            >
                                                {!loading && <span className='indicator-label'>Submit
                                                </span>}
                                                {loading && (
                                                    <span className='indicator-progress' style={{ display: 'block' }}>
                                                        Please wait...{' '}
                                                        <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
                                                    </span>
                                                )}
                                            </button>

                                            <button className='btn btn-secondary text-white' onClick={clearForm} style={{ backgroundColor: '#0fb2f7' }}> Cancel</button>
                                        </div>

                                    </Form>
                                </ModalBody>
                                <ModalFooter>
                                    {/* <Button
												type="button"
												color="primary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Save
											</Button>
											<Button
												type="button"
												color="secondary"
												onClick={() => onCloseModal("VaryingMdo")}
											>
												Close
											</Button> */}
                                </ModalFooter>
                            </Modal>
                        </div>
                    </div>
                </Card>
                <Row className="products-admin ratio_asos">
                    {allBrands.map((myData, i) => {
                        return (
                            <Col xl="3" sm="6" key={i}>
                                <Card>
                                    <div className="products-admin">
                                        <CardBody className="product-box">
                                            <div className="img-wrapper">
                                                <div className="lable-block">
                                                    {myData.tag === "new" ? (
                                                        <span className="lable3">{myData.tag}</span>
                                                    ) : (
                                                        ""
                                                    )}
                                                    {myData.discount === "on sale" ? (
                                                        <span className="lable4">{myData.discount}</span>
                                                    ) : (
                                                        ""
                                                    )}
                                                </div>
                                                <div className="front">
                                                    <a href="/#" className="bg-size">
                                                        {/* <img
															alt=""
															className="img-fluid blur-up bg-img lazyloaded"
															src={myData.photos}
														/> */}
                                                        <img src={process.env.REACT_APP_API_BASE_URL + 'uploads/brand/logo/' + myData.id + '/' + myData.logo} className=" h-50px img-fluid blur-up bg-img lazyloaded" alt='' />
                                                    </a>
                                                    <div className="product-hover">
                                                        <ul>
                                                            <li>
                                                                <Button color="btn" type="button">
                                                                    <Edit className="editBtn" />
                                                                </Button>
                                                            </li>
                                                            <li>
                                                                <Button color="btn" type="button" onClick={(e) => onDelete(myData.id)}>
                                                                    <Trash2 className="deleteBtn" />
                                                                </Button>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="product-detail">
                                                <div className="rating">
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                    <i className="fa fa-star"></i>
                                                </div>
                                                <a href="/#">
                                                    {" "}
                                                    <h6>{myData.name}</h6>
                                                </a>
                                                <h4>
                                                    {myData.meta_title} <del>{myData.meta_description}</del>
                                                </h4>
                                                <ul className="color-variant">
                                                    <li className="bg-light0"></li>
                                                    <li className="bg-light1"></li>
                                                    <li className="bg-light2"></li>
                                                </ul>
                                            </div>
                                        </CardBody>
                                    </div>
                                </Card>
                            </Col>
                        );
                    })}
                </Row>
            </Container>
        </Fragment>
    );
};

export default BrandList;
