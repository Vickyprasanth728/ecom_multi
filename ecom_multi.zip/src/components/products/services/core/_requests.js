import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

export const GET_SERVICES = `${API_URL}/get_services `
export const SAVE_SERVICE = `${API_URL}/save_service `
export const GET_SERVICE_EDIT = `${API_URL}/get_service_edit`
export const UPDATE_SERVICE = `${API_URL}/put_service`
export const DELETE_SERVICE = `${API_URL}/delete_service`
export const GET_CATEGORIES = `${API_URL}/get_categories `


export function getServices() {
    return axios.get(GET_SERVICES)
    .then((response => response.data))
}

export function saveService(postData, headers) {
    return axios.post(SAVE_SERVICE, postData, headers)
    .then((response => response.data))
}

export function getServiceEdit(id) {
    return axios.get(GET_SERVICE_EDIT+'/'+id)
    .then((response => response.data))
}

export function updateService(id ,body) {
    return axios.put(UPDATE_SERVICE+'/'+id, body)
    .then((response => response.data))
}

export function deleteService(id) {
    return axios.delete(DELETE_SERVICE+'/'+id)
    .then((response => response.data))
}

export function getCategories() {
    return axios.get(GET_CATEGORIES)
    .then((response => response.data))
}
