import React, { Fragment, useState, useRef, useEffect } from "react";
import { Tabs, TabList, TabPanel, Tab } from "react-tabs";
import { Button, Col, Form, FormGroup, Input, Label, Row } from "reactstrap";
import { useFormik } from 'formik';
import DataTable from "react-data-table-component";
import { Link, useNavigate } from 'react-router-dom';
import { Offcanvas, Toast } from 'bootstrap';
import * as Yup from 'yup';
import { Card, CardBody, CardHeader, Container } from "reactstrap";
import { getUsers, saveUser, editUser, updateUser, deleteUser, getRoles } from '../users/core/_requests';

const initialValues = {
    "id" : "",
    "referred_by" : "",
    "provider_id" : "",
    "user_type" : "",
    "name" : "",
    "email" : "",
    "email_verified_at" : "",
    "verification_code" : "",
    "new_email_verificiation_code" : "",
    "password" : "" ,
    "remember_token" : "" ,
    "device_token" : "",
    "avatar" : ""  ,
    "avatar_original" : "",
    "address" : "",
    "country" : "",
    "state" : "",
    "city" : "",
    "postal_code" : "" ,
    "phone" : "",
    "balance" : "" ,
    "banned" : "" ,
    "referral_code" : "",
    "customer_package_id" : "" ,
    "remaining_uploads" : "",
    "confirm_password" : "" ,
}

const TabsetUser = () => {

    const navigate = useNavigate();

	const UsersSchema = Yup.object().shape({
		name: Yup.string()
		.min(3, '* Minimum 3 characters')
		.max(50, '* Maximum 50 characters')
		.required('* Name is required'),
		user_type: Yup.string()
		.required('* Role is required'),
        email: Yup.string()
            .email('Wrong email format')
            .min(3, '* Minimum 3 characters')
            .max(50, '* Maximum 50 characters')
            .required('* Email is required'),
		password: Yup.string()
		.matches(
		/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
		"Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
		)
		.required('* Password is required'),
		confirm_password: Yup.string()
		.required('* Password confirmation is required')
		.when('password', {
		  is: (val) => (val && val.length > 0 ? true : false),
		  then: Yup.string().oneOf([Yup.ref('password')], " * Password didn't match"),
		}),
        phone: Yup.string()
        .min(10, '* Minimum 10 symbols')
        .max(10, '* Maximum 10 symbols')
		.required('* Phone number is required'),
    })

	const [allUsers, setAllUsers] = useState([]);
    const [allRoles, setAllRoles] = useState([]);
    const [allUserEdit, setAllUserEdit] = useState([]);
    const [allCategoryBlogs, setAllCategoryBlogs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [editClicked, setEditClicked] = useState(false);
    const [editId, setEditId] = useState('');
    const [selectedId, setSelectedId] = useState('');
    const [blogEdit, setBlogEdit] = useState([]);
    const [dataBinded, setDataBinded] = useState(false);
    const [changeClicked, setChangeClicked] = useState(false);

    const UsersList = async () => {
        const UsersResponse = await getUsers()
        console.log('All Users List');
        console.log(UsersResponse.Data);
        setAllUsers(UsersResponse.Data);
    }

    const RolesList = async () => {
        const UsersResponse = await getRoles()
        console.log('All Users List');
        console.log(UsersResponse);
        setAllRoles(UsersResponse);
    }

	const formik = useFormik({
        initialValues,
        validationSchema: UsersSchema,
        onSubmit: async (values, {setStatus, setSubmitting, resetForm}) => {
          setLoading(true)
          try {
              
            // const body = {

            //     "id" : values.id,
            //     "referred_by" : values.referred_by,
            //     "provider_id" : values.provider_id,
            //     "user_type" : values.user_type,
            //     "name" : values.name,
            //     "email" : values.email,
            //     "email_verified_at" : values.email_verified_at,
            //     "verification_code" : values.verification_code,
            //     "new_email_verificiation_code" : values.new_email_verificiation_code,
            //     "password" : values.password,
            //     "remember_token" : values.remember_token,
            //     "device_token" : values.device_token,
            //     "avatar" : values.avatar,
            //     "avatar_original" : values.avatar_original,
            //     "address" : values.address,
            //     "country" : values.country,
            //     "state" : values.state,
            //     "city" : values.city,
            //     "postal_code" : values.postal_code,
            //     "phone" : values.phone,
            //     "balance" : values.balance,
            //     "banned" : values.banned,
            //     "referral_code" : values.referral_code,
            //     "customer_package_id" : values.customer_package_id,
            //     "remaining_uploads" : values.remaining_uploads,
           
            // }

            var formData = new FormData();

            // formData.append("id" , values.id);
            formData.append("referred_by" , values.referred_by);
            formData.append("provider_id" , values.provider_id);
            formData.append("user_type" , values.user_type);
            formData.append('name', values.name);
            formData.append('email', values.email);
            formData.append('email_verified_at', values.email_verified_at);
            formData.append('verification_code', values.verification_code);
            formData.append('new_email_verificiation_code', values.new_email_verificiation_code);
            formData.append('password', values.password);
            formData.append('remember_token', values.remember_token);
            formData.append('device_token', values.device_token);
            formData.append('avatar', values.avatar);
            formData.append('avatar_original', values.avatar_original);
            formData.append('address', values.address);
            formData.append('country', values.country);
            formData.append('state', values.state);
            formData.append('city', values.city);
            formData.append('postal_code', values.postal_code);
            formData.append('phone', values.phone);
            formData.append('balance', values.balance);
            formData.append('banned', values.banned);
            formData.append('referral_code', values.referral_code);
            formData.append('customer_package_id', values.customer_package_id);
            formData.append('remaining_uploads', values.remaining_uploads);
            
            const headers = {
                headers: {
                    "Content-type": "multipart/form-data",
                },
            }
                
            console.log('lead form body');
            console.log(formData);
            if(!dataBinded){
                const saveUsersData = await saveUser(formData, headers);
            
                if(saveUsersData != null){
                    setLoading(false);
                    document.getElementById('kt_team_close')?.click();
                    var toastEl = document.getElementById('myToastAdd');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    UsersList();
					NavPageList();
                }

            } else {
                const updateUserData = await updateUser(selectedId, formData);

                if (updateUserData != null) {
                    setLoading(false);
                    var toastEl = document.getElementById('myToastUpdate');
                    const bsToast = new Toast(toastEl);
                    bsToast.show();
                    resetForm();
                    setDataBinded(false);
                    UsersList();
                    resetForm();
                }
            }
            UsersList();
    
          } catch (error) {
            console.error(error)
            setStatus('The registration details is incorrect')
            setSubmitting(false)
            setLoading(false)
        }
          UsersList();
          resetForm();
		//   NavPageList();
        }
    })

	const clearButton = () => {
        formik.resetForm();
        setDataBinded(false);
    }

	const NavPageList=()=>{
        setTimeout(
            () => navigate('/users/list-user'),
            2000
          );
        }

    useEffect(() => {
        UsersList();
        RolesList();
    }, []);

	return (
		<Fragment>
			<Tabs>
				<TabList className="nav nav-tabs tab-coupon">
					<Tab className="nav-link">Account</Tab>
					{/* <Tab className="nav-link">Permission</Tab> */}
				</TabList>
				<TabPanel>
					<Form className="needs-validation user-add"noValidate onSubmit={formik.handleSubmit}>
						<h4>Account Details</h4>
						<FormGroup className="row">
							<Label className="col-xl-3 col-md-4">
								<span>*</span> Name
							</Label>
							<div className="col-xl-8 col-md-7">
								<Input
									className="form-control"
									id="validationCustom0"
									type="text"
									required=""
									placeholder="Name"
									{...formik.getFieldProps('name')}
								/>
								{formik.touched.name && formik.errors.name && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.name}</span>
										</div>
									</div>
								)}
							</div>
						</FormGroup>
						{/* <FormGroup className="row">
							<Label className="col-xl-3 col-md-4">
								<span>*</span> Last Name
							</Label>
							<div className="col-xl-8 col-md-7">
								<Input
									className="form-control"
									id="validationCustom1"
									type="text"
									required=""
								/>
							</div>
						</FormGroup> */}
						<FormGroup className="row">
							<Label className="col-xl-3 col-md-4">
								<span>*</span> Role
							</Label>
							<div className="col-xl-8 col-md-7">
								{/* <Input
										type="number" className="form-control mt-2"
										placeholder="Approved" {...formik.getFieldProps('approved')}
										min="1" 
										required
								/> */}
								<select className="form-control text-center" {...formik.getFieldProps('user_type')} name="user_type" id="user_type"
									data-selected="" data-live-search="true" required style={{cursor:'pointer'}}>
									<option className="text-center"> Roles  </option>
									<option>admin</option>
									<option>customer</option>
									<option>seller</option>
								</select>
								{formik.touched.user_type && formik.errors.user_type && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger mx-2'>{formik.errors.user_type}</span>
										</div>
									</div>
								)}
							</div>
						</FormGroup>
						<FormGroup className="row">
							<Label className="col-xl-3 col-md-4">
								<span>*</span> Email
							</Label>
							<div className="col-xl-8 col-md-7">
								<Input
									className="form-control"
									id="validationCustom2"
									type="text"
									required=""
									placeholder="Email : E.g - example@gmail.com"
									{...formik.getFieldProps('email')}
								/>
								{formik.touched.email && formik.errors.email && (
									<div className='fv-plugins-message-container'>
										<div className='fv-help-block'>
											<span role='alert' className='text-danger'>{formik.errors.email}</span>
										</div>
									</div>
								)}
							</div>
						</FormGroup>
						<FormGroup className="row">
							<Label className="col-xl-3 col-md-4">
								<span>*</span> Password
							</Label>
							<div className="col-xl-8 col-md-7">
								<Input
									className="form-control"
									id="validationCustom3"
									type="Password"
									required=""
									placeholder="Password"
									{...formik.getFieldProps('password')}
								/>
								{formik.touched.password && formik.errors.password && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.password}</span>
									</div>
								</div>
								)}
							</div>
						</FormGroup>
						<FormGroup className="row">
							<Label className="col-xl-3 col-md-4">
								<span>*</span> Confirm Password
							</Label>
							<div className="col-xl-8 col-md-7">
								<Input
									className="form-control"
									id="validationCustom4"
									type="password"
									required=""
									placeholder="Confirm Password"
									{...formik.getFieldProps('confirm_password')}
								/>
								{formik.touched.confirm_password && formik.errors.confirm_password && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.confirm_password}</span>
									</div>
								</div>
								)}
							</div>
						</FormGroup>
						<FormGroup className="row">
							<Label className="col-xl-3 col-md-4">
								<span>*</span> Phone Number
							</Label>
							<div className="col-xl-8 col-md-7">
								<Input
									className="form-control"
									id="validationCustom2"
									type="number"
									required=""
									placeholder="Phone Number"
									{...formik.getFieldProps('phone')}
								/>
								{formik.touched.phone && formik.errors.phone && (
								<div className='fv-plugins-message-container'>
									<div className='fv-help-block'>
										<span role='alert' className='text-danger'>{formik.errors.phone}</span>
									</div>
								</div>
								)}
							</div>
						</FormGroup>
						<div className="pull-right">
							<Button type="submit" color="primary">
								Save
							</Button>
						</div>
					</Form>
				</TabPanel>
				<TabPanel>
					<Form className="needs-validation user-add" noValidate="">
						<div className="permission-block">
							<div className="attribute-blocks">
								<h5 className="f-w-600 mb-3">Product Related Permission </h5>
								<Row>
									<Col xl="3" sm="4">
										<Label className="form-label">Add Product</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className="m-checkbox-inline mb-0 custom-radio-ml d-flex radio-animated">
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani1"
													type="radio"
													name="rdo-ani"
												/>
												Allow
											</Label>
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani2"
													type="radio"
													name="rdo-ani"
													defaultChecked
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
								<Row>
									<Col xl="3" sm="4">
										<Label className="form-label">Update Product</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className="m-checkbox-inline mb-0 custom-radio-ml d-flex radio-animated">
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani3"
													type="radio"
													name="rdo-ani1"
													defaultChecked
												/>
												Allow
											</Label>
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani4"
													type="radio"
													name="rdo-ani1"
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
								<Row>
									<Col xl="3" sm="4">
										<Label className="form-label">Delete Product</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className=" m-checkbox-inline mb-0 custom-radio-ml d-flex radio-animated">
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani5"
													type="radio"
													name="rdo-ani2"
												/>
												Allow
											</Label>
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani6"
													type="radio"
													name="rdo-ani2"
													defaultChecked
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
								<Row>
									<Col xl="3" sm="4">
										<Label className="mb-0 sm-label-radio">
											Apply Discount
										</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className="m-checkbox-inline mb-0 custom-radio-ml d-flex radio-animated pb-0">
											<Label className="d-block mb-0">
												<Input
													className="radio_animated"
													id="edo-ani7"
													type="radio"
													name="rdo-ani3"
												/>
												Allow
											</Label>
											<Label className="d-block mb-0">
												<Input
													className="radio_animated"
													id="edo-ani8"
													type="radio"
													name="rdo-ani3"
													defaultChecked
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
							</div>
							<div className="attribute-blocks">
								<h5 className="f-w-600 mb-3">Category Related Permission </h5>
								<Row>
									<Col xl="3" sm="4">
										<Label className="form-label">Add Category</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className="m-checkbox-inline mb-0 custom-radio-ml d-flex radio-animated">
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani9"
													type="radio"
													name="rdo-ani4"
												/>
												Allow
											</Label>
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani10"
													type="radio"
													name="rdo-ani4"
													defaultChecked
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
								<Row>
									<Col xl="3" sm="4">
										<Label className="form-label">Update Category</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className="m-checkbox-inline mb-0 custom-radio-ml d-flex radio-animated">
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani11"
													type="radio"
													name="rdo-ani5"
												/>
												Allow
											</Label>
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani12"
													type="radio"
													name="rdo-ani5"
													defaultChecked
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
								<Row>
									<Col xl="3" sm="4">
										<Label className="form-label">Delete Category</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className="m-checkbox-inline mb-0 custom-radio-ml d-flex radio-animated">
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani13"
													type="radio"
													name="rdo-ani6"
												/>
												Allow
											</Label>
											<Label className="d-block">
												<Input
													className="radio_animated"
													id="edo-ani14"
													type="radio"
													name="rdo-ani6"
													defaultChecked
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
								<Row>
									<Col xl="3" sm="4">
										<Label className="mb-0 sm-label-radio">
											Apply Discount
										</Label>
									</Col>
									<Col xl="9" sm="8">
										<FormGroup className="m-checkbox-inline custom-radio-ml d-flex radio-animated pb-0">
											<Label className="d-block mb-0">
												<Input
													className="radio_animated"
													id="edo-ani15"
													type="radio"
													name="rdo-ani7"
												/>
												Allow
											</Label>
											<Label className="d-block mb-0">
												<Input
													className="radio_animated"
													id="edo-ani16"
													type="radio"
													name="rdo-ani7"
													defaultChecked
												/>
												Deny
											</Label>
										</FormGroup>
									</Col>
								</Row>
							</div>
						</div>
					</Form>
				</TabPanel>
			</Tabs>
			{/* <div className="pull-right">
				<Button type="button" color="primary">
					Save
				</Button>
			</div> */}
			<div aria-atomic="true" aria-live="assertive" className="toast text-white position-fixed end-0 bottom-0 m-3" id="myToastAdd" style={{backgroundColor: "#027a02"}}>
				<div className="toast-header">
					<strong className="me-auto">Success</strong>
					<button aria-label="Close" className="btn-close"
						data-bs-dismiss="toast" type="button">
					</button>
				</div>
				<div className="toast-body">
					Users Saved Successfully!
				</div>
			</div>
		</Fragment>
	);
};

export default TabsetUser;
