import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Coupons
export const GET_COUPONS = `${API_URL}/get_coupons`
export const SAVE_COUPON = `${API_URL}/save_coupons`
export const EDIT_COUPON = `${API_URL}/get_coupon_id` 
export const UPDATE_COUPON = `${API_URL}/put_coupons`
export const DELETE_COUPON = `${API_URL}/delete_coupon`

// Coupons
export function getCoupons() {
    return axios.get(GET_COUPONS)
    .then((response => response.data))
}

export function saveCoupon(body) {
    return axios.post(SAVE_COUPON, body)
    .then((response => response.data))
}

export function editCoupon(id) {
    return axios.get(EDIT_COUPON+'/'+id)
    .then((response => response.data))
}

export function updateCoupon(id ,body) {
    return axios.put(UPDATE_COUPON+'/'+id, body)
    .then((response => response.data))
}

export function deleteCoupon(id) {
    return axios.delete(DELETE_COUPON+'/'+id)
    .then((response => response.data))
}
