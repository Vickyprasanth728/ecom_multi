import React, { Fragment } from "react";
import { Card, CardBody, CardHeader, Container } from "reactstrap";
import Breadcrumb from "../common/breadcrumb";
import TabsetPage from "./tabset-page";
import { json, Link, useNavigate } from 'react-router-dom';

const Create_page = () => {
	return (
		<Fragment>
			<Breadcrumb title="Create Page" parent="Pages" />
			<Container fluid={true}>
				<Card>
					{/* <CardHeader>
						<h5>Add Page</h5>
					</CardHeader> */}
					<CardHeader className="mb-4">
						<div className='row align-items-center'>
							<div className='col-auto'>
								<h5>Add Page</h5>
							</div>
							<div className='d-flex justify-content-end col' data-kt-user-table-toolbar='base'>
								<Link to='/pages/list-page' className="btn btn-primary">
									Page List
								</Link>
							</div>
						</div>
					</CardHeader>
					<CardBody>
						<TabsetPage />
					</CardBody>
				</Card>
			</Container>
		</Fragment>
	);
};

export default Create_page;
