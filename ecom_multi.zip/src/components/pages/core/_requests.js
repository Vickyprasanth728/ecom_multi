import axios, {AxiosResponse}  from 'axios'

const API_URL = process.env.REACT_APP_API_URL

// Pages
export const GET_PAGES = `${API_URL}/get_pages`
export const SAVE_PAGE = `${API_URL}/save_page`
export const EDIT_PAGE_EDIT = `${API_URL}/get_page_id`
export const UPDATE_PAGE = `${API_URL}/put_page`
export const DELETE_PAGE = `${API_URL}/delete_page`

export function getPages() {
    return axios.get(GET_PAGES)
    .then((response => response.data))
}

export function savePage(body) {
    return axios.post(SAVE_PAGE, body)
    .then((response => response.data))
}

export function PageEdit(id) {
    return axios.get(EDIT_PAGE_EDIT+'/'+id)
    .then((response => response.data))
}

export function updatePage(id ,body) {
    return axios.put(UPDATE_PAGE+'/'+id, body)
    .then((response => response.data))
}

export function deletePage(id) {
    return axios.delete(DELETE_PAGE+'/'+id)
    .then((response => response.data))
}